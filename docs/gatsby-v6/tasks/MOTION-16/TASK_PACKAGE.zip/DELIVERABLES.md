# MOTION-16: delivery register

## Balance Brief teaser

- File: `deliverables/editorial-wide-excerpt-1.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The opening lower third “The Balance Brief” and “Episode 1”, the presenter credit “Dr. Nadia Reuter”, the cleared sentence “A studied dose is the amount used in the research, not the amount that fits on a label.” set exactly as written, and the closing card “Vitale Labs. Clear about what we know.” above “A new Balance Brief every week.”. No spoken word anywhere and no health claim beyond the cleared sentence.

## Vertical editorial cutdown

- File: `deliverables/editorial-tall-excerpt-1.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":9},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The cleared sentence “A studied dose is the amount used in the research, not the amount that fits on a label.” set exactly as written and fully inside the frame, and the presenter credit “Dr. Nadia Reuter”. No audio track, no spoken word and no health claim beyond the cleared sentence.

## Square series bumper

- File: `deliverables/editorial-wide-excerpt-2.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The series name “The Balance Brief”, the closing card line “Vitale Labs. Clear about what we know.” sitting above “A new Balance Brief every week.”, and the short link “vitalelabs.co/brief/01”. No audio track, no spoken word and no health claim.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
