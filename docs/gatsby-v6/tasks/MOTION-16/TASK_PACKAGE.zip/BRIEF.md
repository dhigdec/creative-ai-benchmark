# Vitale Labs - Wellness editorial video package

For The Balance Brief, we are changing how episode one goes out. We do not have complete, attributable spoken material we are willing to stand behind, and we will not put words in Dr. Reuter's mouth, so this package runs without speech. The cleared sentence carries the piece as on screen text, set exactly as our reviewer signed it off, with the presenter on camera behind it and nothing added. Keep her credible and the pace calm. Do not strengthen, shorten or paraphrase the claim anywhere on screen, and do not add a second claim to fill the time.

Scope
1. Balance Brief teaser: 1 named export, 16:9, 12 to 15 seconds, instrumental bed only, no speech. The cleared sentence for episode one appears exactly as written, with the opening lower third and the presenter credit.
2. Vertical editorial cutdown: 1 named export, 9:16, 8 to 9 seconds, silent, no audio track at all. The cleared sentence survives the crop intact and the attribution stays accurate.
3. Square series bumper: 1 named export, 1:1, 6 to 8 seconds, silent, no audio track at all. The closing card wording and the short link appear as approved.

Episodes two and three are held back from this commission until we have coverage for them.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Every film in this package is silent or carries the supplied instrumental bed only. There is no narration, no voice over and no spoken claim: the message is carried by on screen text that you set.
- Every supplied clip runs about five seconds. Each film must cut at least three distinct supplied shots, and no film may be padded by looping, freezing or slowing a single clip to reach its runtime.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Bind each output to its selected episode/expert and one exact cleared sentence. The choice may vary within the supplied approved set, but no paraphrased health promise is allowed.
- Use Garamond Premier Pro Display instead of the old Tiempos requirement. Editable caption/layout references are included in the handoff. Silent/music-only cuts do not inherit a legacy narration requirement.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
