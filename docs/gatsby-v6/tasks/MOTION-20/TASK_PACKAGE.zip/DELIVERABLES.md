# MOTION-20: delivery register

## Cobbleway campaign film

- File: `deliverables/client-film-cobbleway.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":10,"max":12},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three visibly different supplied Cobbleway segments on the pale warm sweep, the product name “Wildflower Granola” with its price “$8.50” exactly as written in foldgrain_service_copy.txt, and the studio wordmark FOLD & GRAIN. No black lens capped frames.

## Cobbleway vertical cutdown

- File: `deliverables/client-tall-cobbleway.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The carton held whole inside the upright frame, the product name “Wildflower Granola” and its price “$8.50”. No black lens capped frames.

## Lunara campaign film

- File: `deliverables/client-film-lunara.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":10,"max":12},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three visibly different supplied Lunara segments on the dark charcoal slab, the piece name “Ridge Pendant” with its price “$180” exactly as written in foldgrain_service_copy.txt, and the studio wordmark FOLD & GRAIN. No Cobbleway material.

## Lunara vertical cutdown

- File: `deliverables/client-tall-lunara.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: Pendants held whole inside the upright frame on the dark slab, the piece name “Ridge Pendant” and its price “$180”. No Cobbleway material.

## Client campaign presentation - Cobbleway

- File: `deliverables/campaign-board-cobbleway.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":4}
- Content: The direction is appropriate to this client. The board uses the actual final campaign frames.

## Client campaign presentation - Lunara

- File: `deliverables/campaign-board-lunara.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":4}
- Content: The direction is appropriate to this client. The board uses the actual final campaign frames.

## Studio service-page composition

- File: `deliverables/studio-service.png`
- Specification: {"format":"png","width":1440,"height":2400}
- Content: The service offer follows approved copy. The two client examples remain clearly distinct.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
