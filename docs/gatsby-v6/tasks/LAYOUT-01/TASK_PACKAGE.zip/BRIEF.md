# Kantyna Nova - Private dining menu and campaign system

Private-dining cards, menu and opening materials for Kantyna Nova

We set one table a night at Kantyna Nova: one tasting, one wine flight. The plates were photographed during service, and now the private-dining bookings, menu and opening materials need to look as considered as the room.

Please prepare
- Tasting and wine menu: 1 named export. The fourteen approved courses appear in order on page 1. The forty-two wine entries are present on page 2. The wine grouping supports the pour sequence.
- Private-dining partner deck: 1 named export. The deck explains the private-dining offer. The price build-up follows approved copy.
- Reservations information sheet: 1 named export. The reservation wording is reproduced accurately.
- Opening feed post: 1 named export. Kantyna Nova is visibly identified. The approved booking action is readable.
- Opening story: 1 named export. The booking action remains in the safe area. The restaurant name is legible.
- Opening announcement banner: 1 named export. The opening information is accurate. The food remains the focal point.
- Guest pairing card: 14 named exports. The photograph shows the guest's assigned course. The complete wine designation fits at trim.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the approved menu/course and wine-pairing records for the named menu, reservation document, campaign canvases and pairing cards. The partner deck covers the same event/menu; do not invent a flight for a no-flight booking.
- A course without a supplied photograph is represented with type, not a substituted dish. Wine names alone may use the prescribed italic treatment; prices retain the inline numeric treatment.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
