# LAYOUT-01: delivery register

## Tasting and wine menu

- File: `deliverables/menu.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The fourteen approved courses appear in order on page 1. The forty-two wine entries are present on page 2. The wine grouping supports the pour sequence.

## Private-dining partner deck

- File: `deliverables/partner-deck.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":8}
- Content: The deck explains the private-dining offer. The price build-up follows approved copy.

## Reservations information sheet

- File: `deliverables/reservations.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The reservation wording is reproduced accurately.

## Opening feed post

- File: `deliverables/opening-feed.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Kantyna Nova is visibly identified. The approved booking action is readable.

## Opening story

- File: `deliverables/opening-story.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The booking action remains in the safe area. The restaurant name is legible.

## Opening announcement banner

- File: `deliverables/opening-banner.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The opening information is accurate. The food remains the focal point.

## Guest pairing card - 2026-12-04 - James - Seared scallop, cauliflower, brown butter

- File: `deliverables/pairing-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-04 - James - Duck, salsify, blackberry

- File: `deliverables/pairing-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-04 - Priya - Halibut, leek, mussel cream

- File: `deliverables/pairing-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-04 - Devon - Dry-aged beef, bone marrow, burnt onion

- File: `deliverables/pairing-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-11 - Rosa - Cured fluke, buttermilk, green apple

- File: `deliverables/pairing-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-11 - Amara - Roasted beetroot, aged goat, walnut

- File: `deliverables/pairing-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-13 - Theo - Sea urchin, potato custard, brioche

- File: `deliverables/pairing-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-13 - Nadia - Hand-cut tagliatelle, brown crab, chilli

- File: `deliverables/pairing-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-18 - Callum - Aged comté, honeycomb

- File: `deliverables/pairing-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-18 - Iris - Chocolate, olive oil, malt

- File: `deliverables/pairing-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-18 - Marta-Lena - Smoked mussel, celeriac, dulse

- File: `deliverables/pairing-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-20 - Sébastien - Oyster, brown butter, sea lettuce

- File: `deliverables/pairing-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - 2026-12-20 - Wren - Petit fours

- File: `deliverables/pairing-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":88.9,"pages":1,"template_reference":"kantyna_pairing_card_press.pdf"}
- Content: The photograph shows the guest's assigned course. The complete wine designation fits at trim.

## Guest pairing card - combined production run

- File: `deliverables/pairing-card-combined.pdf`
- Specification: {"format":"pdf","pages":13,"width_mm":127,"height_mm":88.9}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
