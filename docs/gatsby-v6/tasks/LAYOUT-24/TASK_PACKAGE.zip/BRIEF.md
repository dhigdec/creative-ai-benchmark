# Halden and Roe - Marlow trade catalog

A reusable A4 trade catalogue for Halden and Roe's Marlow range

Sixteen pieces need to reach the trade show as one coherent Marlow range. Our studio photography covers two days, and the only page artwork is the flat PDF the printer made three seasons ago.

Deliverables
1. Marlow product trade sheet: 15 named exports. The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.
2. Trade catalogue cover and contents: 1 named export. The collection is identified. The contents use the item register order.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the fourteen eligible sellable pieces in the individual trade sheets, their combined file and the catalogue cover. The earlier sixteen-piece count includes excluded/non-deliverable source records.
- Use the corresponding piece/glaze photograph, not a visually similar substitute. Trade prices and qualifications stay attached to their records; only the specified glaze text is italic.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
