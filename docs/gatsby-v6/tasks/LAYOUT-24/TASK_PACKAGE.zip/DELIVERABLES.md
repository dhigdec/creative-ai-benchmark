# LAYOUT-24: delivery register

## Marlow product trade sheet - MRL-101

- File: `deliverables/trade-sheet-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-102

- File: `deliverables/trade-sheet-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-103

- File: `deliverables/trade-sheet-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-104

- File: `deliverables/trade-sheet-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-105

- File: `deliverables/trade-sheet-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-106

- File: `deliverables/trade-sheet-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-107

- File: `deliverables/trade-sheet-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-108

- File: `deliverables/trade-sheet-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-109

- File: `deliverables/trade-sheet-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-110

- File: `deliverables/trade-sheet-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-112

- File: `deliverables/trade-sheet-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-113

- File: `deliverables/trade-sheet-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-114

- File: `deliverables/trade-sheet-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - MRL-116

- File: `deliverables/trade-sheet-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph depicts this piece. The glaze description preserves its supplied qualification. The trade price is readable.

## Marlow product trade sheet - combined production run

- File: `deliverables/trade-sheet-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":210,"height_mm":297}
- Content: undefined

## Trade catalogue cover and contents

- File: `deliverables/catalogue-cover.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The collection is identified. The contents use the item register order.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
