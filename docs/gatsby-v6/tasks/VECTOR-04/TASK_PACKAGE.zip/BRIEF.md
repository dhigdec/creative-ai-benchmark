# Meridian and Ash - Sticker artwork production masters

Coffee sticker collection: recover four designs, add two, prepare the cutting sheet

Four recovered designs + two new designs = one six-sticker collection for Meridian and Ash.

Please prepare
- Recovered sticker artwork: 4 named exports. The design preserves its photographed original. Interior negative space remains open at 55 mm.
- Original companion sticker: 2 named exports. The drawing belongs stylistically beside the recovered collection. Interior negative space remains open at 55 mm.
- Separate sticker cut contour: 6 named exports. The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.
- Transparent sticker proof: 6 named exports. The proof corresponds to its named vector artwork.
- Sticker imposed production sheet: 1 named export. The cut contours leave at least 10 mm clear from the sheet edge. Adjacent cut contours have at least 6 mm gutter. The CutContour layer can be selected separately from the artwork.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Keep the four recovered and two new sticker artworks distinct. A cut file is geometry for its matching artwork, while the proof shows that artwork at the stated size; neither can stand in for the other.
- The gang sheet contains the six approved designs in register order and within the sheet specification. Source lettering stays recovered; new design text and sheet labels use the current role table.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
