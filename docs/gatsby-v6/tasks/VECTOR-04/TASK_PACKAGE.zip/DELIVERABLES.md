# VECTOR-04: delivery register

## Recovered sticker artwork - Window mark

- File: `deliverables/recovered-sticker-window-mark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The design preserves its photographed original. Interior negative space remains open at 55 mm.

## Recovered sticker artwork - Bag design 1

- File: `deliverables/recovered-sticker-bag-design-1.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The design preserves its photographed original. Interior negative space remains open at 55 mm.

## Recovered sticker artwork - Bag design 2

- File: `deliverables/recovered-sticker-bag-design-2.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The design preserves its photographed original. Interior negative space remains open at 55 mm.

## Recovered sticker artwork - Bag design 3

- File: `deliverables/recovered-sticker-bag-design-3.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The design preserves its photographed original. Interior negative space remains open at 55 mm.

## Original companion sticker - Companion 1

- File: `deliverables/new-sticker-companion-1.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The drawing belongs stylistically beside the recovered collection. Interior negative space remains open at 55 mm.

## Original companion sticker - Companion 2

- File: `deliverables/new-sticker-companion-2.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The drawing belongs stylistically beside the recovered collection. Interior negative space remains open at 55 mm.

## Separate sticker cut contour - Window mark

- File: `deliverables/sticker-cut-window-mark.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.

## Separate sticker cut contour - Bag design 1

- File: `deliverables/sticker-cut-bag-design-1.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.

## Separate sticker cut contour - Bag design 2

- File: `deliverables/sticker-cut-bag-design-2.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.

## Separate sticker cut contour - Bag design 3

- File: `deliverables/sticker-cut-bag-design-3.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.

## Separate sticker cut contour - Companion 1

- File: `deliverables/sticker-cut-companion-1.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.

## Separate sticker cut contour - Companion 2

- File: `deliverables/sticker-cut-companion-2.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The contour is offset 2.5 mm from the artwork edge. The minimum corner radius is 3 mm. This file contains one cutting contour.

## Transparent sticker proof - Window mark

- File: `deliverables/sticker-proof-window-mark.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The proof corresponds to its named vector artwork.

## Transparent sticker proof - Bag design 1

- File: `deliverables/sticker-proof-bag-design-1.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The proof corresponds to its named vector artwork.

## Transparent sticker proof - Bag design 2

- File: `deliverables/sticker-proof-bag-design-2.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The proof corresponds to its named vector artwork.

## Transparent sticker proof - Bag design 3

- File: `deliverables/sticker-proof-bag-design-3.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The proof corresponds to its named vector artwork.

## Transparent sticker proof - Companion 1

- File: `deliverables/sticker-proof-companion-1.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The proof corresponds to its named vector artwork.

## Transparent sticker proof - Companion 2

- File: `deliverables/sticker-proof-companion-2.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The proof corresponds to its named vector artwork.

## Sticker imposed production sheet

- File: `deliverables/gang-sheet.pdf`
- Specification: {"format":"pdf","width_mm":305,"height_mm":457,"pages":1}
- Content: The cut contours leave at least 10 mm clear from the sheet edge. Adjacent cut contours have at least 6 mm gutter. The CutContour layer can be selected separately from the artwork.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
