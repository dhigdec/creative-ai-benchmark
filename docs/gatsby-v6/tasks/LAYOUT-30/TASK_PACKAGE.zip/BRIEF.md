# Emberwell Brew House - Live insert and taproom collateral

Two reusable menu templates for fourteen locations, not fourteen manual edits

Our managers have been retyping the same Emberwell insert in a word processor. That led to a customer finding a different flat-white price twenty minutes down the road. We need two controlled templates that take their local details and prices from the data.

Deliverables
1. Current-menu insert: 15 named exports. The availability wording matches the current record. The price is legible.
2. Taproom counter card: 15 named exports. The store details match this record. The offer is understandable at counter distance.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Store-specific approved prices and availability override the old town-line-only-change statement. Each store's insert/card pair uses its own directory/contact data and eligible items.
- Include editable insert/card source documents in the handoff. Preserve complete allergens and the approved seasonal-only italic treatment; prices need not be identical between stores.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
