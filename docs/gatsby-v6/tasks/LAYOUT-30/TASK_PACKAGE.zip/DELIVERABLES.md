# LAYOUT-30: delivery register

## Current-menu insert - Portsmouth

- File: `deliverables/menu-insert-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Burlington

- File: `deliverables/menu-insert-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Old Port

- File: `deliverables/menu-insert-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Munjoy Hill

- File: `deliverables/menu-insert-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Concord

- File: `deliverables/menu-insert-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Brattleboro

- File: `deliverables/menu-insert-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Camden

- File: `deliverables/menu-insert-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Northampton

- File: `deliverables/menu-insert-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Nashua

- File: `deliverables/menu-insert-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Keene

- File: `deliverables/menu-insert-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Montpelier

- File: `deliverables/menu-insert-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Mystic

- File: `deliverables/menu-insert-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Salem

- File: `deliverables/menu-insert-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - Providence

- File: `deliverables/menu-insert-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The availability wording matches the current record. The price is legible.

## Current-menu insert - combined production run

- File: `deliverables/menu-insert-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":210,"height_mm":297}
- Content: undefined

## Taproom counter card - Portsmouth

- File: `deliverables/counter-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Burlington

- File: `deliverables/counter-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Old Port

- File: `deliverables/counter-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Munjoy Hill

- File: `deliverables/counter-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Concord

- File: `deliverables/counter-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Brattleboro

- File: `deliverables/counter-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Camden

- File: `deliverables/counter-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Northampton

- File: `deliverables/counter-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Nashua

- File: `deliverables/counter-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Keene

- File: `deliverables/counter-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Montpelier

- File: `deliverables/counter-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Mystic

- File: `deliverables/counter-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Salem

- File: `deliverables/counter-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - Providence

- File: `deliverables/counter-card-r015.pdf`
- Specification: {"format":"pdf","width_mm":139.7,"height_mm":215.9,"pages":1,"template_reference":"emberwell_counter_card_prior.pdf"}
- Content: The store details match this record. The offer is understandable at counter distance.

## Taproom counter card - combined production run

- File: `deliverables/counter-card-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":139.7,"height_mm":215.9}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
