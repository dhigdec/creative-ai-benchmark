# Anvil and Oak Strength - Movement coaching clip library

Anvil and Oak is not ready to cut the full coaching library yet: our demo pack does not carry a complete repetition in every angle we need, and we are not going to loop a take to pretend otherwise. What we need from you now is the launch package that puts the library in front of subscribers. Cut it short, cut it silent or to the bed we supply, and put the coaching on screen as text, because a lifter under a bar watches with the sound off. The movement names and the cues must read exactly as they are written in the cleared library sheet, and the framing and the lifter must agree across all three films.

Final handoff
1. Movement library launch reel: 1 named export, 16:9, 12 to 15 seconds, instrumental bed only, no speech. All six cleared movement names appear as on screen text, and at least one movement carries its cue line.
2. Vertical library cutdown: 1 named export, 9:16, 8 to 9 seconds, silent, no audio track at all. The barbell stays inside the frame for every repetition shown.
3. Square library cutdown: 1 named export, 1:1, 6 to 8 seconds, silent, no audio track at all. The wordmark closes the film.

The per movement demonstrations we asked for previously are withdrawn from this commission and will be re briefed once the source pack carries full coverage.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Every film in this package is silent or carries the supplied instrumental bed only. There is no narration, no voice over and no spoken claim: the message is carried by on screen text that you set.
- Every supplied clip runs about five seconds. Each film must cut at least three distinct supplied shots, and no film may be padded by looping, freezing or slowing a single clip to reach its runtime.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Keep the reduced launch/cutdown commission; incomplete individual movement demonstrations remain withdrawn. Use the six named movements and cleared cue wording, with selected movement clips identified in the edit handoff.
- Do not manufacture a full repetition by looping a partial take. Landscape music-only and tall/square silence are distinct output requirements. Preserve the Trade Gothic/Benton roles wherever new text appears.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
