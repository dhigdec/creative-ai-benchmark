# MOTION-15: delivery register

## Movement library launch reel

- File: `deliverables/movement-wide-r002.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: All six movement names set as on screen text exactly as written in anvil_oak_library.csv (“Conventional Deadlift”, “Back Squat”, “Overhead Press”, “Bench Press”, “Barbell Row”, “Front Squat”), at least one cue line quoted exactly from the same sheet, and the wordmark “ANVIL AND OAK”. No spoken word anywhere.

## Vertical library cutdown

- File: `deliverables/movement-tall-r002.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":9},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least two movement names set as on screen text exactly as written in anvil_oak_library.csv, each over footage of that movement, and the wordmark “ANVIL AND OAK”. No audio track and no spoken word.

## Square library cutdown

- File: `deliverables/movement-wide-r003.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least two movement names set as on screen text exactly as written in anvil_oak_library.csv, and a closing frame carrying the wordmark “ANVIL AND OAK”. No audio track and no spoken word.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
