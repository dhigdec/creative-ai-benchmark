# Aldervale Mutual - District insurance counter-card run

Rebuild our insurance counter-card template and produce the district run

The printer who made Aldervale Mutual's counter cards has closed. We still have the press file and need a reusable production route, not a one-time approximation of the design.

Scope
1. District insurance counter card: 14 named exports. The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The eligible active/appointed producers, approved plan rates and state-specific disclosure define the card run. Terminated/resigned producer exclusions apply to individual cards and the combined file.
- Do not shorten the disclosure or apply a different plan recommendation to make a layout fit. Producer data may vary only according to the approved row.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
