# LAYOUT-15: delivery register

## District insurance counter card - Raymond Hollis

- File: `deliverables/producer-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Susan Grady

- File: `deliverables/producer-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Paul Devoe

- File: `deliverables/producer-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Karen Marsh

- File: `deliverables/producer-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Daniel Okafor

- File: `deliverables/producer-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Gina Bianchi

- File: `deliverables/producer-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Miguel Reyes

- File: `deliverables/producer-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Linh Tran

- File: `deliverables/producer-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Sean Donnelly

- File: `deliverables/producer-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Rosa Castellano

- File: `deliverables/producer-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Walter Pruitt

- File: `deliverables/producer-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Dana Whitfield

- File: `deliverables/producer-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - Priya Nandakumar

- File: `deliverables/producer-card-r015.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The compliance wording is reproduced without alteration. The contact information belongs to this producer. The complete Disclosure Text remains inside the card trim.

## District insurance counter card - combined production run

- File: `deliverables/producer-card-combined.pdf`
- Specification: {"format":"pdf","pages":13,"width_mm":148,"height_mm":210}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
