# Marrow and Vane - Exhibition wall-label system

Exhibition wall labels, reconciled artwork records and installer files by room

Marrow and Vane is hanging thirty-nine approved works. Reuse the spring printer's label construction, reconcile the interns' two photo shoots to the accession register, and package the final labels in the approved clockwise room order.

The commission

 Exhibition wall label: 40 named exports. The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

 Room installer label file: 3 named exports. Supply one installer file per room in the approved clockwise hang order.

 Exhibition desk and press checklist: 1 named export. The checklist has separate sections for The Front Room, The Cabinet and The Long Gallery. The press contact is exactly “press@marrowandvane.example”.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the corrected hang order and room assignments. The wall labels carry no price, logo, rule or added colour; these restrictions do not prohibit the recovered mark on the separate checklist.
- The source handoff includes an editable checklist. Bind every accession, artist, title and credit to its actual artwork and corrected room; do not use an entire shoot as the reference for one named label.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
