# LAYOUT-35: delivery register

## Exhibition wall label - C-001

- File: `deliverables/wall-label-r002.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-002

- File: `deliverables/wall-label-r003.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-012

- File: `deliverables/wall-label-r013.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-010

- File: `deliverables/wall-label-r011.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-003

- File: `deliverables/wall-label-r004.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-014

- File: `deliverables/wall-label-r015.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-004

- File: `deliverables/wall-label-r005.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-005

- File: `deliverables/wall-label-r006.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-011

- File: `deliverables/wall-label-r012.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-006

- File: `deliverables/wall-label-r007.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-007

- File: `deliverables/wall-label-r008.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-008

- File: `deliverables/wall-label-r009.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-009

- File: `deliverables/wall-label-r010.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-015

- File: `deliverables/wall-label-r016.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-016

- File: `deliverables/wall-label-r017.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-027

- File: `deliverables/wall-label-r028.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-021

- File: `deliverables/wall-label-r022.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-024

- File: `deliverables/wall-label-r025.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-013

- File: `deliverables/wall-label-r014.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-017

- File: `deliverables/wall-label-r018.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-018

- File: `deliverables/wall-label-r019.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-025

- File: `deliverables/wall-label-r026.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-022

- File: `deliverables/wall-label-r023.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-019

- File: `deliverables/wall-label-r020.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-020

- File: `deliverables/wall-label-r021.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-023

- File: `deliverables/wall-label-r024.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-026

- File: `deliverables/wall-label-r027.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-028

- File: `deliverables/wall-label-r029.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-030

- File: `deliverables/wall-label-r031.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-035

- File: `deliverables/wall-label-r036.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-038

- File: `deliverables/wall-label-r039.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-041

- File: `deliverables/wall-label-r042.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-029

- File: `deliverables/wall-label-r030.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-036

- File: `deliverables/wall-label-r037.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-031

- File: `deliverables/wall-label-r032.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-032

- File: `deliverables/wall-label-r033.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-040

- File: `deliverables/wall-label-r041.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-033

- File: `deliverables/wall-label-r034.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - C-034

- File: `deliverables/wall-label-r035.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"mv_spring_labels_press.pdf"}
- Content: The work identity matches this accession record. The artist attribution is accurate. The curatorial text is readable at installation distance.

## Exhibition wall label - combined production run

- File: `deliverables/wall-label-combined.pdf`
- Specification: {"format":"pdf","pages":39,"width_mm":105.156,"height_mm":148.167}
- Content: undefined

## Room installer label file - The Front Room

- File: `deliverables/installer-room-the-front-room.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":13,"template_reference":"mv_spring_labels_press.pdf"}
- Content: 

## Room installer label file - The Cabinet

- File: `deliverables/installer-room-the-cabinet.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":14,"template_reference":"mv_spring_labels_press.pdf"}
- Content: 

## Room installer label file - The Long Gallery

- File: `deliverables/installer-room-the-long-gallery.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":12,"template_reference":"mv_spring_labels_press.pdf"}
- Content: 

## Exhibition desk and press checklist

- File: `deliverables/artwork-checklist.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":16}
- Content: The checklist has separate sections for The Front Room, The Cabinet and The Long Gallery. The press contact is exactly “press@marrowandvane.example”.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
