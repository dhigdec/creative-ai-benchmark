# Lunara Chronometry - Autumn watch campaign

Watch campaign treatment plus colour-accurate dealer product files

Two kinds of files are needed for Lunara Chronometry, and they must not be confused. The campaign can carry our tonal treatment; the dealer needs clean product files, including a dial-finish reference that stays true to colour.

Scope
1. Autumn watch key visual: 1 named export. The watch dial matches the approved reference. The watch remains the dominant visual.
2. Watch product-page feature: 5 named exports. The case geometry matches the named watch. The specification wording is accurate.
3. Watch dealer launch sheet: 1 named export. Model identities are unambiguous. The layout reflects the stated price position.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The Vesper finish view remains true colour; the other campaign placements use the approved warm single-tone treatment. The key visual and dealer launch may select watches from the eligible register, with the selected reference named.
- Preserve the approved timing/certificate line wherever it is used. Do not change dial, hands, serial/reference markings or case geometry. The Vesper exception is not a failure of campaign-wide colour consistency.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
