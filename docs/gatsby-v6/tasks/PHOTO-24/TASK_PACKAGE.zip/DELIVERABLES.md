# PHOTO-24: delivery register

## Autumn watch key visual

- File: `deliverables/watch-keyvisual.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The watch dial matches the approved reference. The watch remains the dominant visual.

## Watch product-page feature - LC-25-0101

- File: `deliverables/watch-feature-r002.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The case geometry matches the named watch. The specification wording is accurate.

## Watch product-page feature - LC-25-0102

- File: `deliverables/watch-feature-r003.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The case geometry matches the named watch. The specification wording is accurate.

## Watch product-page feature - LC-25-0103

- File: `deliverables/watch-feature-r004.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The case geometry matches the named watch. The specification wording is accurate.

## Watch product-page feature - LC-25-0104

- File: `deliverables/watch-feature-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The case geometry matches the named watch. The specification wording is accurate.

## Watch product-page feature - LC-25-0105

- File: `deliverables/watch-feature-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The case geometry matches the named watch. The specification wording is accurate.

## Watch dealer launch sheet

- File: `deliverables/dealer-launch.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: Model identities are unambiguous. The layout reflects the stated price position.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
