# Nordhaven - Harbour hotel booking campaign

Give a small harbour hotel a distinct look without losing room accuracy

Nordhaven occupies a harbour warehouse with fourteen rooms. We want a distinctive image treatment for the brand, while keeping one room hero true to colour so guests can see what they are booking.

Please prepare
- Harbour hotel booking hero: 1 named export. The scene is the supplied Nordhaven property. The booking action is clear.
- Hotel amenity panel: 1 named export. The named amenities are supported by the source pack. The information is easy to scan.
- Hotel room campaign: 14 named exports. The room photograph matches this room category. The advertised rate preserves its supplied conditions.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The booking hero is the true-colour exception. Amenities and room campaigns use the approved campaign treatment without changing a room's actual finishes. The current shoot with the replacement blinds takes precedence over an older blind view.
- Room names, season/rates and image identity stay paired by the output's approved record. Do not apply a blanket toning check to the true-colour hero.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
