# PHOTO-22: delivery register

## Harbour hotel booking hero

- File: `deliverables/booking-hero.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The scene is the supplied Nordhaven property. The booking action is clear.

## Hotel amenity panel

- File: `deliverables/amenities.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The named amenities are supported by the source pack. The information is easy to scan.

## Hotel room campaign - Quay

- File: `deliverables/room-campaign-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Anchor

- File: `deliverables/room-campaign-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Mast

- File: `deliverables/room-campaign-r004.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Hull

- File: `deliverables/room-campaign-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Reef

- File: `deliverables/room-campaign-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Slate

- File: `deliverables/room-campaign-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Beam

- File: `deliverables/room-campaign-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Cove

- File: `deliverables/room-campaign-r009.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Tide

- File: `deliverables/room-campaign-r010.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Wharf

- File: `deliverables/room-campaign-r011.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Keel

- File: `deliverables/room-campaign-r012.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Harbour Watch

- File: `deliverables/room-campaign-r013.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - North Lantern

- File: `deliverables/room-campaign-r014.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Hotel room campaign - Warehouse Loft

- File: `deliverables/room-campaign-r015.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The room photograph matches this room category. The advertised rate preserves its supplied conditions.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
