# Girdermark - Technical data-sheet and bin-label library

Technical sheets and bin labels from two separate legacy PDFs

Production request: Girdermark Components

Scope
1. Technical part data sheet: 18 named exports. The component photograph matches this part. Dimensions preserve their units.
2. Part bin label: 18 named exports. The part identifier is readable at rack distance. The label does not substitute a similar part.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Data sheets retain the full technical row. Bin labels contain the part identifier, part name and the abbreviated fields already named in their output contract; they are not incomplete data sheets.
- The source handoff includes editable layouts for later part updates. Match similar-looking parts by the record and actual photograph, and preserve exact dimensions/units without rounding.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
