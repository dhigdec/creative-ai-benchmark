# LAYOUT-27: delivery register

## Technical part data sheet - GSV-800 - Governor Sheave Assembly

- File: `deliverables/data-sheet-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - DOA-450 - Door Operator Arm Assembly

- File: `deliverables/data-sheet-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - RBK-120 - Overspeed Governor Restrictor Bracket

- File: `deliverables/data-sheet-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - CCL-210 - Traction Cable Clamp

- File: `deliverables/data-sheet-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - RSK-008 - Relay Socket 8-Pin

- File: `deliverables/data-sheet-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - CTB-303 - Contactor Block 3-Pole

- File: `deliverables/data-sheet-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - DIL-330 - Door Interlock Switch

- File: `deliverables/data-sheet-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - HLS-140 - Hoistway Limit Switch

- File: `deliverables/data-sheet-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - BRC-560 - Brake Coil Assembly (Rev A)

- File: `deliverables/data-sheet-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - BRC-560 - Brake Coil Assembly (Rev B)

- File: `deliverables/data-sheet-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - GTW-090 - Governor Tension Weight

- File: `deliverables/data-sheet-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - SLC-070 - Selector Cam

- File: `deliverables/data-sheet-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - LPB-115 - Landing Pushbutton Fixture

- File: `deliverables/data-sheet-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - CTI-380 - Car Top Inspection Station

- File: `deliverables/data-sheet-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - PMR-045 - Phase Monitor Relay

- File: `deliverables/data-sheet-r016.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - MCM-720 - Motor Contactor Main

- File: `deliverables/data-sheet-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - ENC-160 - Encoder Coupling

- File: `deliverables/data-sheet-r018.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The component photograph matches this part. Dimensions preserve their units.

## Technical part data sheet - combined production run

- File: `deliverables/data-sheet-combined.pdf`
- Specification: {"format":"pdf","pages":17,"width_mm":210,"height_mm":297}
- Content: undefined

## Part bin label - GSV-800 - Governor Sheave Assembly

- File: `deliverables/bin-label-r002.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - DOA-450 - Door Operator Arm Assembly

- File: `deliverables/bin-label-r003.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - RBK-120 - Overspeed Governor Restrictor Bracket

- File: `deliverables/bin-label-r004.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - CCL-210 - Traction Cable Clamp

- File: `deliverables/bin-label-r005.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - RSK-008 - Relay Socket 8-Pin

- File: `deliverables/bin-label-r006.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - CTB-303 - Contactor Block 3-Pole

- File: `deliverables/bin-label-r007.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - DIL-330 - Door Interlock Switch

- File: `deliverables/bin-label-r008.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - HLS-140 - Hoistway Limit Switch

- File: `deliverables/bin-label-r009.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - BRC-560 - Brake Coil Assembly (Rev A)

- File: `deliverables/bin-label-r010.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - BRC-560 - Brake Coil Assembly (Rev B)

- File: `deliverables/bin-label-r011.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - GTW-090 - Governor Tension Weight

- File: `deliverables/bin-label-r012.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - SLC-070 - Selector Cam

- File: `deliverables/bin-label-r013.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - LPB-115 - Landing Pushbutton Fixture

- File: `deliverables/bin-label-r014.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - CTI-380 - Car Top Inspection Station

- File: `deliverables/bin-label-r015.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - PMR-045 - Phase Monitor Relay

- File: `deliverables/bin-label-r016.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - MCM-720 - Motor Contactor Main

- File: `deliverables/bin-label-r017.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - ENC-160 - Encoder Coupling

- File: `deliverables/bin-label-r018.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":62.061,"pages":1,"template_reference":"label_2026_PRESS.pdf"}
- Content: The part identifier is readable at rack distance. The label does not substitute a similar part.

## Part bin label - combined production run

- File: `deliverables/bin-label-combined.pdf`
- Specification: {"format":"pdf","pages":17,"width_mm":99.822,"height_mm":62.061}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
