# PHOTO-25: delivery register

## Industrial surfaces dealer poster

- File: `deliverables/dealer-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The correct Apexguard sub-brand is used. The advertised application is supported by source imagery.

## Surface product-page module - V-PPF-104

- File: `deliverables/surface-pdp-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product variant is identified accurately. The surface finish retains its source texture.

## Surface product-page module - V-PPF-105

- File: `deliverables/surface-pdp-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product variant is identified accurately. The surface finish retains its source texture.

## Surface product-page module - V-PPF-107

- File: `deliverables/surface-pdp-r008.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product variant is identified accurately. The surface finish retains its source texture.

## Surface product-page module - U-TNT-204

- File: `deliverables/surface-pdp-r013.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product variant is identified accurately. The surface finish retains its source texture.

## Surface product-page module - U-TNT-208

- File: `deliverables/surface-pdp-r017.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product variant is identified accurately. The surface finish retains its source texture.

## Surface product-page module - F-HW-301

- File: `deliverables/surface-pdp-r018.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product variant is identified accurately. The surface finish retains its source texture.

## Sub-brand application sheet

- File: `deliverables/identity-applications.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The sub-brand hierarchy is clear. The approved master lettering is preserved.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
