# Apexguard - Industrial surfaces launch photography

Apexguard imagery and recovered logo for a tightly defined six-SKU release

Release scope: six product SKUs
- V-PPF-104, V-PPF-105 and V-PPF-107
- U-TNT-204 and U-TNT-208
- F-HW-301

What we need back
- Industrial surfaces dealer poster: 1 named export. The correct Apexguard sub-brand is used. The advertised application is supported by source imagery.
- Surface product-page module: 6 named exports. The product variant is identified accurately. The surface finish retains its source texture.
- Sub-brand application sheet: 1 named export. The sub-brand hierarchy is clear. The approved master lettering is preserved.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use one flat palette accent per designed output, selected and named in the output's handoff. Warranty and fitment copy comes from the matching SKU record; no stronger claim may be added.
- The current poster, PDP modules and identity-application sheet are the scope. Older reusable packaging masters are not additional deliverables. Photographed product markings remain source artwork, not newly reset type.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
