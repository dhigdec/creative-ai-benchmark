# Cape Marren - Shoulder-season tourism campaign

Coastal destination imagery for the quieter season

Cape Marren's campaign runs October to April. We need a welcoming coastal image set, but not sunshine or sea conditions that misrepresent that season. Six members have contributed photographs; suitable licensed coastal imagery can fill the declared context role.

Final handoff

 Shoulder-season destination poster: 1 named export. Cape Marren is identified. Stock coastal imagery is not labelled as a named member venue.

 Destination itinerary carousel: 6 named exports. Stops use the approved member names. The sequence supports a plausible visitor itinerary.

 Tourism member feature: 1 named export. The featured member is identified accurately. The imagery corresponds to that member or is explicitly illustrative.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- This is the supplied shoulder-season campaign, not a promise of year-round availability. The six-slide itinerary follows eligible member order, grouping records when necessary; the closing slide gives the supplied visitor action.
- Use current trading names and opening months. Excluded members do not appear. A November placement may not promote a seasonal business as open when its approved record says otherwise.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
