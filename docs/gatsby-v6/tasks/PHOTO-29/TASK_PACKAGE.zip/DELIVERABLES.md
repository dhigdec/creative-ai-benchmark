# PHOTO-29: delivery register

## Shoulder-season destination poster

- File: `deliverables/destination-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: Cape Marren is identified. Stock coastal imagery is not labelled as a named member venue.

## Destination itinerary carousel - Page 1

- File: `deliverables/itinerary-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Stops use the approved member names. The sequence supports a plausible visitor itinerary.

## Destination itinerary carousel - Page 2

- File: `deliverables/itinerary-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Stops use the approved member names. The sequence supports a plausible visitor itinerary.

## Destination itinerary carousel - Page 3

- File: `deliverables/itinerary-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Stops use the approved member names. The sequence supports a plausible visitor itinerary.

## Destination itinerary carousel - Page 4

- File: `deliverables/itinerary-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Stops use the approved member names. The sequence supports a plausible visitor itinerary.

## Destination itinerary carousel - Page 5

- File: `deliverables/itinerary-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Stops use the approved member names. The sequence supports a plausible visitor itinerary.

## Destination itinerary carousel - Page 6

- File: `deliverables/itinerary-carousel-p06.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Stops use the approved member names. The sequence supports a plausible visitor itinerary.

## Tourism member feature

- File: `deliverables/member-feature.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The featured member is identified accurately. The imagery corresponds to that member or is explicitly illustrative.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
