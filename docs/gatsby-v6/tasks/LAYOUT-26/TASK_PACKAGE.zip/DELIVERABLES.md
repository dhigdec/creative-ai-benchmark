# LAYOUT-26: delivery register

## Festival programme

- File: `deliverables/programme.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":16}
- Content: The running order matches the approved lineup. Stage changes are easy to follow. Performer names are readable at print size.

## Festival wayfinding sign - Main stage

- File: `deliverables/wayfinding-main-stage.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: 

## Festival wayfinding sign - Acoustic stage

- File: `deliverables/wayfinding-acoustic-stage.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: 

## Festival wayfinding sign - Information

- File: `deliverables/wayfinding-information.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: 

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
