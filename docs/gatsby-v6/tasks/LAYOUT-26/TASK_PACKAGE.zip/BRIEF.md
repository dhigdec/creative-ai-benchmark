# Lanternwood Folk Fest - Festival programme and wayfinding

Festival programme production from fourteen artist submissions and two old pages

Lanternwood's programme needs one finished page per act, not fourteen different submission styles. We have the lineup sheet, fourteen artist photographs and two old printed programme pages to work from.

Final handoff

 Festival programme: 1 named export. The running order matches the approved lineup. Stage changes are easy to follow. Performer names are readable at print size.

 Festival wayfinding sign: 3 named exports. Use the approved destination and arrow direction for the Main stage, Acoustic stage and Information signs.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The versioned wayfinding schedule and committee's running order override spreadsheet booking order. Keep the two day-closing headliners in their assigned closing positions and each sign's exact arrow/destination pairing.
- Zero tracking means exactly 0 em, not negative tracking. This programme/wayfinding commission uses its Yeseva One system; the performer-credential commission has a separately specified campaign identity.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
