# PHOTO-21: delivery register

## Autumn studio journal carousel - Page 1

- File: `deliverables/autumn-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The image sequence tells a coherent making story. The captions match the pictured work.

## Autumn studio journal carousel - Page 2

- File: `deliverables/autumn-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The image sequence tells a coherent making story. The captions match the pictured work.

## Autumn studio journal carousel - Page 3

- File: `deliverables/autumn-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The image sequence tells a coherent making story. The captions match the pictured work.

## Autumn studio journal carousel - Page 4

- File: `deliverables/autumn-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The image sequence tells a coherent making story. The captions match the pictured work.

## Autumn studio journal carousel - Page 5

- File: `deliverables/autumn-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The image sequence tells a coherent making story. The captions match the pictured work.

## Autumn studio journal carousel - Page 6

- File: `deliverables/autumn-carousel-p06.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The image sequence tells a coherent making story. The captions match the pictured work.

## Studio journal feature

- File: `deliverables/journal-feature.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The typography supports an editorial reading order. The feature identifies Quill and Kiln.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
