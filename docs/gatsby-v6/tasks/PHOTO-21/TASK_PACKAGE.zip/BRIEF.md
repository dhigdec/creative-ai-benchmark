# Quill and Kiln - Autumn ceramics signature look

An autumn image library that still looks like my ceramics

Hi, I am Marlo Quill, the maker behind Quill and Kiln. I have a month's worth of photographs from my phone and a borrowed camera, taken under four different kinds of light. I need help turning them into a usable autumn collection.

Deliverables
1. Autumn studio journal carousel: 6 named exports. The image sequence tells a coherent making story. The captions match the pictured work.
2. Studio journal feature: 1 named export. The typography supports an editorial reading order. The feature identifies Quill and Kiln.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The six carousel pages follow the eligible piece/caption order; the journal feature uses the same collection and the supplied collaboration credits. This delivery is fixed-date artwork, not an editable-date template commission.
- Use the actual piece photographs and glaze references. Do not invent a caption, provenance detail or collaboration credit to fill a layout.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
