# MOTION-12: delivery register

## Low Beam release teaser

- File: `deliverables/release-teaser.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The artist name NIGHTFORM held throughout, the track title Low Beam, and the release date October 17 as written in nightform_captions.txt, on a closing frame that holds. At least three distinct source shots, all of them night road material.

## Low Beam vertical cutdown

- File: `deliverables/release-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The artist name NIGHTFORM, the track title Low Beam and the release line word for word from nightform_captions.txt, all fully inside the frame. At least three distinct source shots, all of them also used in the wide teaser.

## Music release cover

- File: `deliverables/release-cover.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The artist and track names are correct.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
