# NIGHTFORM - Low Beam music release package

Low Beam is the next release. What I need is short form: a teaser, an upright cutdown and the cover, and all three should feel like one night.

The picture in the pack is silent and short, so this is cut picture over music, nothing else. The cleared Low Beam instrumental excerpt is in the pack as nightform_bed.wav. Cut to that excerpt, let the picture move with it, and finish on a phrase rather than stopping mid note. There is no voice on this release and there should not be one on the films. The lines from the caption sheet carry the words, set on screen.

The commission

Low Beam release teaser: one named export, wide, twelve to fifteen seconds, music. The picture responds to the excerpt, the release details are accurate and the last frame holds. At least three different shots, no looping one clip to fill the length.

Low Beam vertical cutdown: one named export, upright, eight to ten seconds, music. Same night, same road, with the release line readable at arm's length on a dark moving frame.

Music release cover: one named export, square still. Artist and track names exactly as the formats file has them, wordmark from the supplied file, nothing ornamented or distressed.

It is one drive, north of the city, around eleven at night. Any new footage follows that direction: the same wet road, the same sodium light, no daylight, no second location and no people introduced into it.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Video delivery means a playable MP4, not a storyboard, a still montage PDF or an editing log. Audio expectations are stated on each film, and no film in this pack carries speech.

Live action edits require adequate distinct footage. Looping a short clip is not a substitute for the missing coverage.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the supplied Low Beam music master/approved segment and caption/title copy. The source handoff includes editable title/caption documents or a working project link, not just flattened renders.
- Keep the recovered wordmark untouched. The fitted title remains a single line within the allowed safe width. Use the actual night-road source footage; approximate shot-list timestamps are navigation notes, not a demand for nonexistent frames.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
