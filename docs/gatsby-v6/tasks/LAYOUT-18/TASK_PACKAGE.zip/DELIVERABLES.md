# LAYOUT-18: delivery register

## Wholesale relaunch deck

- File: `deliverables/wholesale-deck.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":10}
- Content: The range story supports a trade buying conversation. The product facts are accurate.

## Wholesale paid-social creative - Range

- File: `deliverables/paid-canvas-range.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The trade enquiry action is visible.

## Wholesale paid-social creative - Material

- File: `deliverables/paid-canvas-material.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The trade enquiry action is visible.

## Storefront range banner

- File: `deliverables/storefront-banner.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Kilnmore is identified. The range remains recognisable.

## Product specification tile - KM-01

- File: `deliverables/spec-tile-r002.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-02

- File: `deliverables/spec-tile-r003.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-03

- File: `deliverables/spec-tile-r004.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-04

- File: `deliverables/spec-tile-r005.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-05

- File: `deliverables/spec-tile-r006.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-06

- File: `deliverables/spec-tile-r007.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-07

- File: `deliverables/spec-tile-r008.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-08

- File: `deliverables/spec-tile-r009.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-09

- File: `deliverables/spec-tile-r010.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-10

- File: `deliverables/spec-tile-r011.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-11

- File: `deliverables/spec-tile-r012.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-12

- File: `deliverables/spec-tile-r013.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Product specification tile - KM-13

- File: `deliverables/spec-tile-r014.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The item geometry matches this record.

## Wholesale range one-pager

- File: `deliverables/range-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The product hierarchy is clear.

## Mark and type reference

- File: `deliverables/identity-page.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The typography choices are identified accurately.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
