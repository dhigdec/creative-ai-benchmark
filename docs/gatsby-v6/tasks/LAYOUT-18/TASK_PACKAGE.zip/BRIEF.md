# Kilnmore - Wholesale relaunch campaign

Kilnmore wholesale relaunch: preserve the glazes across the full campaign

The relaunch needs to look like one Kilnmore range. We have fourteen captures from two very different mornings, covering thirteen pieces, and four glazes that customers must still be able to distinguish after correction.

Deliverables
1. Wholesale relaunch deck: 1 named export. The range story supports a trade buying conversation. The product facts are accurate.
2. Wholesale paid-social creative: 2 named exports. The trade enquiry action is visible.
3. Storefront range banner: 1 named export. Kilnmore is identified. The range remains recognisable.
4. Product specification tile: 13 named exports. The item geometry matches this record.
5. Wholesale range one-pager: 1 named export. The product hierarchy is clear.
6. Mark and type reference: 1 named export. The typography choices are identified accurately.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the current Panchang display system. The earlier humanist-serif direction is withdrawn for this wholesale relaunch. The 11 pt wordmark applies to print; the screen equivalent is 15 px before uniform layout scaling.
- Bind each spec tile and selected campaign/deck placement to its actual piece and glaze. The identity page documents this same V6 system. Editable source references are included in the handoff for the designed range documents.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
