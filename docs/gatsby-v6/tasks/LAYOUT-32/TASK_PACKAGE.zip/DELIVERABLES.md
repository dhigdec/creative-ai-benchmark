# LAYOUT-32: delivery register

## Forecourt sales card - 4021

- File: `deliverables/forecourt-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4108

- File: `deliverables/forecourt-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 3960

- File: `deliverables/forecourt-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4210

- File: `deliverables/forecourt-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 887

- File: `deliverables/forecourt-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4155

- File: `deliverables/forecourt-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4090

- File: `deliverables/forecourt-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 3921

- File: `deliverables/forecourt-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4260

- File: `deliverables/forecourt-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4033

- File: `deliverables/forecourt-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4177

- File: `deliverables/forecourt-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 3998

- File: `deliverables/forecourt-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4212

- File: `deliverables/forecourt-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - 4055

- File: `deliverables/forecourt-card-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

## Forecourt sales card - combined production run

- File: `deliverables/forecourt-card-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":210,"height_mm":297}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
