# Vanguard Motors - Forecourt sales card system

Forecourt cards for current stock, with honest paint and highlight handling

Vanguard Motors has fourteen cars on the forecourt, but the feed still includes vehicles sold or reserved. Please reconcile the stock before producing the A4 window cards. The photography also needs care: some panels were overexposed during the shoot.

Final handoff

 Forecourt sales card: 15 named exports. The pictured vehicle matches this stock number. The finance wording follows the approved text. The vehicle specification is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use current eligible stock, price and finance copy from the approved register. Sold/reserved exclusions remain effective. A clipped highlight is reported as a source limitation, not repainted into fictional bodywork.
- Pair each car image with its stock ID. Preserve complete broker wording and real paint/condition. VANGUARD/MOTORS proportions apply to the newly typeset identity treatment, not to vehicle badges.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
