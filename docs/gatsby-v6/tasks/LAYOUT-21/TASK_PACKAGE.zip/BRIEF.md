# Harborline Realty - Weekly listing sheet system

Restore a weekly property-sheet workflow from our retired printer's PDF

Every Monday, Harborline Realty prints a sheet for each active listing. The printer retired with the working file. We need the process rebuilt so the current list controls the output, while the starter homes and premium properties retain appropriate, distinct image treatments.

Scope
1. Weekly property listing sheet: 12 named exports. The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The approved weekly active register supplies the current price, status, house and agent. The source handoff includes editable listing-sheet documents so Thursday prices can be changed later.
- Starter-home versus premium density is a layout choice within the same type roles; neither may lose required facts/contact details. Recover the office-window mark rather than resetting it.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
