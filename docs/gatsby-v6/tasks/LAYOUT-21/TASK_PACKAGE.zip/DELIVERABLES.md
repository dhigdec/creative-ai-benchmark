# LAYOUT-21: delivery register

## Weekly property listing sheet - 18 Lighthouse Point Road, Rockport, Maine 04856

- File: `deliverables/listing-sheet-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 9 Shore Rd, Camden

- File: `deliverables/listing-sheet-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 24 Bayview Ter, Rockport

- File: `deliverables/listing-sheet-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 3 Beacon Ln, Lincolnville

- File: `deliverables/listing-sheet-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 42 Birch Ln, Rockland

- File: `deliverables/listing-sheet-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 7 Mechanic St, Rockland

- File: `deliverables/listing-sheet-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 115 Cedar St, Thomaston

- File: `deliverables/listing-sheet-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 28 Pleasant St, Rockland

- File: `deliverables/listing-sheet-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 6 Elm St, Camden

- File: `deliverables/listing-sheet-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 51 High St, Camden

- File: `deliverables/listing-sheet-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - 19 Sea St, Rockland

- File: `deliverables/listing-sheet-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The photograph belongs to this listing. The listing status is current in the supplied register. The agent contact is clear.

## Weekly property listing sheet - combined production run

- File: `deliverables/listing-sheet-combined.pdf`
- Specification: {"format":"pdf","pages":11,"width_mm":210,"height_mm":297}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
