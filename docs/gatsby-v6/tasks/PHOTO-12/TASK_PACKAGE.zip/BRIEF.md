# Kilnmore - Ceramic ecommerce image system

A coherent ceramics range, with the glaze differences left intact

We sell the surface as much as the form at Kilnmore. Fourteen pieces and their glaze details need to become one usable product image library, but the work should not flatten the glazes into the same colour or texture.

Scope
1. Ceramic product-page module: 14 named exports. The vessel geometry matches the named product. The glaze retains its material texture.
2. Wholesale range one-sheet: 1 named export. The range names agree with the supplied register. Trade information is easy to scan.
3. Ceramic range launch carousel: 5 named exports. Kilnmore is identified on the opening page. The range sequence makes product differences clear.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- This brief commissions designed PDP modules, a wholesale sheet and a launch carousel. The product-only square marketplace primaries in the older notes are not additional outputs.
- SKU and glaze bindings in the register are authoritative. The wholesale sheet covers the eligible range; the carousel uses the same records in register order. Brand graphic colours do not restrict the photographed glaze colours.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
