# PHOTO-12: delivery register

## Ceramic product-page module - Tide Mug

- File: `deliverables/ceramic-pdp-r002.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Basin Bowl

- File: `deliverables/ceramic-pdp-r003.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Reed Bud Vase

- File: `deliverables/ceramic-pdp-r004.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Column Tumbler

- File: `deliverables/ceramic-pdp-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Pour-Over Cone

- File: `deliverables/ceramic-pdp-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Harvest Serving Bowl

- File: `deliverables/ceramic-pdp-r007.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Side Plate

- File: `deliverables/ceramic-pdp-r008.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Ironwork Mug

- File: `deliverables/ceramic-pdp-r009.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Ironwork Bowl

- File: `deliverables/ceramic-pdp-r010.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Ember Bud Vase

- File: `deliverables/ceramic-pdp-r011.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Ember Tumbler

- File: `deliverables/ceramic-pdp-r012.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Ash Dinner Plate

- File: `deliverables/ceramic-pdp-r013.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Salt Vase

- File: `deliverables/ceramic-pdp-r014.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Ceramic product-page module - Pewter Tumbler

- File: `deliverables/ceramic-pdp-r015.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The vessel geometry matches the named product. The glaze retains its material texture.

## Wholesale range one-sheet

- File: `deliverables/wholesale-range.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The range names agree with the supplied register. Trade information is easy to scan.

## Ceramic range launch carousel - Page 1

- File: `deliverables/launch-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Kilnmore is identified on the opening page. The range sequence makes product differences clear.

## Ceramic range launch carousel - Page 2

- File: `deliverables/launch-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Kilnmore is identified on the opening page. The range sequence makes product differences clear.

## Ceramic range launch carousel - Page 3

- File: `deliverables/launch-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Kilnmore is identified on the opening page. The range sequence makes product differences clear.

## Ceramic range launch carousel - Page 4

- File: `deliverables/launch-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Kilnmore is identified on the opening page. The range sequence makes product differences clear.

## Ceramic range launch carousel - Page 5

- File: `deliverables/launch-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Kilnmore is identified on the opening page. The range sequence makes product differences clear.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
