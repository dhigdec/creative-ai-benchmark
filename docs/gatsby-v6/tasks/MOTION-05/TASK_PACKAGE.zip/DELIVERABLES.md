# MOTION-05: delivery register

## Residence launch film

- File: `deliverables/opening-film.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least four different supplied clips, an opening card carrying the approved tagline “Nine residences. No hurry.”, one residence fact card reading “The Penthouse”, “Floor 9”, “4,300 square feet”, and a closing card reading “Viewings by appointment”. No price on screen.

## Residence vertical teaser

- File: `deliverables/opening-teaser.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three different supplied clips, the development name “Sterling Row” on screen, followed by a closing card reading “Viewings by appointment”. No price and none of the banned phrases.

## Blue-hour residence hero 1

- File: `deliverables/residence-hero-01.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 2

- File: `deliverables/residence-hero-02.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 3

- File: `deliverables/residence-hero-03.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 4

- File: `deliverables/residence-hero-04.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 5

- File: `deliverables/residence-hero-05.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 6

- File: `deliverables/residence-hero-06.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 7

- File: `deliverables/residence-hero-07.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Blue-hour residence hero 8

- File: `deliverables/residence-hero-08.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Truthful residence view; no fabricated feature.

## Sterling Row viewing brochure

- File: `deliverables/viewing-brochure.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: Page 1: Sterling Row and Nine residences. No hurry., with sterlingrow_residence_still_08.jpg. Pages 2-4: three unit records per page, in sterlingrow_units.csv order; typography-led factual entries, no invented unit photograph. Include both full disclosure lines on each of these pages. Page 5: Nine residences. Full floor. Sold one at a time, to buyers in no hurry., with sterlingrow_residence_still_04.jpg. Page 6: Viewings by appointment. and both full disclosure lines.

## Sterling Row film cover

- File: `deliverables/residence-film-cover.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Sterling Row Viewings by appointment.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
