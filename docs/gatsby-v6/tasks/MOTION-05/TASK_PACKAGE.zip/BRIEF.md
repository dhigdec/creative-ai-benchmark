# Sterling Row - Residence launch film and viewing package

Sterling Row is nine full floor residences in a converted warehouse block, and we are opening the release on the broker's channel. The footage is honest about its limits: every supplied clip runs five seconds and carries no audio, so this is a short form package, not a long film. Build a restrained launch film and a vertical teaser for the channel, both carried by quiet on screen text rather than a voice. The interiors should stay warm against the blue hour glazing without drifting into a different colour world from shot to shot, and the building and residence details must stay truthful.

What we need back
- Residence launch film: 1 named export, 12 to 15 seconds, 16:9, under the supplied instrumental bed. It opens on the approved tagline, carries one residence fact card taken from the specification sheet, and closes on the viewing action.
- Residence vertical teaser: 1 named export, 6 to 8 seconds, 9:16, cut from the same material. The development identity is clear and the teaser ends on the viewing action.
- The still and print items in the register are unchanged: eight blue hour residence heroes, the residence viewing brochure and the residence film cover.

House rules for this package
- The approved viewing action is set exactly as: Viewings by appointment. It is the last thing on screen on both films.
- No narration. The broker's recorded read (sterlingrow_broker_read.wav) stays out of this cut; we would rather say less than lay a voice over five second clips. Both films run under the supplied bed, sterlingrow_bed.wav.
- On screen copy stays small and minimal, in the approved language only. Never say luxury lifestyle, act now, limited time or dream home, and never burn a price into a frame.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Live action edits require adequate distinct footage: looping one short clip is not a substitute for the missing coverage.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register. Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Retain eight residence hero images, a six-page viewing brochure and film cover alongside the two music-only films. Use the actual residence stills; do not invent a ninth residence photograph.
- Both films end with Viewings by appointment. The broker read is excluded, no speech is allowed, and no price is burned into a film frame. The supplied bed is sterlingrow_bed.wav.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
