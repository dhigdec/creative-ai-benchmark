# MOTION-08: delivery register

## Product demo master

- File: `deliverables/demo-master.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least four different supplied clips, the product name “SentinelMesh”, at least two claim cards taken word for word from rows marked Cleared in sentinelmesh_messaging.csv, and a closing card reading “Book a walkthrough”.

## Product demo feed cut

- File: `deliverables/demo-feed.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three different supplied clips, the product name “SentinelMesh” and one claim card taken word for word from a row marked Cleared in sentinelmesh_messaging.csv, over interface footage cropped to square.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
