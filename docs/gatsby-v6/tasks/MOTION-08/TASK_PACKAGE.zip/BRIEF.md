# SentinelMesh - Product demo and narration package

SentinelMesh is going in front of security buyers and we need the product cut. Be aware of what the pack actually holds: every supplied clip runs five seconds and none of them carry audio, so a narrated demonstration is not on the table. What we want is a short product film that lets the real screen captures do the work, with the cleared claims set as on screen text and enough time on each screen for a security engineer to read the interface detail that matters.

Please prepare
- Product demo master: 1 named export, 12 to 15 seconds, 16:9, under the supplied instrumental bed (sentinelmesh_bed.wav). The screen state on show must support the claim on screen at that moment, the claim wording must come from the cleared rows of the messaging sheet, and the film closes on the booking action.
- Product demo feed cut: 1 named export, 6 to 8 seconds, 1:1, silent, cut from the same material. The feature stays readable: crop the capture, never squeeze it.
- Product website band: 1 named export, unchanged from the register.
- Website feature panel: 1 named export, unchanged from the register.

House rules for this package
- No narration. The recorded read (sentinelmesh_vo.wav) stays out of these cuts, and no synthetic voice replaces it. The message is carried by on screen text.
- The approved closing action is set exactly as: Book a walkthrough. It is the last thing on screen on the master.
- Only rows marked Cleared in sentinelmesh_messaging.csv may appear on screen, word for word. The claim about cutting repeat risky behaviour by 60% is in legal review and must not appear anywhere.
- Precision over spectacle: no fear language, no exclamation, one idea per card.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Live action edits require adequate distinct footage: looping one short clip is not a substitute for the missing coverage.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register. Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- This edition commissions two non-narrated product demos. Earlier narration, website or static-collateral requests are withdrawn; the supplied messaging rows govern on-screen copy.
- Use actual supplied interface states. The one Signal Cyan cursor-rule and PP Formula/Whitney roles apply to new overlays. Deliver playable moving video, not a PDF storyboard.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
