# VECTOR-11: delivery register

## Farmers-market identity master

- File: `deliverables/market-mark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The source identity is preserved.

## Seasonal market poster

- File: `deliverables/season-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The market date is accurate. The location is readable.

## Market stall sign - 1 - Green Mountain Produce

- File: `deliverables/stall-sign-r002.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 2 - Willowbrook Bakery

- File: `deliverables/stall-sign-r003.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 3 - Two Ponds Flowers

- File: `deliverables/stall-sign-r004.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 4 - Cabot Ridge Cheese

- File: `deliverables/stall-sign-r005.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 5 - Sunfield Eggs

- File: `deliverables/stall-sign-r006.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 6 - Maple Hollow Sugarworks

- File: `deliverables/stall-sign-r007.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 7 - Birch & Bramble Preserves

- File: `deliverables/stall-sign-r008.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 8 - Stone Meadow Dairy

- File: `deliverables/stall-sign-r009.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 9 - Little Otter Coffee

- File: `deliverables/stall-sign-r010.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 10 - Ferncliff Mushrooms

- File: `deliverables/stall-sign-r011.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 11 - Red Wagon Vegetables

- File: `deliverables/stall-sign-r012.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 12 - Highfield Heritage Orchard & Cider Cooperative of Vermont

- File: `deliverables/stall-sign-r013.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 13 - Clover Lane Honey

- File: `deliverables/stall-sign-r014.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 14 - Trillium Herb Farm

- File: `deliverables/stall-sign-r015.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 15 - North Star Breads

- File: `deliverables/stall-sign-r016.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 16 - Painted Hills Pottery

- File: `deliverables/stall-sign-r017.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 17 - Quiet Brook Soap

- File: `deliverables/stall-sign-r018.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 18 - Alder Creek Meats

- File: `deliverables/stall-sign-r019.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 19 - Meadowlark Flowers

- File: `deliverables/stall-sign-r020.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 20 - Windfall Apples

- File: `deliverables/stall-sign-r021.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 21 - Sap Bucket Confections

- File: `deliverables/stall-sign-r022.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 22 - Rolling Thyme Kitchen

- File: `deliverables/stall-sign-r023.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 24 - Cornerstone Cheesemongers

- File: `deliverables/stall-sign-r026.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 25 - Blue Heron Fish

- File: `deliverables/stall-sign-r027.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 26 - Sugarhouse Sweets

- File: `deliverables/stall-sign-r028.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 27 - Bright Acre Greens

- File: `deliverables/stall-sign-r029.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 28 - Timber Line Woodcraft

- File: `deliverables/stall-sign-r030.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 29 - Foothill Berry Farm

- File: `deliverables/stall-sign-r031.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 30 - Wren's Nest Baking

- File: `deliverables/stall-sign-r032.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 31 - Silver Maple Syrup Co

- File: `deliverables/stall-sign-r033.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 32 - Stonewall Preserves

- File: `deliverables/stall-sign-r034.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 33 - Harvest Moon Flowers

- File: `deliverables/stall-sign-r035.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 34 - Otter Run Herbs

- File: `deliverables/stall-sign-r036.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 35 - Pine Barn Eggs

- File: `deliverables/stall-sign-r037.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 36 - Riverbend Roasters

- File: `deliverables/stall-sign-r038.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 37 - Golden Fields Grain

- File: `deliverables/stall-sign-r039.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 38 - Beaver Pond Honey

- File: `deliverables/stall-sign-r040.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 39 - Copper Kettle Kitchen

- File: `deliverables/stall-sign-r041.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 40 - Thistle & Vine Flowers

- File: `deliverables/stall-sign-r042.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 41 - Long Meadow Lamb

- File: `deliverables/stall-sign-r043.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 42 - Cedar Swamp Cranberries

- File: `deliverables/stall-sign-r044.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - 43 - Morningside Mushrooms

- File: `deliverables/stall-sign-r045.pdf`
- Specification: {"format":"pdf","width_mm":152.4,"height_mm":152.4,"pages":1,"template_reference":"cedar_commons_plate_card.pdf"}
- Content: The trader name matches this stall record. The sign is legible at the intended stall distance.

## Market stall sign - combined production run

- File: `deliverables/stall-sign-combined.pdf`
- Specification: {"format":"pdf","pages":42,"width_mm":152.4,"height_mm":152.4}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
