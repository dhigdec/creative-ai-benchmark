# Cedar Commons - Farmers market identity restoration

Recover the market's apron mark and prepare our site photographs

Hello from Cedar Commons. We help run the farmers' market, and the apron print is the version of our mark people recognise. Could you help us get it into a form we can place cleanly, without a box around it?

Final handoff

 Farmers-market identity master: 1 named export. The source identity is preserved.

 Seasonal market poster: 1 named export. The market date is accurate. The location is readable.

 Market stall sign: 43 named exports. The trader name matches this stall record. The sign is legible at the intended stall distance.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The approved trader records define the stall-sign run; the combined sign file follows individual-sign order. Recover the apron mark faithfully for reuse on poster and signs rather than resetting it in the new layout font.
- Flat inks, no tints and final-size lettering limits apply to the stall signs as well as the poster where printed. Trader names remain exact even when the layout must reflow.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
