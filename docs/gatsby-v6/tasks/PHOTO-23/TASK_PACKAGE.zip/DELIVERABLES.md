# PHOTO-23: delivery register

## Architectural foundry editorial feature

- File: `deliverables/foundry-feature.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The sequence explains the foundry's casting work. Tool and material detail remains credible.

## Foundry exhibition poster

- File: `deliverables/expo-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The architectural casting offer uses approved copy. The specifier contact is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
