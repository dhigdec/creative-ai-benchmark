# Ironline Forge - Blacksmith editorial image set

Foundry photographs for architects: one dark treatment, visible material

The furnace and rooflight give us two very different versions of Ironline Forge. We need an experienced retoucher to bring them together for architectural audiences and the expo.

Final handoff

 Architectural foundry editorial feature: 1 named export. The sequence explains the foundry's casting work. Tool and material detail remains credible.

 Foundry exhibition poster: 1 named export. The architectural casting offer uses approved copy. The specifier contact is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The feature uses the supplied foundry story and casting facts; the expo poster uses the supplied event/contact information. Recovery of the struck maker mark is not permission to replace its lettering with a similar font.
- Record the exact foundry photograph for each spread or poster placement and bind any named casting to its record. Protect the mark impression and the actual metal appearance.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
