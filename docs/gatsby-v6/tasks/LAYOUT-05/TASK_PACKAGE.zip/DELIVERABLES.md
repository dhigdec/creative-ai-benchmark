# LAYOUT-05: delivery register

## House-story presentation

- File: `deliverables/house-story.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":10}
- Content: The sequence communicates the house's approved story. The packaging shown matches the supplied artwork.

## House campaign poster

- File: `deliverables/campaign-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The campaign identifies Maison Valcere. The product remains recognisable.

## House campaign feed ad

- File: `deliverables/campaign-feed.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The approved message is readable. The brand treatment reflects the stated price position.

## House campaign story

- File: `deliverables/campaign-story.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The action line remains inside the safe area.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
