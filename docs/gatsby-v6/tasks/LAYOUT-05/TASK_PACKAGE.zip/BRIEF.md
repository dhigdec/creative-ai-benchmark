# Maison Valcere - Brand story deck and campaign document

An appointment-season story deck with a consistent jewellery image library

Maison Valcere needs its house-story and campaign documents ready for the autumn appointment season. The bench photography spans two sittings, and it does not yet sit together as a collection.

The commission

 House-story presentation: 1 named export. The sequence communicates the house's approved story. The packaging shown matches the supplied artwork.

 House campaign poster: 1 named export. The campaign identifies Maison Valcere. The product remains recognisable.

 House campaign feed ad: 1 named export. The approved message is readable. The brand treatment reflects the stated price position.

 House campaign story: 1 named export. The action line remains inside the safe area.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The house-story deck includes approved provenance and product information. The campaign poster, feed and story carry no price; the deck may show the approved retail prices beside their corresponding pieces.
- Preserve the approved accented brand spelling and the original wordmark geometry. New display type stays Light, and assay/provenance copy remains exact.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
