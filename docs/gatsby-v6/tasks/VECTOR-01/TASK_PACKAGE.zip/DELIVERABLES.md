# VECTOR-01: delivery register

## Recovered garment mark - Compass chest

- File: `deliverables/recovered-mark-compass-chest.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The geometry follows the authoritative source mark. The lettering is faithful to the source.

## Recovered garment mark - Overland badge

- File: `deliverables/recovered-mark-overland-badge.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The geometry follows the authoritative source mark. The lettering is faithful to the source.

## Recovered garment mark - Ridgeline back

- File: `deliverables/recovered-mark-ridgeline-back.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The geometry follows the authoritative source mark. The lettering is faithful to the source.

## Garment graphics application sheet

- File: `deliverables/graphics-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":3}
- Content: Placement scale matches the supplied garment constraints. The specified ink count is respected.

## Garment lookbook layout

- File: `deliverables/lookbook.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The garment and graphic relationship is visible. The identity is consistent with the recovered masters.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
