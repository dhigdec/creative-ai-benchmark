# Cordwain Overland - Identity master graphics

Recover three apparel graphics and prove they survive small reproduction

Cordwain has lost the working artwork for three overland graphics. We need a vector specialist who can recover what is actually in the references and make a useful garment-ready family, not deliver an unchecked automatic trace.

What we need back
- Recovered garment mark: 3 named exports. The geometry follows the authoritative source mark. The lettering is faithful to the source.
- Garment graphics application sheet: 1 named export. Placement scale matches the supplied garment constraints. The specified ink count is respected.
- Garment lookbook layout: 1 named export. The garment and graphic relationship is visible. The identity is consistent with the recovered masters.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Recover the three named garment marks from their individual sources and use them in the graphics sheet/lookbook. Source lettering is authoritative: do not reset it to match the new layout type card.
- Apply GT America/Atlas to added captions and layout text only. Dark-garment discharge restrictions and eligible inks come from the printer inkbook and the named garment application, not from the colours in a reference photograph.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
