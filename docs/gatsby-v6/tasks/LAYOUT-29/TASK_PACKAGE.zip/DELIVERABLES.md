# LAYOUT-29: delivery register

## Donor acknowledgement letter - Eleanor Pratt

- File: `deliverables/donor-letter-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Tom & Grace Hollister

- File: `deliverables/donor-letter-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Dr. Rosalind Featherstonehaugh-Wetherby

- File: `deliverables/donor-letter-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - John Aldercott

- File: `deliverables/donor-letter-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Margaret Aldercott

- File: `deliverables/donor-letter-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Warren Cobb

- File: `deliverables/donor-letter-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - The Merriwether Family

- File: `deliverables/donor-letter-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Mr. and Mrs. Prescott Vandeleur

- File: `deliverables/donor-letter-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Judge Harriet Ellsworth

- File: `deliverables/donor-letter-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Bartholomew Quiller

- File: `deliverables/donor-letter-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Sam & Dee Fenn

- File: `deliverables/donor-letter-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Priya & Alan Northcote

- File: `deliverables/donor-letter-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Constance Merryfield

- File: `deliverables/donor-letter-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Owen Trask

- File: `deliverables/donor-letter-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Marguerite L'Estrange-Postlethwaite

- File: `deliverables/donor-letter-r016.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Ted Ruddock

- File: `deliverables/donor-letter-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - The Halvorsen-Achterberg Household

- File: `deliverables/donor-letter-r018.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - Gil Overholt

- File: `deliverables/donor-letter-r019.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The salutation matches the donor record. The acknowledged amount is accurate.

## Donor acknowledgement letter - combined production run

- File: `deliverables/donor-letter-combined.pdf`
- Specification: {"format":"pdf","pages":18,"width_mm":210,"height_mm":297}
- Content: undefined

## Donation receipt - Eleanor Pratt

- File: `deliverables/receipt-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Tom & Grace Hollister

- File: `deliverables/receipt-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Dr. Rosalind Featherstonehaugh-Wetherby

- File: `deliverables/receipt-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - John Aldercott

- File: `deliverables/receipt-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Margaret Aldercott

- File: `deliverables/receipt-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Warren Cobb

- File: `deliverables/receipt-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - The Merriwether Family

- File: `deliverables/receipt-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Mr. and Mrs. Prescott Vandeleur

- File: `deliverables/receipt-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Judge Harriet Ellsworth

- File: `deliverables/receipt-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Bartholomew Quiller

- File: `deliverables/receipt-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Sam & Dee Fenn

- File: `deliverables/receipt-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Priya & Alan Northcote

- File: `deliverables/receipt-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Constance Merryfield

- File: `deliverables/receipt-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Owen Trask

- File: `deliverables/receipt-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Marguerite L'Estrange-Postlethwaite

- File: `deliverables/receipt-r016.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Ted Ruddock

- File: `deliverables/receipt-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - The Halvorsen-Achterberg Household

- File: `deliverables/receipt-r018.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - Gil Overholt

- File: `deliverables/receipt-r019.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The receipt date is accurate. The donor identity is unambiguous.

## Donation receipt - combined production run

- File: `deliverables/receipt-combined.pdf`
- Specification: {"format":"pdf","pages":18,"width_mm":210,"height_mm":297}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
