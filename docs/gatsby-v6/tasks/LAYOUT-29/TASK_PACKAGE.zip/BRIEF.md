# Rivermeadow Trust - Year-end donor acknowledgement system

Replace our manual year-end donor letters with a dependable reusable system

Rivermeadow Trust's office manager spent three weeks preparing acknowledgements last year, and two donors were still missed. We need this December's letters and receipts produced correctly, plus templates the office can reuse next year by changing the data.

The commission

 Donor acknowledgement letter: 19 named exports. The salutation matches the donor record. The acknowledged amount is accurate.

 Donation receipt: 19 named exports. The receipt date is accurate. The donor identity is unambiguous.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use approved household gift amounts, dates and giving-level rules. A letter and receipt are bound to the same household record; do not aggregate separate rows unless that approved record already does so.
- Editable letter and receipt source documents are included through the source handoff. The statutory receipt wording stays complete; the letter's acknowledgement copy is not a substitute for it.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
