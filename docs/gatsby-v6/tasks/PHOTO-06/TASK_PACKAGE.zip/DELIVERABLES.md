# PHOTO-06: delivery register

## Archival restoration master - hollis_scan_01

- File: `deliverables/restoration-hollis-scan-01.png`
- Specification: {"format":"png","source_dimensions":true,"width":2200,"height":3000}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_02

- File: `deliverables/restoration-hollis-scan-02.png`
- Specification: {"format":"png","source_dimensions":true,"width":2400,"height":3200}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_03

- File: `deliverables/restoration-hollis-scan-03.png`
- Specification: {"format":"png","source_dimensions":true,"width":2600,"height":3400}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_04

- File: `deliverables/restoration-hollis-scan-04.png`
- Specification: {"format":"png","source_dimensions":true,"width":3000,"height":4000}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_05

- File: `deliverables/restoration-hollis-scan-05.png`
- Specification: {"format":"png","source_dimensions":true,"width":3200,"height":4200}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_06

- File: `deliverables/restoration-hollis-scan-06.png`
- Specification: {"format":"png","source_dimensions":true,"width":2400,"height":3600}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_07

- File: `deliverables/restoration-hollis-scan-07.png`
- Specification: {"format":"png","source_dimensions":true,"width":2400,"height":3600}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_08

- File: `deliverables/restoration-hollis-scan-08.png`
- Specification: {"format":"png","source_dimensions":true,"width":2400,"height":3600}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Archival restoration master - hollis_scan_09

- File: `deliverables/restoration-hollis-scan-09.png`
- Specification: {"format":"png","source_dimensions":true,"width":2400,"height":3600}
- Content: The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.

## Family archive share image - hollis_scan_01

- File: `deliverables/share-hollis-scan-01.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_02

- File: `deliverables/share-hollis-scan-02.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_03

- File: `deliverables/share-hollis-scan-03.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_04

- File: `deliverables/share-hollis-scan-04.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_05

- File: `deliverables/share-hollis-scan-05.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_06

- File: `deliverables/share-hollis-scan-06.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_07

- File: `deliverables/share-hollis-scan-07.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_08

- File: `deliverables/share-hollis-scan-08.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.

## Family archive share image - hollis_scan_09

- File: `deliverables/share-hollis-scan-09.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The full intended picture area is retained. The tone remains appropriate to the photographic era.
