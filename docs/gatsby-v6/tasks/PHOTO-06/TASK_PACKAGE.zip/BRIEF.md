# Hollis Family Archive - Ada Hollis archival restoration

Help us prepare Ada's family photographs for the reunion

Hello,

Scope
1. Archival restoration master: 9 named exports. The sitter remains faithful to the source photograph. Documentary details are not invented. Damage removal does not erase facial texture.
2. Family archive share image: 9 named exports. The full intended picture area is retained. The tone remains appropriate to the photographic era.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Restoration masters and share JPEGs remain uncaptioned photographic files; they are not newly designed archive plates. Do not add the folio typography, plate numbers, logos or accession text to these photographs.
- Use the source-to-output mapping in the register. Preserve Ada's scar, original grain, deckled paper and historic pencil retouching; reconcile duplicate scans without treating them as new photographs. The archival typography card is reference-only for a future folio, not a scored requirement here.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
