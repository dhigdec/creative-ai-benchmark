# Halcyon Quarter - Mixed-use launch photography

Evening-led property campaign from an overcast shoot

Halcyon Quarter is a former ropeworks development. The audience is downsizers looking carefully at the place, not people buying a dramatic sky. Our capture day was overcast; the campaign needs a credible evening direction across very different placements.

Final handoff

 Halcyon Quarter launch hoarding: 1 named export. The development name is legible at the specified scale. The pictured building remains faithful to the supplied development image. The enquiry action is visible.

 Mixed-use launch poster: 1 named export. The residential and commercial offer is distinguishable. The developer identity is visible.

 Property portal campaign panel: 1 named export. The approved location appears correctly. The composition does not imply completed construction where the source is a proposal.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use a restrained exposure/colour treatment of the supplied building photographs; no replaced sky, invented landscaping or new building feature. A concept label is required on a conceptual evening-treatment layout, not on an unaltered documentary photograph.
- The hoarding uses halcyon_elevation_a.jpg. The poster and portal panel may choose an elevation from the named building set in their asset contracts; preserve the complete building features visible in the chosen view. Use the current approved unit records only. Brass is a flat palette colour, not metallic gold.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
