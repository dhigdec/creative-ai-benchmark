# PHOTO-05: delivery register

## Halcyon Quarter launch hoarding

- File: `deliverables/hoarding.pdf`
- Specification: {"format":"pdf","width_mm":1200,"height_mm":600,"pages":1}
- Content: The development name is legible at the specified scale. The pictured building remains faithful to the supplied development image. The enquiry action is visible.

## Mixed-use launch poster

- File: `deliverables/launch-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The residential and commercial offer is distinguishable. The developer identity is visible.

## Property portal campaign panel

- File: `deliverables/property-portal.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The approved location appears correctly. The composition does not imply completed construction where the source is a proposal.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
