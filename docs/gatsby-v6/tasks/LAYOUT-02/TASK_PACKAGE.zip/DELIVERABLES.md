# LAYOUT-02: delivery register

## Cold-case label - The Corner Reuben - Half

- File: `deliverables/cold-label-r002.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - The Corner Reuben - Whole

- File: `deliverables/cold-label-r003.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Pastrami on Rye - Whole

- File: `deliverables/cold-label-r004.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Turkey Club - Whole

- File: `deliverables/cold-label-r005.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Italian Hero - Whole

- File: `deliverables/cold-label-r006.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Chopped Cheese - Whole

- File: `deliverables/cold-label-r007.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Roast Beef Sandwich - Whole

- File: `deliverables/cold-label-r008.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Caprese Sandwich - Whole

- File: `deliverables/cold-label-r009.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Meatball Sub - Whole

- File: `deliverables/cold-label-r010.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Egg & Cheese Roll - Whole

- File: `deliverables/cold-label-r011.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Tuna Melt - Whole

- File: `deliverables/cold-label-r012.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - BLT - Whole

- File: `deliverables/cold-label-r013.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Buffalo Chicken Wrap - Whole

- File: `deliverables/cold-label-r014.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Chicken Grain Bowl - Regular

- File: `deliverables/cold-label-r015.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Cobb Salad Bowl - Regular

- File: `deliverables/cold-label-r016.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Falafel Bowl - Regular

- File: `deliverables/cold-label-r017.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Cold Cut Platter - Small

- File: `deliverables/cold-label-r018.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Cold Cut Platter - Large

- File: `deliverables/cold-label-r019.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - House Chicken Salad - 8 oz

- File: `deliverables/cold-label-r020.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - House Tuna Salad - 8 oz

- File: `deliverables/cold-label-r021.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Egg Salad - 8 oz

- File: `deliverables/cold-label-r022.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Macaroni Salad - 8 oz

- File: `deliverables/cold-label-r023.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Potato Salad - 8 oz

- File: `deliverables/cold-label-r024.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Coleslaw - 8 oz

- File: `deliverables/cold-label-r025.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Half-Sour Pickles - Each

- File: `deliverables/cold-label-r026.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Marinated Olives - 6 oz

- File: `deliverables/cold-label-r027.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Roasted Vegetables - 8 oz

- File: `deliverables/cold-label-r028.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Mozzarella & Tomato - 8 oz

- File: `deliverables/cold-label-r029.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Prosciutto - 4 oz

- File: `deliverables/cold-label-r030.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Sharp Provolone - 6 oz

- File: `deliverables/cold-label-r031.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Smoked Turkey Breast - 6 oz

- File: `deliverables/cold-label-r032.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Genoa Salami - 6 oz

- File: `deliverables/cold-label-r033.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Minestrone - Cup

- File: `deliverables/cold-label-r034.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Minestrone - Bowl

- File: `deliverables/cold-label-r035.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Chicken Noodle Soup - Cup

- File: `deliverables/cold-label-r036.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Rice Pudding - Cup

- File: `deliverables/cold-label-r037.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Black & White Cookie - Each

- File: `deliverables/cold-label-r038.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - Brooklyn Egg Cream - Each

- File: `deliverables/cold-label-r039.pdf`
- Specification: {"format":"pdf","width_mm":90.001,"height_mm":55.033,"pages":1,"template_reference":"cornerandcure_label_press.pdf"}
- Content: The allergen wording agrees with the approved item record. The item name is readable at label size.

## Cold-case label - combined production run

- File: `deliverables/cold-label-combined.pdf`
- Specification: {"format":"pdf","pages":38,"width_mm":90.001,"height_mm":55.033}
- Content: undefined

## Marketplace item tile - The Corner Reuben - Half

- File: `deliverables/market-tile-r002.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - The Corner Reuben - Whole

- File: `deliverables/market-tile-r003.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Pastrami on Rye - Whole

- File: `deliverables/market-tile-r004.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Turkey Club - Whole

- File: `deliverables/market-tile-r005.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Italian Hero - Whole

- File: `deliverables/market-tile-r006.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Chopped Cheese - Whole

- File: `deliverables/market-tile-r007.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Roast Beef Sandwich - Whole

- File: `deliverables/market-tile-r008.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Caprese Sandwich - Whole

- File: `deliverables/market-tile-r009.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Meatball Sub - Whole

- File: `deliverables/market-tile-r010.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Egg & Cheese Roll - Whole

- File: `deliverables/market-tile-r011.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Tuna Melt - Whole

- File: `deliverables/market-tile-r012.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - BLT - Whole

- File: `deliverables/market-tile-r013.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Buffalo Chicken Wrap - Whole

- File: `deliverables/market-tile-r014.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Chicken Grain Bowl - Regular

- File: `deliverables/market-tile-r015.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Cobb Salad Bowl - Regular

- File: `deliverables/market-tile-r016.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Falafel Bowl - Regular

- File: `deliverables/market-tile-r017.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Cold Cut Platter - Small

- File: `deliverables/market-tile-r018.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Cold Cut Platter - Large

- File: `deliverables/market-tile-r019.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - House Chicken Salad - 8 oz

- File: `deliverables/market-tile-r020.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - House Tuna Salad - 8 oz

- File: `deliverables/market-tile-r021.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Egg Salad - 8 oz

- File: `deliverables/market-tile-r022.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Macaroni Salad - 8 oz

- File: `deliverables/market-tile-r023.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Potato Salad - 8 oz

- File: `deliverables/market-tile-r024.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Coleslaw - 8 oz

- File: `deliverables/market-tile-r025.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Half-Sour Pickles - Each

- File: `deliverables/market-tile-r026.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Marinated Olives - 6 oz

- File: `deliverables/market-tile-r027.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Roasted Vegetables - 8 oz

- File: `deliverables/market-tile-r028.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Mozzarella & Tomato - 8 oz

- File: `deliverables/market-tile-r029.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Prosciutto - 4 oz

- File: `deliverables/market-tile-r030.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Sharp Provolone - 6 oz

- File: `deliverables/market-tile-r031.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Smoked Turkey Breast - 6 oz

- File: `deliverables/market-tile-r032.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Genoa Salami - 6 oz

- File: `deliverables/market-tile-r033.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Minestrone - Cup

- File: `deliverables/market-tile-r034.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Minestrone - Bowl

- File: `deliverables/market-tile-r035.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Chicken Noodle Soup - Cup

- File: `deliverables/market-tile-r036.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Rice Pudding - Cup

- File: `deliverables/market-tile-r037.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Black & White Cookie - Each

- File: `deliverables/market-tile-r038.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Marketplace item tile - Brooklyn Egg Cream - Each

- File: `deliverables/market-tile-r039.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The photograph shows the named item. The restaurant identity does not obscure the dish.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
