# Corner & Cure - Cold-case label system

Cold-case labels and ordering tiles from our cafe's existing materials

Our sign is painted on a board screwed to the wall. Most of the food photographs were taken on a phone over the counter. Corner & Cure needs someone who can work carefully with those materials and turn them into a practical, consistent set.

Final handoff

 Cold-case label: 39 named exports. The allergen wording agrees with the approved item record. The item name is readable at label size.

 Marketplace item tile: 38 named exports. The photograph shows the named item. The restaurant identity does not obscure the dish.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- This commission covers eligible item labels and marketplace tiles, plus the combined label file. The editable daily board in the earlier source note is not part of this delivery.
- Keep the full allergen wording, item/size and approved price. Uppercase styling changes letter case only, not wording. Recover the painted shop mark rather than replacing it with Vollkorn.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
