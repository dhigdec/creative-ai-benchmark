# LAYOUT-07: delivery register

## Agent open-house card - Dana Marsh

- File: `deliverables/agent-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.

## Agent open-house card - Theo Brandt

- File: `deliverables/agent-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.

## Agent open-house card - Colleen Vasquez

- File: `deliverables/agent-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.

## Agent open-house card - Raymond Okafor

- File: `deliverables/agent-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.

## Agent open-house card - Nadia Feldman

- File: `deliverables/agent-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.

## Agent open-house card - Gregory Lin

- File: `deliverables/agent-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.

## Agent open-house card - combined production run

- File: `deliverables/agent-card-combined.pdf`
- Specification: {"format":"pdf","pages":6,"width_mm":148,"height_mm":210}
- Content: undefined

## Open-house property presentation

- File: `deliverables/property-presentation.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The rooms are shown truthfully. The enquiry information is unambiguous.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
