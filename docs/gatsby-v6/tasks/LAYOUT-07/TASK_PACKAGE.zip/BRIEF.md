# Harbor Crest Realty - Open-house card campaign

Listing photography and six agent cards for 14 Marlowe Crescent

Harbor Crest Realty needs the house to look consistent across the listing and the open-house cards. The shooter has returned the rooms as captured; wall colour and window handling now vary from room to room.

Please prepare
- Agent open-house card: 7 named exports. The agent portrait matches the record. The property details match the fact sheet. The contact line is readable.
- Open-house property presentation: 1 named export. The rooms are shown truthfully. The enquiry information is unambiguous.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the current Marlowe property facts and the eligible agent roster. Individual agent cards and their combined file are distinct from the property presentation.
- The property image stays paired with the property, while each agent portrait stays paired with that agent. Preserve approved facts, price and contact details. The same property photo can legitimately recur across agent cards.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
