# PHOTO-02: delivery register

## Spring dish counter card - Burnt Butter Gnocchi

- File: `deliverables/dish-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Roast Squash & Farro Bowl

- File: `deliverables/dish-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Braised Short Rib Sandwich

- File: `deliverables/dish-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Charred Broccolini & Anchovy

- File: `deliverables/dish-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Chicken Milanese

- File: `deliverables/dish-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Spring Pea & Mint Risotto

- File: `deliverables/dish-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Grilled Hake & Salsa Verde

- File: `deliverables/dish-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - House Burger & Aged Cheddar

- File: `deliverables/dish-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Whipped Ricotta & Honey

- File: `deliverables/dish-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - Roast Carrots & Dukkah

- File: `deliverables/dish-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"dishcard_2025_print.pdf"}
- Content: The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

## Spring dish counter card - combined production run

- File: `deliverables/dish-card-combined.pdf`
- Specification: {"format":"pdf","pages":10,"width_mm":105.156,"height_mm":148.167}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
