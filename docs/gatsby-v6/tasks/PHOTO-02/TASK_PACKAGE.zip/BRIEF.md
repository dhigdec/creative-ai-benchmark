# Corner & Cure - Spring dish launch photography

Spring dish photography and a reusable printed card set for Corner & Cure

The spring dishes are ready. The photographs and printed cards are not. We run Corner & Cure, a neighbourhood cafe, and need someone comfortable moving between food retouching and small-format print production.

The commission

 Spring dish counter card: 11 named exports. The hero photograph shows the named dish. The dish description is readable at printed size. The plate retains natural food texture. The restaurant identity is visible.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the dine-in price, not the takeaway price. Dish-name wording is fixed, but the design deliberately renders it in lowercase; wording comparisons ignore this declared case change only. Keep descriptions and allergen wording unchanged.
- The combined card PDF follows the individual-card order. Ogg is for dish names and section headings; National 2 is for descriptions, allergens and prices. Grower credits are the only italic text.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
