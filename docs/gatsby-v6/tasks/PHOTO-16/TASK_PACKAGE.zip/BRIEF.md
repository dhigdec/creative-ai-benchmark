# SlabVault - Collectible card marketplace image system

Consignment listing photographs where the holder and label remain legible

SlabVault handles graded collectibles. A listing photograph has to show the item and the evidence around it: holder, label and seal. Glare is a problem in the current set, but we cannot replace unreadable information with a convincing guess.

Please prepare
- Collectible listing tile: 14 named exports. The pictured card and visible holder label match this lot record. Source condition defects remain visible.
- Collectible condition-detail tile: 14 named exports. The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Supply the registered front/detail pair for each eligible lot. The front view identifies the item; the detail view preserves the relevant condition evidence. Source blemishes may not be removed to improve a grade.
- Separate slab-case scratches from card damage when comparing the supplied views. New lot numbers use Redaction; certification digits use Söhne Mono. Printed type inside the original photographed slab is not retypeset.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
