# PHOTO-16: delivery register

## Collectible listing tile - LOT-001

- File: `deliverables/listing-front-r002.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-002

- File: `deliverables/listing-front-r003.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-003

- File: `deliverables/listing-front-r004.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-004

- File: `deliverables/listing-front-r005.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-005

- File: `deliverables/listing-front-r006.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-006

- File: `deliverables/listing-front-r007.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-007

- File: `deliverables/listing-front-r008.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-008

- File: `deliverables/listing-front-r009.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-009

- File: `deliverables/listing-front-r010.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-010

- File: `deliverables/listing-front-r011.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-011

- File: `deliverables/listing-front-r012.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-012

- File: `deliverables/listing-front-r013.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-013

- File: `deliverables/listing-front-r014.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible listing tile - LOT-014

- File: `deliverables/listing-front-r015.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The pictured card and visible holder label match this lot record. Source condition defects remain visible.

## Collectible condition-detail tile - LOT-001

- File: `deliverables/listing-detail-r002.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-002

- File: `deliverables/listing-detail-r003.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-003

- File: `deliverables/listing-detail-r004.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-004

- File: `deliverables/listing-detail-r005.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-005

- File: `deliverables/listing-detail-r006.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-006

- File: `deliverables/listing-detail-r007.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-007

- File: `deliverables/listing-detail-r008.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-008

- File: `deliverables/listing-detail-r009.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-009

- File: `deliverables/listing-detail-r010.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-010

- File: `deliverables/listing-detail-r011.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-011

- File: `deliverables/listing-detail-r012.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-012

- File: `deliverables/listing-detail-r013.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-013

- File: `deliverables/listing-detail-r014.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Collectible condition-detail tile - LOT-014

- File: `deliverables/listing-detail-r015.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The grader, grade and certification number appear in the caption block. The photograph does not imply a different grade.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
