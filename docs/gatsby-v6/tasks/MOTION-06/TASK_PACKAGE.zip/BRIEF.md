# Meridian Academy - Lesson video package

We are opening Lesson 4 of Operations Analytics for Working Managers to people who have not bought the course yet. The recorded lecture and screen captures we can hand over are five seconds each and none of them carry audio, so a narrated lesson excerpt is not something we can honestly ask for. What we want instead is a course teaser: a short, plain piece that shows the real screens and puts the teaching line on screen as text, the way a working manager watches video on a laptop at midnight with the sound off.

The commission

1. Course teaser: 1 named export, 12 to 15 seconds, 16:9, under the supplied instrumental bed (meridian_bed.wav). It names the lesson, states the topic, and carries two teaching lines lifted word for word from the approved caption sheet. The screen captures must stay readable: give a viewer time to see what is on the screen before the next cut.

2. Course teaser vertical cutdown: 1 named export, 6 to 8 seconds, 9:16, silent, cut from the same material. Set the landscape screen captures inside a framed panel on a brand ground rather than cropping into them, so the interface keeps its own proportions and stays legible upright.

3. Lesson cover: 1 named export, unchanged from the register.

House rules for this package

- No voice. Nothing in this package is narrated and no deliverable carries speech. The message is carried by on screen text you author from meridian_captions.csv and meridian_lesson4_outline.txt.
- Do not invent teaching copy. If a line is not in the approved caption sheet or the outline, it does not go on screen.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Live action edits require adequate distinct footage: looping one short clip is not a substitute for the missing coverage.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register. Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Retain the lesson cover alongside the two teasers. The wide teaser uses the approved captions at 12:05 and 14:20 in meridian_captions.csv, in that order. The vertical uses the 14:20 caption, Post each movement once, in date order. One line, one cause. Retain Lesson 4 and Reconciling the Numbers. Do not invent teaching copy.
- Larish Neue is the topic-heading family, replacing Tiempos. A deliberately cropped decorative lesson numeral is allowed; the actual lesson/topic and teaching text must remain complete. Landscape UI stays framed rather than cropped in the vertical.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
