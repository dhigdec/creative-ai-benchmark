# MOTION-06: delivery register

## Course teaser

- File: `deliverables/lesson.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least four different supplied clips, the label “Lesson 4”, the topic “Reconciling the Numbers”, and two teaching cards taken word for word from meridian_captions.csv, one of them “Post each movement once, in date order. One line, one cause.”

## Course teaser vertical cutdown

- File: `deliverables/lesson-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three different supplied clips, the topic “Reconciling the Numbers” on screen, with the screen captures set inside a framed panel so the interface keeps the proportions of the supplied recordings.

## Lesson 4 course cover

- File: `deliverables/lesson-cover.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Lesson 4 Reconciling the Numbers Operations Analytics for Working Managers

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
