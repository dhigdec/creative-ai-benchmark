# Halden Diaries - Season recap video package

We are closing season two of The Halden Diaries and we want the recap to feel like Nate's own channel, not a trailer bolted onto a quiet personal series. Two things have changed since the last brief. We are holding back the recap voiceover, so please do not cut to it and do not replace it with any other voice: the recap runs to the supplied instrumental bed with Nate's words set as on screen text, which is how most people meet the channel in a feed anyway. And we are keeping it short. Choose moments that add up to a season level story, give the edit a clear ending, and make the upright cut and the three episode covers belong to the same season.

Please prepare
- Season recap: 1 named export, 16:9, 12 to 15 seconds, instrumental bed only, no speech. The sequence reads as a season, episode titles appear as on screen text, and the film ends on a closing card.
- Vertical season recap: 1 named export, 9:16, 8 to 10 seconds, silent, no audio track at all. The story still holds in the shorter cut and every word of text sits inside the frame.
- Season episode cover: 3 named exports. The episode title, the date and the standfirst match the approved copy, and the channel address reads exactly as written.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Every film in this package is silent or carries the supplied instrumental bed only. There is no narration, no voice over and no spoken claim: the message is carried by on screen text that you set.
- Every supplied clip runs about five seconds. Each film must cut at least three distinct supplied shots, and no film may be padded by looping, freezing or slowing a single clip to reach its runtime.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The landscape recap uses the supplied instrumental bed only; the vertical is silent with no audio track. halden_recap_vo.wav is explicitly excluded and the old voiceover verifier is withdrawn.
- The three covers correspond to the first three source episode-copy records in order. Keep their titles, dates, standfirsts and www.haldendiaries.tv exact. Painted HALDEN is recovered artwork, not Avenir text.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
