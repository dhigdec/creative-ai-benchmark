# MOTION-14: delivery register

## Season recap

- File: `deliverables/season-recap.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three season two episode titles set as on screen text exactly as written in halden_episode_copy.txt, and a closing card carrying the channel address “www.haldendiaries.tv”. No spoken word anywhere.

## Vertical season recap

- File: `deliverables/recap-tall.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":10},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least two season two episode titles set as on screen text exactly as written in halden_episode_copy.txt, and the channel address “www.haldendiaries.tv” on the closing card. No audio track and no spoken word.

## Episode 1 cover - The good light in the morning

- File: `deliverables/episode-cover-episode-1.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The good light in the morning Sunday 1 March 2026 The kettle, the window, and twenty good minutes before anyone needed me. www.haldendiaries.tv

## Episode 2 cover - The long way to the post office

- File: `deliverables/episode-cover-episode-2.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The long way to the post office Sunday 8 March 2026 A parcel to post and no reason to hurry, so I didn't. www.haldendiaries.tv

## Episode 3 cover - Soup, because it rained

- File: `deliverables/episode-cover-episode-3.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Soup, because it rained Sunday 15 March 2026 It rained all day, so I made too much soup and regretted none of it. www.haldendiaries.tv

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
