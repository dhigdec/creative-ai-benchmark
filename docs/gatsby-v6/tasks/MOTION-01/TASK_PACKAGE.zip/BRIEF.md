# Ember and Oak - Restaurant launch reel system

We are opening the second room at Ember and Oak and we need a launch package that makes people hungry before they read a word. Everything the shoot left us is short and silent, five second takes off the pass and around the room, so treat this as a short form set rather than a film with a story to tell. The food leads: real char, visible texture, a room that feels alive. The message rides on type, not on a voice.

Please cut a 12 to 15 second launch reel in 16:9, built from at least five different takes, then an 8 to 10 second upright cutdown and a 6 to 8 second square bumper that each stand on their own rather than reading as a crop of the wide one. The upright keeps all type clear of the top 250 and bottom 320 pixels. Every film stays silent by our own choice, so the words have to carry it on screen. The closing card carries the mark, the line “Second room now open” and the booking action “Book a table”, designed as a card. Please do not drop the mark over the last available frame and call that an ending.

One correction to the manifest: emberoak_pass_call.mov has no audio despite the name. Treat it as b roll like the rest.

The rest of the package is unchanged. We still need the reel cover, the window poster and the three dish callout cards, with dish names, prices and allergen lines taken word for word from emberoak_menu_callouts.txt.

Production decisions for this edition
- Retain the reel cover, A2 window poster and three dish cards in addition to the three silent films. Dish records come from emberoak_menu_callouts.txt, including full allergen text and price.
- Use at least five distinct takes in the wide film. The vertical and square cuts remain separate silent edits. emberoak_pass_call.mov is silent b-roll. The closing card contains Second room now open and Book a table.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
