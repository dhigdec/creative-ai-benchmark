# MOTION-01: delivery register

## Restaurant launch reel

- File: `deliverables/launch.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least five different supplied clips, opening on food, and a designed closing card carrying the Ember and Oak mark, the line “Second room now open” and the booking action “Book a table”.

## Restaurant upright cutdown

- File: `deliverables/vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":10},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least four different supplied clips, the Ember and Oak mark, and the booking action “Book a table” set clear of the top 250 and bottom 320 pixels.

## Restaurant square bumper

- File: `deliverables/square.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three different supplied clips and a closing card showing the Ember and Oak mark with the line “Second room now open”.

## Second room reel cover

- File: `deliverables/reel-cover.png`
- Specification: {"format":"png","width":1080,"height":1920}
- Content: Second room now open Book a table

## Second room window poster

- File: `deliverables/window-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: Second room now open Book a table

## Dish callout - The Hearth Chop

- File: `deliverables/dish-callout-1.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The Hearth Chop - $36 Allergens: cooked over open flame. No nuts, no dairy in the dish.

## Dish callout - Wood-Fired Half Chicken

- File: `deliverables/dish-callout-2.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Wood-Fired Half Chicken - $28 Allergens: no nuts, no dairy in the dish.

## Dish callout - Fire Porterhouse, for two

- File: `deliverables/dish-callout-3.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Fire Porterhouse, for two - $38 Allergens: cooked over open flame. No nuts, no dairy in the dish.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
