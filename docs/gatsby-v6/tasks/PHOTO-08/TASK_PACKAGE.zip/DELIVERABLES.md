# PHOTO-08: delivery register

## Vehicle sales card - M3082

- File: `deliverables/vehicle-card-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

## Vehicle sales card - M3091

- File: `deliverables/vehicle-card-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

## Vehicle sales card - M2417

- File: `deliverables/vehicle-card-r004.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

## Vehicle sales card - M3105

- File: `deliverables/vehicle-card-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

## Vehicle sales card - M2471

- File: `deliverables/vehicle-card-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

## Vehicle sales card - M3119

- File: `deliverables/vehicle-card-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

## Forecourt inventory campaign

- File: `deliverables/inventory-campaign.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The dealership name is clear. The campaign uses vehicles present in the intake register.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
