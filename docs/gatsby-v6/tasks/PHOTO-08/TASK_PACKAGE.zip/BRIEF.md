# Meridian Motors - Showroom vehicle image system

Standardise a used-car photo set without changing the cars

We photograph stock in three different bays at Meridian Motors. That is showing up in our listings: the same forecourt can look like three dealerships, and paint colours move around with the light.

The commission

 Vehicle sales card: 6 named exports. The vehicle photograph matches this stock record. The vehicle condition is not misrepresented by retouching. The enquiry action is readable.

 Forecourt inventory campaign: 1 named export. The dealership name is clear. The campaign uses vehicles present in the intake register.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- These are dealership-owned designed sales cards and a campaign panel, not marketplace primary photographs. Marketplace-only no-graphics and primary-image export requests are outside this commission.
- Bind the named vehicle, stock ID, certification tier and disclosure to its approved intake row. Keep paint and condition truthful. Use the current Publico/Source Sans role table for new text, replacing the older generic sans dealership-name rule.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
