# PHOTO-19: delivery register

## Summit speaker card - Marguerite Halloran

- File: `deliverables/speaker-card-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Peter Vance

- File: `deliverables/speaker-card-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Ines Moreau

- File: `deliverables/speaker-card-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Anders Lindqvist

- File: `deliverables/speaker-card-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Colm Byrne

- File: `deliverables/speaker-card-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Dana Whitfield

- File: `deliverables/speaker-card-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Estelle Rioux

- File: `deliverables/speaker-card-r009.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Grant Mackey

- File: `deliverables/speaker-card-r010.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Sofia Bellini

- File: `deliverables/speaker-card-r011.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Nils Haugen

- File: `deliverables/speaker-card-r013.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Robin Tate

- File: `deliverables/speaker-card-r014.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Bernadette Cruz

- File: `deliverables/speaker-card-r015.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Hugo Almeida

- File: `deliverables/speaker-card-r016.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Karin Voss

- File: `deliverables/speaker-card-r017.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Laurel Beckett

- File: `deliverables/speaker-card-r018.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Owen Faraday

- File: `deliverables/speaker-card-r019.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Mireille Dufort

- File: `deliverables/speaker-card-r020.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit speaker card - Jonah Pryce

- File: `deliverables/speaker-card-r021.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.

## Summit announcement

- File: `deliverables/summit-announcement.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The event name is clear. The approved date is visible. The registration action is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
