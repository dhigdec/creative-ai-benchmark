# Cascadia Founders Summit - Executive portrait set

Conference speaker portraits from eighteen very different submissions

Our Cascadia Founders Summit speakers have sent their own photographs. They need to sit together in the programme, in tight squares and on wide stage screens. Please make them look like one event without making the people look alike.

What we need back
- Summit speaker card: 18 named exports. The portrait belongs to the named speaker. The role is readable at mobile size. The summit identity is visible.
- Summit announcement: 1 named export. The event name is clear. The approved date is visible. The registration action is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Deliver the speaker cards and announcement named in the register. Separate transparent stage portraits and programme-photo exports from the older placement note are not additional outputs.
- Use the approved speaker record and matching portrait for each card. The announcement may use eligible speakers from the same set, with every chosen portrait named. Preserve speaker-role wording and use one consistent approved portrait ground.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
