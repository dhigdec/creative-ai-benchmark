# PHOTO-14: delivery register

## Industrial SKU plate - GM-4120

- File: `deliverables/sku-plate-r002.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-3312

- File: `deliverables/sku-plate-r003.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-2075

- File: `deliverables/sku-plate-r004.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-1180

- File: `deliverables/sku-plate-r005.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-5540

- File: `deliverables/sku-plate-r006.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-5560

- File: `deliverables/sku-plate-r007.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-6210

- File: `deliverables/sku-plate-r008.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-7010

- File: `deliverables/sku-plate-r009.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-7400

- File: `deliverables/sku-plate-r010.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-8130

- File: `deliverables/sku-plate-r011.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-8850

- File: `deliverables/sku-plate-r012.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU plate - GM-9200

- File: `deliverables/sku-plate-r013.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

## Industrial SKU cutout - GM-4120

- File: `deliverables/sku-cutout-r002.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-3312

- File: `deliverables/sku-cutout-r003.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-2075

- File: `deliverables/sku-cutout-r004.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-1180

- File: `deliverables/sku-cutout-r005.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-5540

- File: `deliverables/sku-cutout-r006.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-5560

- File: `deliverables/sku-cutout-r007.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-6210

- File: `deliverables/sku-cutout-r008.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-7010

- File: `deliverables/sku-cutout-r009.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-7400

- File: `deliverables/sku-cutout-r010.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-8130

- File: `deliverables/sku-cutout-r011.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-8850

- File: `deliverables/sku-cutout-r012.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Industrial SKU cutout - GM-9200

- File: `deliverables/sku-cutout-r013.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The silhouette preserves all functional holes. The edge has no visible halo.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
