# Girdermark - Industrial component image system

Catalogue-ready component photography, including difficult internal openings

Girdermark sells replacement components. A buyer needs to recognise the finish and the shape, not admire a dramatic studio treatment. Our twelve components were photographed over two bench sessions and need a consistent technical presentation.

The commission

 Industrial SKU plate: 12 named exports. The part geometry agrees with the source component. Source wear, machining marks and identification defects are not retouched away.

 Industrial SKU cutout: 12 named exports. The silhouette preserves all functional holes. The edge has no visible halo.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- SKU plates carry the part number, part name and approved technical fields. Transparent cutouts contain the isolated part only, with no added caption or mark.
- Use the same approved part/finish image for a plate and its cutout. Inspect cutout edges on white and #202020 grounds; neither ground becomes part of the transparent file. Apply the Cinzel/Plex role rules to plates only.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
