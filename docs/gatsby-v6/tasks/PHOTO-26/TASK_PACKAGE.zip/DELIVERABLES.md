# PHOTO-26: delivery register

## Autumn interiors collection spread

- File: `deliverables/collection-spread.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The textiles preserve their source patterns. The styled grouping feels coherent.

## Interiors wholesale presentation

- File: `deliverables/wholesale-presentation.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":8}
- Content: Each featured object has its correct product name. The page sequence supports a trade buying conversation.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
