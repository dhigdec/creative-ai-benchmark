# Thornmere Home - Autumn interiors image system

Wholesale product images that keep indigo and reactive glaze honest

Our homeware photographs were made under two lighting rigs. Thornmere needs the twenty ceramic and textile pieces to work as a range, both in retailer tiles and on a coloured wholesale band.

The commission

 Autumn interiors collection spread: 1 named export. The textiles preserve their source patterns. The styled grouping feels coherent.

 Interiors wholesale presentation: 1 named export. Each featured object has its correct product name. The page sequence supports a trade buying conversation.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The spread and presentation use the eligible autumn SKU range and its exact wholesale prices/care wording. Product placement and page grouping are open art-direction choices, but the selected product/source association is recorded per page.
- V6 adopts the displayed type-scale values as benchmark production defaults rather than claiming those values came from the original client. Preserve the Druk product-name treatment and Graphik care/price roles.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
