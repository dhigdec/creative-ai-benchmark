# LAYOUT-16: delivery register

## Opening-roster athlete card - Rosa Delgado

- File: `deliverables/athlete-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Theo Marsh

- File: `deliverables/athlete-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Priya Nair

- File: `deliverables/athlete-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Cal Whitaker

- File: `deliverables/athlete-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Nadia Boone

- File: `deliverables/athlete-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Sam Okafor

- File: `deliverables/athlete-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Lena Fischer

- File: `deliverables/athlete-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Marcus Reyes

- File: `deliverables/athlete-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Dot Kalinowski

- File: `deliverables/athlete-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Jonah Pryce

- File: `deliverables/athlete-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Bex Holloway

- File: `deliverables/athlete-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Reggie Tran

- File: `deliverables/athlete-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Grace Amadi

- File: `deliverables/athlete-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Wyatt Cole

- File: `deliverables/athlete-card-r015.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Fiona Walsh

- File: `deliverables/athlete-card-r016.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - Elena Sokolova

- File: `deliverables/athlete-card-r017.pdf`
- Specification: {"format":"pdf","width_mm":127,"height_mm":178.139,"pages":1,"template_reference":"meetcard_press.pdf"}
- Content: The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.

## Opening-roster athlete card - combined production run

- File: `deliverables/athlete-card-combined.pdf`
- Specification: {"format":"pdf","pages":16,"width_mm":127,"height_mm":178.139}
- Content: undefined

## Opening gym spotlight - Community

- File: `deliverables/spotlight-community.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The gym identity is visible. The opening message follows approved copy.

## Opening gym spotlight - Coaching

- File: `deliverables/spotlight-coaching.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The gym identity is visible. The opening message follows approved copy.

## Opening gym spotlight - Training

- File: `deliverables/spotlight-training.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The gym identity is visible. The opening message follows approved copy.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
