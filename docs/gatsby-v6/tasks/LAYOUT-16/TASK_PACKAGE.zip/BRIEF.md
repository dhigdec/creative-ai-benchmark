# Anvil and Oak - Gym opening member collateral

Athlete cards and spotlight portraits for our gym opening

Anvil and Oak needs opening-roster cards and a consistent portrait set. Sixteen members were photographed across three evenings, and the colour differences are obvious when the portraits sit on our dark ground.

What we need back
- Opening-roster athlete card: 17 named exports. The portrait belongs to the named athlete. The squat, bench and deadlift figures match this athlete record.
- Opening gym spotlight: 3 named exports. The gym identity is visible. The opening message follows approved copy.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Reggie Tran's consent withdrawal applies to athlete cards, spotlights and group imagery. The three spotlights may select consenting athletes from the register, with the athlete, portrait and approved lift figure named for each.
- Keep the supplied units and personal data. Use the reversed display, numeric roles and Brass rule only on the corresponding designed elements; no positive tracking is introduced.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
