# OSTRA - Restaurant plate photography system

OSTRA tasting-menu images: dark, precise and still appetising

OSTRA is a 22-seat tasting counter. We have thirteen plate photographs from two services, and we need them to feel like the same room and the same menu. Dark should not mean muddy; glaze and food texture still need to read.

Deliverables
1. Seasonal menu announcement: 1 named export. OSTRA is identified. The featured dish agrees with the seasonal menu. The reservation action is visible.
2. Booking-page dish tile: 13 named exports. The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.
3. Reservation story: 1 named export. The booking action sits within the defined safe area. The restaurant name is readable at mobile size.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The delivered scope is the menu announcement, the named dish tiles and one reservation story; older wine-pairing cards and printed dining covers are not required. Dish names retain the kitchen's spelling and the source row association.
- Use one plate per dish tile. The announcement and reservation story may each choose one dish from the eligible set, with its exact source file and dish name recorded. Reservation-story critical text stays 250 px below the top and 320 px above the bottom.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
