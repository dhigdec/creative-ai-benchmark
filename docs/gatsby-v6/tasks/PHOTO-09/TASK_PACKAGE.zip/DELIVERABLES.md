# PHOTO-09: delivery register

## Seasonal menu announcement

- File: `deliverables/menu-launch.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: OSTRA is identified. The featured dish agrees with the seasonal menu. The reservation action is visible.

## Booking-page dish tile - ostra_service_one_01

- File: `deliverables/menu-tile-ostra-service-one-01.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_one_02

- File: `deliverables/menu-tile-ostra-service-one-02.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_one_03

- File: `deliverables/menu-tile-ostra-service-one-03.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_one_04

- File: `deliverables/menu-tile-ostra-service-one-04.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_one_05

- File: `deliverables/menu-tile-ostra-service-one-05.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_one_06

- File: `deliverables/menu-tile-ostra-service-one-06.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_one_07

- File: `deliverables/menu-tile-ostra-service-one-07.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_two_01

- File: `deliverables/menu-tile-ostra-service-two-01.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_two_02

- File: `deliverables/menu-tile-ostra-service-two-02.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_two_03

- File: `deliverables/menu-tile-ostra-service-two-03.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_two_04

- File: `deliverables/menu-tile-ostra-service-two-04.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_two_05

- File: `deliverables/menu-tile-ostra-service-two-05.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Booking-page dish tile - ostra_service_two_06

- File: `deliverables/menu-tile-ostra-service-two-06.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The caption correctly identifies the pictured dish. The food is recognisable at mobile listing size.

## Reservation story

- File: `deliverables/reservation-story.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The booking action sits within the defined safe area. The restaurant name is readable at mobile size.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
