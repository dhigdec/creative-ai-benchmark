# Maison Serault - Wordmark and monogram master set

Recover our jewellery wordmark from three disagreeing references

Maison Serault has three captures of the existing wordmark and monogram. They disagree in apparent colour and weight. We need a careful reconstruction of the identity, not an average of three photographs.

What we need back
- Maison Serault wordmark: 1 named export. The lettering preserves the authoritative source. Optical spacing is balanced at packaging size.
- Maison Serault monogram: 1 named export. The approved letter structure is preserved. The mark remains readable at its smallest application.
- Collection packaging label: 1 named export. The product naming follows the approved collection. The finish treatment respects supplier limits.
- House stationery application: 1 named export. The brand name is readable. The layout leaves practical writing space.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the source precedence and retained geometry specified in the supplier/copy materials; an abandoned reference number is excluded. Packaging and stationery reuse the delivered master rather than a new redraw.
- Never outline Marian means no decorative outline/stroke effect. Converting approved lettering to filled vector paths for manufacture is allowed. Foil and engraving clearances are checked on their own applications, not as one general visual-quality test.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
