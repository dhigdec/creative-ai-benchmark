# VECTOR-13: delivery register

## Maison Serault wordmark

- File: `deliverables/wordmark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The lettering preserves the authoritative source. Optical spacing is balanced at packaging size.

## Maison Serault monogram

- File: `deliverables/monogram.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The approved letter structure is preserved. The mark remains readable at its smallest application.

## Collection packaging label

- File: `deliverables/pack-label.pdf`
- Specification: {"format":"pdf","width_mm":99.822,"height_mm":69.85,"pages":1,"template_reference":"serault_enclosure_card_press.pdf"}
- Content: The product naming follows the approved collection. The finish treatment respects supplier limits.

## House stationery application

- File: `deliverables/stationery.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The brand name is readable. The layout leaves practical writing space.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
