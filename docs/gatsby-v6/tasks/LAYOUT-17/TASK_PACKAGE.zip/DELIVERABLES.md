# LAYOUT-17: delivery register

## Product roll label - AG-G-24

- File: `deliverables/roll-label-r002.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-G-30

- File: `deliverables/roll-label-r003.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-G-36

- File: `deliverables/roll-label-r004.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-G-48

- File: `deliverables/roll-label-r005.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GP-24

- File: `deliverables/roll-label-r006.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GP-30

- File: `deliverables/roll-label-r007.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GP-36

- File: `deliverables/roll-label-r008.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GP-48

- File: `deliverables/roll-label-r009.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GE-30

- File: `deliverables/roll-label-r010.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GE-36

- File: `deliverables/roll-label-r011.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GE-48

- File: `deliverables/roll-label-r012.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - AG-GE-60

- File: `deliverables/roll-label-r013.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":152.4,"pages":1,"template_reference":"rolllabel_2025_PRINT.pdf"}
- Content: The tier is identified accurately. The complete warranty_statement remains inside the label trim.

## Product roll label - combined production run

- File: `deliverables/roll-label-combined.pdf`
- Specification: {"format":"pdf","pages":12,"width_mm":101.6,"height_mm":152.4}
- Content: undefined

## Dealer range brochure

- File: `deliverables/dealer-collateral.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The product tiers are easy to compare. The uses are supported by the approved range data.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
