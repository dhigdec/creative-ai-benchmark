# Apexguard - Product label and dealer collateral system

Dealer-ready roll labels and bay imagery for Apexguard

Our dealer meetings need a reliable label system, not another set of labels assembled one by one. Apexguard has three tiers that should read as one family, and the current stock export must control the product information.

The commission

 Product roll label: 13 named exports. The tier is identified accurately. The complete warranty_statement remains inside the label trim.

 Dealer range brochure: 1 named export. The product tiers are easy to compare. The uses are supported by the approved range data.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the approved values in the output register for SKU/tier/spec fields, retaining raw export values only as provenance. The dealer collateral covers the eligible label range.
- Do not infer a technical value from a package photograph. Newly typeset figures/units follow their stated size relationship and numeric roles; label colour does not change the actual photographed product.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
