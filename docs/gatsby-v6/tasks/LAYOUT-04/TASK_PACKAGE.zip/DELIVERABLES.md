# LAYOUT-04: delivery register

## Wholesale capsule lookbook

- File: `deliverables/lookbook.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":12}
- Content: Styles are identified accurately. The page sequence supports wholesale selection.

## Garment hang tag - Fell Overshirt

- File: `deliverables/hang-tag-r002.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Yard Chore Coat

- File: `deliverables/hang-tag-r003.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Range Shirt Jacket

- File: `deliverables/hang-tag-r004.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Forge Flannel Shirt

- File: `deliverables/hang-tag-r005.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Bench Henley

- File: `deliverables/hang-tag-r006.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Mill Pocket Tee

- File: `deliverables/hang-tag-r007.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Kestrel Club Jersey

- File: `deliverables/hang-tag-r008.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Drover Knit

- File: `deliverables/hang-tag-r009.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Cutter Waistcoat

- File: `deliverables/hang-tag-r010.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - Anvil Work Trouser

- File: `deliverables/hang-tag-r011.pdf`
- Specification: {"format":"pdf","width_mm":55.033,"height_mm":90.001,"pages":1,"template_reference":"northgrove_hangtag.pdf"}
- Content: The garment facts match this style. The care wording remains readable at tag size.

## Garment hang tag - combined production run

- File: `deliverables/hang-tag-combined.pdf`
- Specification: {"format":"pdf","pages":10,"width_mm":55.033,"height_mm":90.001}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
