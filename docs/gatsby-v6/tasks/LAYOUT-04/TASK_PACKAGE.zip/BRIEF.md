# Northgrove - Wholesale lookbook and hang-tag system

A ten-look wholesale hang-tag run with properly matched product photography

Northgrove's fall capsule is heading to stockists. Our immediate need is a dependable hang-tag pack: the correct piece, its own image and the full make note on every card. The photography comes from two mornings that do not yet look like the same collection.

What we need back
- Wholesale capsule lookbook: 1 named export. Styles are identified accurately. The page sequence supports wholesale selection.
- Garment hang tag: 11 named exports. The garment facts match this style. The care wording remains readable at tag size.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the eligible line-sheet styles for the hang tags and wholesale lookbook. The lookbook follows style order; the source handoff includes editable tag/lookbook documents for future updates.
- Recover the Kestrel Lane crest as artwork. Literata/Freight governs new words only; it does not authorize retypesetting the crest or changing its details.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
