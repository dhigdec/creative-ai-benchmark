# PHOTO-01: delivery register

## Skincare product-page module - Clarity Vitamin C Serum

- File: `deliverables/pdp-r002.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Even Niacinamide Serum

- File: `deliverables/pdp-r003.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Reservoir Hyaluronic Serum (30ml frosted)

- File: `deliverables/pdp-r004.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Renew Retinol Night Oil

- File: `deliverables/pdp-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Barrier Peptide Moisturizer

- File: `deliverables/pdp-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Gentle Amino Cleanser

- File: `deliverables/pdp-r007.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Refine Exfoliating Toner

- File: `deliverables/pdp-r008.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare product-page module - Barrier Repair Cream

- File: `deliverables/pdp-r009.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.

## Skincare range launch key visual

- File: `deliverables/range-launch.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The composition identifies Aurelian Skin. The cleared launch claim is reproduced without a stronger efficacy claim. The product range is the primary visual focus.

## Retailer launch carousel - Page 1

- File: `deliverables/retailer-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The opening page identifies the range. The closing page presents the approved shopping action. The product sequence has a clear narrative.

## Retailer launch carousel - Page 2

- File: `deliverables/retailer-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The opening page identifies the range. The closing page presents the approved shopping action. The product sequence has a clear narrative.

## Retailer launch carousel - Page 3

- File: `deliverables/retailer-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The opening page identifies the range. The closing page presents the approved shopping action. The product sequence has a clear narrative.

## Retailer launch carousel - Page 4

- File: `deliverables/retailer-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The opening page identifies the range. The closing page presents the approved shopping action. The product sequence has a clear narrative.

## Retailer launch carousel - Page 5

- File: `deliverables/retailer-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The opening page identifies the range. The closing page presents the approved shopping action. The product sequence has a clear narrative.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
