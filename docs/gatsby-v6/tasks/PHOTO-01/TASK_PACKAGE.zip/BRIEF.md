# Aurelian Skin - Ecommerce skincare image system

Make eight skincare products look like one launch, not eight shoots

Our launch range needs to look as considered online as it does on the shelf. At the moment the eight bottles look as though they belong to different brands.

What we need back
- Skincare product-page module: 8 named exports. The photograph shows the product named on this module. The bottle label remains legible at the delivered size. The product benefit is visually subordinate to the product name.
- Skincare range launch key visual: 1 named export. The composition identifies Aurelian Skin. The cleared launch claim is reproduced without a stronger efficacy claim. The product range is the primary visual focus.
- Retailer launch carousel: 5 named exports. The opening page identifies the range. The closing page presents the approved shopping action. The product sequence has a clear narrative.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The eight approved product records remain the range. The range-launch visual includes the range; carousel pages follow the product order in the output register. Use the assigned product records for the pictured packs and their claims. The closing carousel page uses the CTA Shop the range.
- Product names use Signifier Light; the cleared claim is Signifier Light too. The older sans-only non-wordmark instruction is withdrawn. Barrier Repair Cream has no supplied macro: do not invent one.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
