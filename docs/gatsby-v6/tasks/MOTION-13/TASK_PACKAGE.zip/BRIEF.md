# Emberline - Food channel thumbnail and motion package

Emberline needs the promo package for tomorrow's programme, and this time we are cutting it for the way people actually watch us: short, in the feed, with the sound off. Do not build the promo around the host's spoken introduction. Carry the whole message in on screen text over the instrumental bed we supply, keep the host warm and present, keep the gratin appetising, and follow the approved rundown order so the viewer understands what is on the programme. We still want a system the team can reach again tomorrow without every episode looking identical.

Deliverables
1. Food-show programme promo: 1 named export, 16:9, 12 to 15 seconds, instrumental bed only, no speech. The shot order follows the approved rundown, and the show name, the dish name and the strap line appear as on screen text.
2. Food-show vertical promo: 1 named export, 9:16, 6 to 8 seconds, instrumental bed only, no speech. The featured dish stays recognisable and every word of text sits inside the frame.
3. Food-show thumbnail: 1 named export. The show name is readable at full export size.
4. Programme segment card: 9 named exports. If the record names a supplied picture, that picture appears on the card, otherwise the card contains no invented image.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
- Video delivery means a playable MP4, not a storyboard, still montage PDF or editing log. Every film in this package is silent or carries the supplied instrumental bed only. There is no narration, no voice over and no spoken claim: the message is carried by on screen text that you set.
- Every supplied clip runs about five seconds. Each film must cut at least three distinct supplied shots, and no film may be padded by looping, freezing or slowing a single clip to reach its runtime.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the current Optima/Omnes role table, replacing the older soft-slab direction. The nine segment cards follow the supplied rundown order and their matching keyframes.
- Keep the opening market footage and segment/food identity attached to the correct portion of the programme. The source show mark is recovered artwork, not a new type treatment.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
