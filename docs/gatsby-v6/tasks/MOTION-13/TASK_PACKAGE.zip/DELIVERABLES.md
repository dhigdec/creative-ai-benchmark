# MOTION-13: delivery register

## Food-show programme promo

- File: `deliverables/food-promo.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: On screen text carrying the show name “Emberline”, the dish name “White bean and rosemary gratin” and the strap line “A good kitchen, every day.”, cut over shots ordered to the running order in emberline_rundown.md, opening on the market and closing on the endboard. No spoken word anywhere.

## Food-show vertical promo

- File: `deliverables/promo-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: On screen text carrying the show name “Emberline” and the strap line “A good kitchen, every day.”, with the plated white bean and rosemary gratin visible on screen. No spoken word anywhere.

## Food-show thumbnail

- File: `deliverables/show-thumbnail.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The programme title is readable.

## Programme segment card - 1

- File: `deliverables/programme-card-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 2

- File: `deliverables/programme-card-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 3

- File: `deliverables/programme-card-r004.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 4

- File: `deliverables/programme-card-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 5

- File: `deliverables/programme-card-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 6

- File: `deliverables/programme-card-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 7

- File: `deliverables/programme-card-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 8

- File: `deliverables/programme-card-r009.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Programme segment card - 9

- File: `deliverables/programme-card-r010.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
