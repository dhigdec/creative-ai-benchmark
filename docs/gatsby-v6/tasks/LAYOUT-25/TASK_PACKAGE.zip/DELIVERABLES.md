# LAYOUT-25: delivery register

## Personalised autumn renewal mailer - Mr. and Mrs. Alden Frost

- File: `deliverables/renewal-mailer-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Ruth Beals

- File: `deliverables/renewal-mailer-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Harmon Family

- File: `deliverables/renewal-mailer-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Wendell and Marie Coburn

- File: `deliverables/renewal-mailer-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - George Tewksbury

- File: `deliverables/renewal-mailer-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Lorraine Pike

- File: `deliverables/renewal-mailer-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Everett Blodgett

- File: `deliverables/renewal-mailer-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Sylvia Rowell

- File: `deliverables/renewal-mailer-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Fournier Family

- File: `deliverables/renewal-mailer-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Carl and Dot Aiken

- File: `deliverables/renewal-mailer-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Harriet Stoddard

- File: `deliverables/renewal-mailer-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Norman Locke

- File: `deliverables/renewal-mailer-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Dana Urie

- File: `deliverables/renewal-mailer-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Pearl Hutchins

- File: `deliverables/renewal-mailer-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Sanville Family

- File: `deliverables/renewal-mailer-r016.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Elmer and Faye Batchelder

- File: `deliverables/renewal-mailer-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Gladys Perry

- File: `deliverables/renewal-mailer-r018.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Silas Wheelock

- File: `deliverables/renewal-mailer-r019.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Ada Chamberlin

- File: `deliverables/renewal-mailer-r020.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Randall Family

- File: `deliverables/renewal-mailer-r021.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Clifford and June Morrill

- File: `deliverables/renewal-mailer-r022.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Bernice Trombley

- File: `deliverables/renewal-mailer-r023.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Walter Kittredge

- File: `deliverables/renewal-mailer-r024.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Otis Fairbanks

- File: `deliverables/renewal-mailer-r025.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Miriam Choate

- File: `deliverables/renewal-mailer-r026.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Bagley Family

- File: `deliverables/renewal-mailer-r027.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Leon and Ethel Somers

- File: `deliverables/renewal-mailer-r028.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Doris Whitcomb

- File: `deliverables/renewal-mailer-r029.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Rufus Goodwin

- File: `deliverables/renewal-mailer-r030.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Hazel Nutting

- File: `deliverables/renewal-mailer-r031.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Renfrew Family

- File: `deliverables/renewal-mailer-r032.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Arthur and Cora Dole

- File: `deliverables/renewal-mailer-r033.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mildred Sargent

- File: `deliverables/renewal-mailer-r034.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Emery Flint

- File: `deliverables/renewal-mailer-r035.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Vera Bushway

- File: `deliverables/renewal-mailer-r036.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Kendall Family

- File: `deliverables/renewal-mailer-r037.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Homer and Alta Corliss

- File: `deliverables/renewal-mailer-r038.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Frances Dwinell

- File: `deliverables/renewal-mailer-r039.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Alva Bacon

- File: `deliverables/renewal-mailer-r040.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Opal Wheeler

- File: `deliverables/renewal-mailer-r041.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Currier Family

- File: `deliverables/renewal-mailer-r042.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Dennis and Rita Blaisdell

- File: `deliverables/renewal-mailer-r043.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Stella Farnham

- File: `deliverables/renewal-mailer-r044.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Ivan Whitham

- File: `deliverables/renewal-mailer-r045.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Genevieve Paige

- File: `deliverables/renewal-mailer-r046.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Larkin Family

- File: `deliverables/renewal-mailer-r047.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Cyrus and Nellie Mott

- File: `deliverables/renewal-mailer-r048.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Marion Tillotson

- File: `deliverables/renewal-mailer-r049.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Loren Pettit

- File: `deliverables/renewal-mailer-r050.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Beulah Hardy

- File: `deliverables/renewal-mailer-r051.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Emmons Family

- File: `deliverables/renewal-mailer-r052.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Chester and Ola Peckham

- File: `deliverables/renewal-mailer-r053.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Iris Sawyer

- File: `deliverables/renewal-mailer-r054.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Mr. and Mrs. Amos Pinney

- File: `deliverables/renewal-mailer-r055.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Lucille Crane

- File: `deliverables/renewal-mailer-r056.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - The Woodard Family

- File: `deliverables/renewal-mailer-r057.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Delbert and Grace Hovey

- File: `deliverables/renewal-mailer-r058.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Estelle Ripley

- File: `deliverables/renewal-mailer-r059.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Warren Tinkham

- File: `deliverables/renewal-mailer-r060.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - Phyllis Dodge

- File: `deliverables/renewal-mailer-r061.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

## Personalised autumn renewal mailer - combined production run

- File: `deliverables/renewal-mailer-combined.pdf`
- Specification: {"format":"pdf","pages":60,"width_mm":210,"height_mm":297}
- Content: undefined

## Producer mailing file - Harlan Pease

- File: `deliverables/producer-run-harlan-pease.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: Only Harlan Pease's households, in approved source-row order.

## Producer mailing file - Merritt Dolan

- File: `deliverables/producer-run-merritt-dolan.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: Only Merritt Dolan's households, in approved source-row order.

## Producer mailing file - Ada Fenwick

- File: `deliverables/producer-run-ada-fenwick.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Ada Fenwick's households, in approved source-row order.

## Producer mailing file - Roy Latimer

- File: `deliverables/producer-run-roy-latimer.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: Only Roy Latimer's households, in approved source-row order.

## Producer mailing file - Colette Brann

- File: `deliverables/producer-run-colette-brann.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Colette Brann's households, in approved source-row order.

## Producer mailing file - Wesley Amsden

- File: `deliverables/producer-run-wesley-amsden.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Wesley Amsden's households, in approved source-row order.

## Producer mailing file - Ida Thibault

- File: `deliverables/producer-run-ida-thibault.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Ida Thibault's households, in approved source-row order.

## Producer mailing file - Garrett Poole

- File: `deliverables/producer-run-garrett-poole.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Garrett Poole's households, in approved source-row order.

## Producer mailing file - Nan Ostrander

- File: `deliverables/producer-run-nan-ostrander.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Nan Ostrander's households, in approved source-row order.

## Producer mailing file - Verne Ottaway

- File: `deliverables/producer-run-verne-ottaway.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":5}
- Content: Only Verne Ottaway's households, in approved source-row order.

## Producer mailing file - Susannah Kell

- File: `deliverables/producer-run-susannah-kell.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":7}
- Content: Only Susannah Kell's households, in approved source-row order.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
