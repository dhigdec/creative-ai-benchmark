# Aldervale Mutual - Personalized autumn renewal mailer

Personalised renewal postcards, including eleven correctly separated producer files

For Aldervale Mutual's autumn renewal drop, each household must receive its own address, offer band and assigned producer's photograph. The starting point is the printer's PDF and our spreadsheet.

Please prepare
- Personalised autumn renewal mailer: 61 named exports. The addressee is correct. The offer wording matches the approved copy. The response instructions are readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Retain the promised eleven producer-separated PDFs in addition to the sixty individual mailers and combined run. A producer file contains only that producer's households in the original approved row order.
- The due date remains Friday, 31 October 2025 for this frozen historical campaign. Use one assigned offer band, full regulatory wording and the assigned producer portrait per household. This notice is not a bill appears on the mailer.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
