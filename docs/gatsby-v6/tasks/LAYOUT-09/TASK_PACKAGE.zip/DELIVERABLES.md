# LAYOUT-09: delivery register

## B2B product sell sheet - Median first response time

- File: `deliverables/sell-sheet-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The stated metric preserves its qualification. The UI is a faithful supplied capture.

## B2B product sell sheet - Tickets resolved per agent

- File: `deliverables/sell-sheet-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The stated metric preserves its qualification. The UI is a faithful supplied capture.

## B2B product sell sheet - Customer satisfaction (CSAT)

- File: `deliverables/sell-sheet-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The stated metric preserves its qualification. The UI is a faithful supplied capture.

## B2B product sell sheet - combined production run

- File: `deliverables/sell-sheet-combined.pdf`
- Specification: {"format":"pdf","pages":3,"width_mm":210,"height_mm":297}
- Content: undefined

## Product pitch deck

- File: `deliverables/pitch-deck.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":10}
- Content: The narrative explains the customer problem before the offer. The claims follow approved copy.

## Product launch post - Workflow

- File: `deliverables/launch-post-workflow.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The product name is clear. The request-demo action is visible.

## Product launch post - Team

- File: `deliverables/launch-post-team.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The product name is clear. The request-demo action is visible.

## Product launch post - Reporting

- File: `deliverables/launch-post-reporting.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The product name is clear. The request-demo action is visible.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
