# Nimbadesk - B2B sell-sheet system

Nimbadesk launch collateral using the current product build

We need the sell sheets, pitch deck and launch social to look like one product. There are eleven product captures in the pack, but the first job is to establish which belong to the current build and how they should be presented consistently.

Scope
1. B2B product sell sheet: 4 named exports. The stated metric preserves its qualification. The UI is a faithful supplied capture.
2. Product pitch deck: 1 named export. The narrative explains the customer problem before the offer. The claims follow approved copy.
3. Product launch post: 3 named exports. The product name is clear. The request-demo action is visible.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Every displayed business metric uses its supplied measurement period and unit. The sell sheets, pitch deck and launch posts may select relevant metrics from the approved table, but the row/period is named at each placement.
- Zilla Slab is the heading family; the old generic sans deck-headline check is withdrawn. Use supplied screen captures, not invented interface states.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
