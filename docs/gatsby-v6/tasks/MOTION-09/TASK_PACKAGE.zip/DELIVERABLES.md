# MOTION-09: delivery register

## Episode 42 verdict short

- File: `deliverables/podcast-square.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: On screen text giving the verdict order from voltcast_channel_notes.md, reading Kestrel PS-1500 first, Torrent Flux 1800 second and Halcyon C2200 third, plus the episode number 42 and the channel bug small in the bottom right corner. At least three distinct source shots.

## Verdict short vertical cutdown

- File: `deliverables/podcast-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: On screen text naming the pick, Kestrel PS-1500, plus the episode number 42 and the channel bug small in the bottom right corner. At least three distinct source shots, all of them also used in the square master.

## Podcast episode cover

- File: `deliverables/episode-cover.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The episode number is correct.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
