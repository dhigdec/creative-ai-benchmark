# MOTION-19: delivery register

## Right turns explainer

- File: `deliverables/scenario-r003.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The scenario title “Right turns”, then the five approved steps on screen in order, “Slow down early and get into the correct position”, “Signal right in good time”, “Check your mirrors and the road you are turning into”, “Take the turn at a speed that lets you stay in your own lane” and “Straighten up and build speed gently once you are round”, closing on the callout “Slow in, steady out.”, over footage of a car completing a right turn.

## Four-way stops explainer

- File: `deliverables/scenario-r008.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":10,"max":12},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The scenario title “Four-way stops”, then the four approved steps on screen in order, “Come to a full stop at the line, every time”, “The first vehicle to stop is the first to go”, “If two of you arrive together, the one on the right goes first” and “When it is your turn, move off clearly so others know”, closing on the callout “Full stop, then first come, first go.”, over footage of a car stopping at the line and proceeding.

## Vertical lane changes example

- File: `deliverables/scenario-tall.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":9},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The scenario title “Lane changes” and the callout “One lane at a time. Never two at once.” over upright lane change footage in which the dashed lane line stays visible in frame.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
