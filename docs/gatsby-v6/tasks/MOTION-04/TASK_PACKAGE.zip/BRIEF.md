# Sable and Finch Realty - Property listing tour package

For Sable and Finch the tour needs to help a buyer understand the house, not simply admire a sequence of rooms. Everything the videographer left us is five seconds and silent, so we are treating this as a short form pair that plays muted on the listing page and in social. The agent recording stays out of this round. The facts sit on screen as captions instead, which is how a buyer reads them on a phone anyway.

Please cut a 12 to 15 second listing tour in 16:9, built from at least five different takes, that opens on the exterior, moves through the rooms in an order a buyer could actually walk, and closes on the viewing action. The lower third carries the address “14 Gingerbread Hill Lane” with the price set under it, both exactly as row 2 of sablefinch_listings.csv has them. The upright cutdown runs 8 to 10 seconds and can be far more selective, but every room in it belongs to this house. One property per film, no exceptions: two houses in one tour is the single mistake we cannot put in front of a buyer.

Both films carry the supplied instrumental bed and nothing else on the audio. The completed source pack adds four five second shots, including the exterior coverage we never received.

The rest of the package is unchanged. We still need the twelve open house cards, each bound to its own row of sablefinch_listings.csv, the combined print run, and the disclosure line from sablefinch_facts_and_disclosure.txt carried word for word.

Production decisions for this edition
- The property tour and vertical tour are the full scope; earlier open-house print collateral is not required. Use the current listing facts and the supplied disclosure wherever the corresponding offer is shown.
- Manrope Light is the address font, replacing Tiempos. Keep the address/town hierarchy, Finch Gold-only graphic accent and truthful room/exterior footage on both films.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
