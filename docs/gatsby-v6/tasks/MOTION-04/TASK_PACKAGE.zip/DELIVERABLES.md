# MOTION-04: delivery register

## Property listing tour

- File: `deliverables/property-tour.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: An exterior opening shot of the featured house, at least five different supplied takes, a lower third with the address “14 Gingerbread Hill Lane” above the price from row 2 of sablefinch_listings.csv, and a closing viewing action.

## Upright property tour

- File: `deliverables/tour-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: Rooms from the featured house only, at least three different supplied takes, and the address “14 Gingerbread Hill Lane” on the closing frame.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
