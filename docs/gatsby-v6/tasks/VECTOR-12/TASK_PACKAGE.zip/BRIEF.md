# Static Union - Manufacturing artwork system

One streetwear graphic family adapted properly for four manufacturing methods

Static Union needs production-minded artwork adaptation for small goods. The same detailed drawing will not work unchanged as embroidery, enamel, a sticker and a woven label. We are looking for someone who understands those differences and can make deliberate reductions.

Scope
1. Eagle Bolt embroidery artwork: 1 named export. The artwork respects the embroidery vendor tolerance. The smallest reproduced detail remains open.
2. Arc Badge enamel-pin artwork: 1 named export. The artwork respects the enamel-pin vendor tolerance. The smallest reproduced detail remains open.
3. Bolt Icon sticker artwork: 1 named export. The artwork respects the sticker vendor tolerance. The smallest reproduced detail remains open.
4. Union Stripe woven-label artwork: 1 named export. The artwork respects the woven-label vendor tolerance. The smallest reproduced detail remains open.
5. Supplier production guide: 1 named export. The intended medium is stated on the relevant page. The physical reproduction size is unambiguous.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Eagle Bolt, Arc Badge, Bolt Icon and Union Stripe use their own references and maker-limit sections for embroidery, enamel, sticker and woven label respectively. The production guide documents those four supplied production files.
- Keep manufacturing separation layers inside the corresponding named SVG; a separately exported plate file is not an additional deliverable unless listed. Judge stroke/hole limits at the stated final manufacturing size, not screen zoom.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
