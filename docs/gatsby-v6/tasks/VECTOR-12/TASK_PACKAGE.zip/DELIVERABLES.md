# VECTOR-12: delivery register

## Eagle Bolt embroidery artwork

- File: `deliverables/embroidery-art.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The artwork respects the embroidery vendor tolerance. The smallest reproduced detail remains open.

## Arc Badge enamel-pin artwork

- File: `deliverables/pin-art.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The artwork respects the enamel-pin vendor tolerance. The smallest reproduced detail remains open.

## Bolt Icon sticker artwork

- File: `deliverables/sticker-art.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The artwork respects the sticker vendor tolerance. The smallest reproduced detail remains open.

## Union Stripe woven-label artwork

- File: `deliverables/woven-art.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The artwork respects the woven-label vendor tolerance. The smallest reproduced detail remains open.

## Supplier production guide

- File: `deliverables/production-guide.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The intended medium is stated on the relevant page. The physical reproduction size is unambiguous.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
