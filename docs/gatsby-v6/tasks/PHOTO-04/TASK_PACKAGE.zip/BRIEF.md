# Verranza Coastal Retreats - Villa collection image system

Three villas, one collection: imagery, crops and the gate monogram

For Verranza Coastal Retreats, the challenge is consistency without making three different villas interchangeable. We need the stone, limewash and coastal light to sit comfortably together across direct bookings and agent materials. The supplied do-not-want references are important.

Please prepare
- Villa booking hero: 3 named exports. The named villa matches the photograph. The offer price agrees with the approved rate record. The booking action is readable.
- Villa comparison brochure: 1 named export. Villa identities are unambiguous. The comparison makes differences between the properties easy to scan. Rates preserve their stated season.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The three booking heroes advertise High Summer (S2): Casa Verranza EUR 680 per night, Casa Oliveto EUR 740, and Casa Scogliera EUR 780, with a seven-night minimum. Show High Summer as words. All heroes end with Book direct.
- Use verranza_pool.jpg, oliveto_pool.jpg and scogliera_terrace.jpg for their respective heroes. The six-page brochure has a collection cover, one page per house, a three-house seasonal-rate comparison, and a booking page. Its comparison includes Spring, High Summer and Autumn. Casa Scogliera sleeps 10; Casa Fienile is excluded. No authored gold on any of these outputs.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
