# PHOTO-04: delivery register

## Villa booking hero - Oliveto

- File: `deliverables/booking-hero-oliveto.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Casa Oliveto High Summer EUR 740 per night 7-night minimum Book direct

## Villa booking hero - Scogliera

- File: `deliverables/booking-hero-scogliera.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Casa Scogliera High Summer EUR 780 per night 7-night minimum Book direct

## Villa booking hero - Verranza

- File: `deliverables/booking-hero-verranza.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Casa Verranza High Summer EUR 680 per night 7-night minimum Book direct

## Villa comparison brochure

- File: `deliverables/villa-collection.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: Villa identities are unambiguous. The comparison makes differences between the properties easy to scan. Rates preserve their stated season.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
