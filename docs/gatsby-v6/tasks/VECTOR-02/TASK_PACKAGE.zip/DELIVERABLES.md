# VECTOR-02: delivery register

## Engineering identity master

- File: `deliverables/works-mark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The mark preserves the surviving original identity. Letter counters remain open at the specified reproduction size.

## Machine identity plate

- File: `deliverables/machine-plate.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The plate information matches the supplied machine record. The production lettering is legible.

## Service document header

- File: `deliverables/service-header.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The company name is correct. The header leaves usable space for service content.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
