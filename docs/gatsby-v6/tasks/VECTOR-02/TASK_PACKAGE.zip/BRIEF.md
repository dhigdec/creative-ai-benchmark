# Redecker Machine Works - Restored mark system

Restore a machineworks identity from a catalogue and an etched plate

Redecker's mark has a long history, but the source artwork has not survived. We have a 1974 catalogue and an etched plate to work from. We want the identity recovered carefully, not replaced with something that merely looks industrial.

The commission

 Engineering identity master: 1 named export. The mark preserves the surviving original identity. Letter counters remain open at the specified reproduction size.

 Machine identity plate: 1 named export. The plate information matches the supplied machine record. The production lettering is legible.

 Service document header: 1 named export. The company name is correct. The header leaves usable space for service content.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the current works mark without the obsolete place-name arc. The machine plate uses its approved machine record; the service header uses the supplied current address block.
- Keep surviving identity geometry faithful. New serial and address text follows the role table; removal of the obsolete arc does not authorize removing the ring knockout or other retained features.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
