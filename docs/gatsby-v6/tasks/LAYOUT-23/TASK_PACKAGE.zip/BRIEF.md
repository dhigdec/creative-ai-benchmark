# Meridian Summit - Conference badge and wayfinding system

Eighteen conference badges with portraits that match and records that do not drift

The Meridian Summit registration desk needs a correct badge for every attending delegate. We have eighteen self-submitted photographs and last year's venue-bureau PDF, but not its working file.

The commission

 Conference delegate badge: 20 named exports. The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

 Conference track direction sign: 3 named exports. The track name follows the approved track note. The arrow points in the specified direction.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The output register is authoritative: nineteen individual delegate badges and one combined file, with the approved portraitless cases left portraitless. Eighteen describes the supplied portrait count, not a limit of eighteen delegates.
- Do not generate a missing headshot. Bind track/access text to its delegate and the three direction signs to their approved venue destinations.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
