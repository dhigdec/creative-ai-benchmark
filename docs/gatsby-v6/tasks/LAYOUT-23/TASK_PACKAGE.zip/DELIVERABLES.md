# LAYOUT-23: delivery register

## Conference delegate badge - Adaeze Okafor

- File: `deliverables/delegate-badge-r011.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Harold Brennan

- File: `deliverables/delegate-badge-r003.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Eleanor Vance

- File: `deliverables/delegate-badge-r004.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Margaret Whitlock

- File: `deliverables/delegate-badge-r006.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Katherine Osei

- File: `deliverables/delegate-badge-r007.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Camille Boucher

- File: `deliverables/delegate-badge-r008.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Lian Wei

- File: `deliverables/delegate-badge-r009.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Sanjay Mehta

- File: `deliverables/delegate-badge-r010.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Alan Pemberton

- File: `deliverables/delegate-badge-r012.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Raymond Delacroix

- File: `deliverables/delegate-badge-r013.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Neil Brackett

- File: `deliverables/delegate-badge-r014.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Freya Lindqvist

- File: `deliverables/delegate-badge-r015.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Gregory Nash

- File: `deliverables/delegate-badge-r016.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Theodore Ashworth

- File: `deliverables/delegate-badge-r017.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Idris Osman

- File: `deliverables/delegate-badge-r018.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Rosalind Achebe

- File: `deliverables/delegate-badge-r019.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Yuki Tanaka

- File: `deliverables/delegate-badge-r020.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Duncan Ferreira

- File: `deliverables/delegate-badge-r021.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - Benjamin Croft

- File: `deliverables/delegate-badge-r022.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The access category matches the registration. When a headshot is supplied, it belongs to the named delegate; otherwise the badge contains no invented portrait. The delegate name is readable when worn.

## Conference delegate badge - combined production run

- File: `deliverables/delegate-badge-combined.pdf`
- Specification: {"format":"pdf","pages":19,"width_mm":101.6,"height_mm":76.2}
- Content: undefined

## Conference track direction sign - Registration

- File: `deliverables/track-wayfinding-registration.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The track name follows the approved track note. The arrow points in the specified direction.

## Conference track direction sign - Main stage

- File: `deliverables/track-wayfinding-main-stage.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The track name follows the approved track note. The arrow points in the specified direction.

## Conference track direction sign - Breakouts

- File: `deliverables/track-wayfinding-breakouts.pdf`
- Specification: {"format":"pdf","width_mm":101.6,"height_mm":76.2,"pages":1,"template_reference":"badge_2026_PRINT.pdf"}
- Content: The track name follows the approved track note. The arrow points in the specified direction.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
