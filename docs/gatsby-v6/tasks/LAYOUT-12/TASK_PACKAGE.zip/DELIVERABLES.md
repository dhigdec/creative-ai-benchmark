# LAYOUT-12: delivery register

## After Dark poster direction - Type-led

- File: `deliverables/poster-direction-type-led.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The billing order follows the supplied list. The event information is readable.

## After Dark poster direction - Image-led

- File: `deliverables/poster-direction-image-led.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The billing order follows the supplied list. The event information is readable.

## After Dark poster direction - Graphic-led

- File: `deliverables/poster-direction-graphic-led.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The billing order follows the supplied list. The event information is readable.

## Promoter pitch deck

- File: `deliverables/promoter-deck.pdf`
- Specification: {"format":"pdf","width_mm":338.667,"height_mm":190.5,"pages":6}
- Content: The three directions are meaningfully distinct. The sequence explains the series identity.

## Night release post - 2026-09-25

- File: `deliverables/release-post-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-09-26

- File: `deliverables/release-post-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-02

- File: `deliverables/release-post-r004.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-03

- File: `deliverables/release-post-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-04

- File: `deliverables/release-post-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-09

- File: `deliverables/release-post-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-10

- File: `deliverables/release-post-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-16

- File: `deliverables/release-post-r009.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Night release post - 2026-10-17

- File: `deliverables/release-post-r010.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The date matches this event. The advance price is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
