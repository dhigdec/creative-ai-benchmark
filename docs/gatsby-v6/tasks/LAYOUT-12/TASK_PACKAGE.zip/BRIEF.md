# Umbra Loft - After Dark event campaign

After Dark: a coherent poster and social campaign from six different nights

Umbra Loft's autumn programme needs to feel like a series, even though our six usable archive photographs were shot under six different lighting rigs. We want a strong two-colour and grain treatment that actually lives in the images, not a collection of unrelated pictures behind matching text.

Deliverables
1. After Dark poster direction: 3 named exports. The billing order follows the supplied list. The event information is readable.
2. Promoter pitch deck: 1 named export. The three directions are meaningfully distinct. The sequence explains the series identity.
3. Night release post: 9 named exports. The date matches this event. The advance price is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The three poster directions and promoter deck use the supplied current autumn programme; release posts follow the nine event records. Keep act billing, door/date and accessibility wording attached to its event.
- Poster direction is a creative choice, not permission to change headliner/support order, omit the with prefix, invent an act or replace the approved price.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
