# VECTOR-10: delivery register

## Apparel crest production artwork - Cedar Line - Tee - Full chest

- File: `deliverables/garment-crest-r002.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest matches the authoritative painted reference. The brush character survives the reduction.

## Apparel crest production artwork - Sage Hollow - Hoodie - Left chest

- File: `deliverables/garment-crest-r003.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest matches the authoritative painted reference. The brush character survives the reduction.

## Apparel crest production artwork - Aubergine Dusk - Tee - Full chest

- File: `deliverables/garment-crest-r004.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest matches the authoritative painted reference. The brush character survives the reduction.

## Apparel crest production artwork - Cedar Line - Hoodie - Full back

- File: `deliverables/garment-crest-r005.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest matches the authoritative painted reference. The brush character survives the reduction.

## Apparel crest production artwork - Bone Ridge - Tee - Left sleeve

- File: `deliverables/garment-crest-r006.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest matches the authoritative painted reference. The brush character survives the reduction.

## Apparel crest production artwork - Harvest Bench - Hoodie - Full chest

- File: `deliverables/garment-crest-r007.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest matches the authoritative painted reference. The brush character survives the reduction.

## Garment capsule application presentation

- File: `deliverables/capsule-presentation.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: The graphic placement follows the garment schedule. The presentation distinguishes print artwork from illustrative mockup.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
