# Evergreen Provisions - Restored crest system

Six painted crest lockups prepared for an apparel capsule

Evergreen Provisions needs the six painted crest lockups prepared for its small garment capsule. The brush character matters, but the artwork must hold at the actual garment width rather than only in a large presentation.

Please prepare
- Apparel crest production artwork: 6 named exports. The crest matches the authoritative painted reference. The brush character survives the reduction.
- Garment capsule application presentation: 1 named export. The graphic placement follows the garment schedule. The presentation distinguishes print artwork from illustrative mockup.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The six garment artworks follow their own plate-schedule records and source crests. The capsule presentation shows those six applications, not six invented logo concepts.
- Flat fills and approved shelf inks apply separately to the six production artworks. Presentation photographs can retain their natural colours; production spot colours cannot be inferred from photographed fabric lighting.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
