# Cellar & Cru - Autumn shelf-talker campaign

Autumn shelf talkers that match the bottles and the sellable wine list

Cellar & Cru's autumn selection goes onto the shelf as a collection. We have sixteen photographs covering fourteen wines, taken on two evenings, and an old printer's PDF for the shelf talker.

Please prepare
- Wine shelf talker: 15 named exports. The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the eligible autumn wine list and exclude the two withdrawn records. The missing Sancerre photo may use a typography-led shelf card; never substitute a similar bottle or invent a score for the co-op red.
- Keep wine name, vintage, buyer note, price and any supplied score associated with their record. Do not shorten the buyer's copy to fit.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
