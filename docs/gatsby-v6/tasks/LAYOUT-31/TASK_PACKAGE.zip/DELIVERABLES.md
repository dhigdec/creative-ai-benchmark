# LAYOUT-31: delivery register

## Wine shelf talker - Clos des Galets Muscadet Sevre et Maine sur Lie

- File: `deliverables/shelf-talker-r002.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Domaine Vionne Alsace Riesling

- File: `deliverables/shelf-talker-r003.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Les Perrieres Sancerre

- File: `deliverables/shelf-talker-r004.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Bricault Chablis

- File: `deliverables/shelf-talker-r005.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Domaine Rosaline Provence Rose

- File: `deliverables/shelf-talker-r006.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Poderi Solano Vermentino

- File: `deliverables/shelf-talker-r008.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Weingut Halden Mosel Riesling Kabinett

- File: `deliverables/shelf-talker-r009.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Hofgut Steinweg Gruner Veltliner

- File: `deliverables/shelf-talker-r010.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Cave de Trevigne Coteaux Rouge

- File: `deliverables/shelf-talker-r011.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Domaine des Escaliers Cote Brune Syrah

- File: `deliverables/shelf-talker-r012.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Cascina Voltone Nebbiolo

- File: `deliverables/shelf-talker-r013.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Clos du Verger Bourgogne Rouge

- File: `deliverables/shelf-talker-r015.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Mas de la Pierre Vacqueyras

- File: `deliverables/shelf-talker-r016.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - Domaine Ravel Morgon

- File: `deliverables/shelf-talker-r017.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"talker_2025_PRINT.pdf"}
- Content: The bottle image matches the named wine. The vintage is accurate. The origin is readable. The price is easy to locate.

## Wine shelf talker - combined production run

- File: `deliverables/shelf-talker-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":105.156,"height_mm":148.167}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
