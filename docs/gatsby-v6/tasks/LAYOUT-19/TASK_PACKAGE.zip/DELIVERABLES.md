# LAYOUT-19: delivery register

## Advisory team-page composition

- File: `deliverables/team-page.png`
- Specification: {"format":"png","width":1440,"height":2400}
- Content: 

## Capabilities leave-behind

- File: `deliverables/capabilities.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The sector offer is clearly structured. No unsupported credential is added.

## Recruitment announcement

- File: `deliverables/recruitment-post.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The approved role or recruitment offer is clear. The application action is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
