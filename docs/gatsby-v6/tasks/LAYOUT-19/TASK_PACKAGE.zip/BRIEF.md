# Northwind Advisory - Team page and recruitment collateral

Make eight advisers look like one firm across the site and leave-behind

Northwind Advisory's team photographs were taken on three separate mornings. At present, we look like three different firms. We need a coherent portrait treatment and the team page, capabilities leave-behind and announcement posts built around it.

Please prepare
- Advisory team-page composition: 1 named export. 
- Capabilities leave-behind: 1 named export. The sector offer is clearly structured. No unsupported credential is added.
- Recruitment announcement: 1 named export. The approved role or recruitment offer is clear. The application action is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use current staff and approved regulated credentials/sectors; Julian is excluded. The recruitment post may select current team members but must name those people and their portraits in the asset plan.
- Cabinet Grotesk is the newly typeset firm-name family, replacing the old serif-name test. Preserve an existing supplied logo as artwork. Name/designation associations are checked person by person.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
