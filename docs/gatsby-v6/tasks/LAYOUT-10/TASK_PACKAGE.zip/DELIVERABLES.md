# LAYOUT-10: delivery register

## Recovered Alderwood crest master

- File: `deliverables/recovered-crest.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The crest geometry matches eastgate_crest_sign.jpg. The complete crest remains inside the SVG viewBox.

## Centre appeal banner - Eastgate Centre

- File: `deliverables/centre-appeal-r002.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The beneficiary story matches the named centre. The programme amount agrees with the reconciled funding table. The donation action is readable.

## Centre appeal banner - Waterman Row Centre

- File: `deliverables/centre-appeal-r003.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The beneficiary story matches the named centre. The programme amount agrees with the reconciled funding table. The donation action is readable.

## Centre appeal banner - Olneyville Green Centre

- File: `deliverables/centre-appeal-r004.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The beneficiary story matches the named centre. The programme amount agrees with the reconciled funding table. The donation action is readable.

## Centre appeal banner - Pawtucket Mills Centre

- File: `deliverables/centre-appeal-r005.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The beneficiary story matches the named centre. The programme amount agrees with the reconciled funding table. The donation action is readable.

## Centre appeal banner - Cranston Fields Centre

- File: `deliverables/centre-appeal-r006.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The beneficiary story matches the named centre. The programme amount agrees with the reconciled funding table. The donation action is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
