# Alderwood Scholars Fund - Multi-center appeal campaign

Five-centre appeal banners with accurate local details and a recovered crest

Alderwood Scholars Fund needs one coordinated banner run for its five centres. The office must be able to trust each centre's name, address, hours and coordinator, not proofread five designs assembled independently from memory.

What we need back
- Recovered Alderwood crest master: 1 named export. The crest geometry matches eastgate_crest_sign.jpg. The complete crest remains inside the SVG viewBox.
- Centre appeal banner: 5 named exports. The beneficiary story matches the named centre. The programme amount agrees with the reconciled funding table. The donation action is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The five centre appeal banners and recovered crest are this commission. A full 341-name honour roll and spending-table publication from the older copy pack are not additional outputs.
- Bind a centre photograph and outcome period to the correct centre. Display its approved donation message without combining another centre's result or date.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
