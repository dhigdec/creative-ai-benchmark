# PHOTO-13: delivery register

## Jewellery capsule campaign poster

- File: `deliverables/capsule-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The jewellery remains the primary visual focus. The campaign identifies Argent & Faith.

## Jewellery product detail - Quarry Band

- File: `deliverables/jewellery-detail-r002.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Vesper Medallion

- File: `deliverables/jewellery-detail-r003.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Crescent Studs

- File: `deliverables/jewellery-detail-r004.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Lattice Pendant

- File: `deliverables/jewellery-detail-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Reliquary Locket

- File: `deliverables/jewellery-detail-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Signet Ring

- File: `deliverables/jewellery-detail-r007.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Cloister Band

- File: `deliverables/jewellery-detail-r008.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Vigil Band

- File: `deliverables/jewellery-detail-r009.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Meridian Band

- File: `deliverables/jewellery-detail-r010.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Jewellery product detail - Ember Drop Earrings

- File: `deliverables/jewellery-detail-r011.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The construction or setting method matches the named piece. Metal colour remains believable.

## Retailer capsule look sheet

- File: `deliverables/retailer-look-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: Product labels identify the pictured pieces. The layout communicates the capsule relationship.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
