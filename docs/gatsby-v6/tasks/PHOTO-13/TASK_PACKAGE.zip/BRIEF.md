# Argent & Faith - Spring jewellery capsule photography

Silver jewellery retouching with an honest plan for open centres

Argent & Faith needs ten seasonal pieces prepared as a consistent listing set. The silver should read as silver, with a common light and scale across the range. We do not want the high polish turned into featureless grey.

What we need back
- Jewellery capsule campaign poster: 1 named export. The jewellery remains the primary visual focus. The campaign identifies Argent & Faith.
- Jewellery product detail: 10 named exports. The construction or setting method matches the named piece. Metal colour remains believable.
- Retailer capsule look sheet: 1 named export. Product labels identify the pictured pieces. The layout communicates the capsule relationship.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the capsule inventory's ten eligible pieces. The poster may feature one or more of those pieces; identify the chosen inventory row and bench_capsule filename for each pictured piece. The look sheet includes the ten pieces in piece-number order.
- The supplied web2025 photo paths are historical, not deliverable sources. Match the actual bench photograph to the inventory piece using the piece's construction and dimensions, then record the chosen filename. A filename alone is not evidence of identity. Preserve open centres, stones and silver tone.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
