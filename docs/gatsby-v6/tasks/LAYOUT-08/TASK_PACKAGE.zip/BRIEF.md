# Verranza Coastal Retreats - In-villa seasonal collateral

Twelve seasonal villa cards and a coherent three-property image set

Looking at our Verranza photographs together, you could believe they describe three different holidays. Two trips, two photographers and a batch already edited elsewhere have left the collection inconsistent.

Final handoff

 In-villa seasonal card: 13 named exports. The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Keep the twelve explicit villa/season/rate bindings. The combined file follows their register order. Seasonal labels and included-service conditions retain the wording in the current supplied rates/amenities files.
- This is the seasonal in-villa collateral identity, a deliberately separate commission from PHOTO-04's booking-campaign identity. Use this task's Aleo system and palette, not PHOTO-04's Canela system.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
