# LAYOUT-08: delivery register

## In-villa seasonal card - Villa Solane - Low Season

- File: `deliverables/season-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Solane - Shoulder Season

- File: `deliverables/season-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Solane - High Season

- File: `deliverables/season-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Solane - Peak Season

- File: `deliverables/season-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Cascina - Low Season

- File: `deliverables/season-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Cascina - Shoulder Season

- File: `deliverables/season-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Cascina - High Season

- File: `deliverables/season-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Villa Cascina - Peak Season

- File: `deliverables/season-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Maison Aubine - Low Season

- File: `deliverables/season-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Maison Aubine - Shoulder Season

- File: `deliverables/season-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Maison Aubine - High Season

- File: `deliverables/season-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - Maison Aubine - Peak Season

- File: `deliverables/season-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The season label matches this record. The villa information is unambiguous. The rate conditions are readable.

## In-villa seasonal card - combined production run

- File: `deliverables/season-card-combined.pdf`
- Specification: {"format":"pdf","pages":12,"width_mm":148,"height_mm":210}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
