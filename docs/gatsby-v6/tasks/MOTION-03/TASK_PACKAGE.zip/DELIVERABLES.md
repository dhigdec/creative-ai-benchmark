# MOTION-03: delivery register

## Creator led ad, hook 1

- File: `deliverables/creator-ad-hook-1.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":10,"max":12},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: A cleared hook line from halden_hooks.txt as on screen text inside the first two seconds, at least four different supplied takes, and the approved subscription action on the closing frame.

## Creator led ad, hook 2

- File: `deliverables/creator-ad-hook-2.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":10,"max":12},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: A cleared hook line from halden_hooks.txt that differs from the one used in hook 1, at least four different supplied takes, and the approved subscription action on the closing frame.

## Creator led ad, hook 3

- File: `deliverables/creator-ad-hook-3.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":10,"max":12},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: A cleared hook line from halden_hooks.txt that differs from hooks 1 and 2, at least four different supplied takes, and the approved subscription action on the closing frame.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
