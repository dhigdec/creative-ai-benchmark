# Summit & Sable - Recovery-gear launch campaign

Recovery-gear image system with a controlled Ridge Blue colourway

We need Summit & Sable's field and bench photographs to read as one recovery-gear range. There are twenty supplied captures, with webbing, stitching and hardware that need to remain convincing at close range.

Deliverables
1. Recovery-gear launch poster: 1 named export. The actual Summit & Sable equipment is shown. The poster contains no unsupported safety claim.
2. Recovery equipment product-page module: 9 named exports. The component geometry matches the named equipment. The load or use wording matches supplied approved copy.
3. Recovery-gear dealer sheet: 1 named export. The range is clearly identified. Specifications are readable at print size.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The dealer sheet includes the nine approved equipment records. The campaign poster may select a product from that range; name its source photograph and certified load in the handoff.
- Certified-load wording and figures are copied without rounding. Certified numbers stay in National 2. A Bodoni headline uses Bone White on a solid Recovery Orange band; that graphic treatment must not recolour the equipment itself.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
