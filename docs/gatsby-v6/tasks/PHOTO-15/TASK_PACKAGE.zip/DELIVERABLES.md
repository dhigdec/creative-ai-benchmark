# PHOTO-15: delivery register

## Recovery-gear launch poster

- File: `deliverables/gear-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The actual Summit & Sable equipment is shown. The poster contains no unsupported safety claim.

## Recovery equipment product-page module - Recovery Strap 3in

- File: `deliverables/equipment-pdp-r002.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Kinetic Rope

- File: `deliverables/equipment-pdp-r003.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Soft Shackle Large

- File: `deliverables/equipment-pdp-r004.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Soft Shackle Small

- File: `deliverables/equipment-pdp-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Tree Saver Strap

- File: `deliverables/equipment-pdp-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Winch Line Damper

- File: `deliverables/equipment-pdp-r007.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Snatch Block

- File: `deliverables/equipment-pdp-r008.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - Gear Bag

- File: `deliverables/equipment-pdp-r009.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery equipment product-page module - D-Ring Bow Shackle

- File: `deliverables/equipment-pdp-r010.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The component geometry matches the named equipment. The load or use wording matches supplied approved copy.

## Recovery-gear dealer sheet

- File: `deliverables/dealer-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The range is clearly identified. Specifications are readable at print size.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
