# PHOTO-30: delivery register

## Care-service information poster

- File: `deliverables/care-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The service wording stays within approved claims. The care contact is readable.

## Care website header

- File: `deliverables/care-header.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Stock people are not identified as named clinicians. The service name is clear. The clinical lead has a clean hair edge on the deep brand ground.

## Clinical lead transparent portrait

- File: `deliverables/clinical-lead.png`
- Specification: {"format":"png","width":1600,"height":1600,"transparent":true}
- Content: The portrait preserves the person in palewell_lead_frame.jpg. The shoulder edge has no visible halo.

## Referral information panel

- File: `deliverables/referral-panel.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The referral steps follow approved copy. The clinical lead identity is accurate.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
