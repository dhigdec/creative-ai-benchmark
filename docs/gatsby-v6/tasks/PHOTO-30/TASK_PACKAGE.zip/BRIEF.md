# Palewell Health - Licensed care image campaign

A restrained healthcare image set with a reliable clinical-lead cutout

Palewell needs photography that feels credible together, even though most of the set will be licensed and only one frame is owned. Please prioritise compatible camera scale, neutral balance and depth over a collection of individually attractive stock photographs.

Scope
1. Care-service information poster: 1 named export. The service wording stays within approved claims. The care contact is readable.
2. Care website header: 1 named export. Stock people are not identified as named clinicians. The service name is clear. The clinical lead has a clean hair edge on the deep brand ground.
3. Clinical lead transparent portrait: 1 named export. The portrait preserves the person in palewell_lead_frame.jpg. The shoulder edge has no visible halo.
4. Referral information panel: 1 named export. The referral steps follow approved copy. The clinical lead identity is accurate.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The poster, header and referral panel use the relevant approved care/service copy; employer-page paragraphs from earlier website work are not extra outputs. Keep longer approved regulated copy intact: the four-word limit applies only to a newly authored headline, not that fixed copy.
- Use licensed care photographs and the named clinical-lead portrait only. The lead cutout has no added type. Apply the one-accent rule to designed pieces, not the portrait's natural colours.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
