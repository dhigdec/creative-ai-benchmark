# Gable & Grove - Home services before-and-after library

Before-and-after renovation photographs that clients can trust

Gable & Grove needs five before-and-after pairs prepared for the website and sales materials. These are evidence of our work. The after pictures should look good, but not because the before pictures have been made deliberately worse.

What we need back
- Completed project case-study panel: 4 named exports. The comparison preserves meaningful structural differences. The project caption identifies the work actually shown.
- Estimate-pack cover: 1 named export. The cover identifies Gable & Grove. The selected project demonstrates the service without claiming an invented result.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The four completed projects follow the approved project records. A case-study panel contains its matching before and after photographs and that project's approved name and scope. The estimate cover may feature one of those four approved projects, with its selection recorded.
- Chapin Road is excluded from every output. The before photograph receives no cosmetic improvement; exposure normalization for legibility is allowed only if defects and structural details remain visible. New project text follows Austin/Whitney; recovered maker-mark lettering stays faithful to its source.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
