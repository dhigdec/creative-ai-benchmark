# PHOTO-07: delivery register

## Completed project case-study panel - Ridge Road

- File: `deliverables/case-study-r002.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The comparison preserves meaningful structural differences. The project caption identifies the work actually shown.

## Completed project case-study panel - Marble Dale

- File: `deliverables/case-study-r003.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The comparison preserves meaningful structural differences. The project caption identifies the work actually shown.

## Completed project case-study panel - Cornwall Bridge

- File: `deliverables/case-study-r004.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The comparison preserves meaningful structural differences. The project caption identifies the work actually shown.

## Completed project case-study panel - Ellsworth Hill

- File: `deliverables/case-study-r005.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The comparison preserves meaningful structural differences. The project caption identifies the work actually shown.

## Estimate-pack cover

- File: `deliverables/estimate-cover.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The cover identifies Gable & Grove. The selected project demonstrates the service without claiming an invented result.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
