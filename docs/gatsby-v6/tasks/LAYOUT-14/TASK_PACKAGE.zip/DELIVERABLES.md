# LAYOUT-14: delivery register

## Autumn editorial issue

- File: `deliverables/autumn-issue.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":10}
- Content: The complete approved article is present. The image order follows the editorial sequence. The masthead preserves the approved lettering. The page hierarchy supports sustained reading.

## Editorial plate card - I - Above Sennet Cove

- File: `deliverables/plate-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - II - By Hand

- File: `deliverables/plate-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - 3 - Emory Vaughn

- File: `deliverables/plate-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - IV - The Hull

- File: `deliverables/plate-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - IV - The Double End

- File: `deliverables/plate-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - 06 - The Hull

- File: `deliverables/plate-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - VII - Steam

- File: `deliverables/plate-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - 8 - The Joint

- File: `deliverables/plate-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - 09 - His Father's Tools

- File: `deliverables/plate-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - X - Laid By

- File: `deliverables/plate-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - 11 - Sighting the Line

- File: `deliverables/plate-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - XII - Day's End

- File: `deliverables/plate-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - 13 - Late Sun

- File: `deliverables/plate-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - XIV - North Light

- File: `deliverables/plate-card-r015.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":105.156,"pages":1,"template_reference":"lumen_platecard_template.pdf"}
- Content: The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

## Editorial plate card - combined production run

- File: `deliverables/plate-card-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":148.167,"height_mm":105.156}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
