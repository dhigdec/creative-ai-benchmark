# Lumen Quarterly - Autumn editorial issue

Lumen Quarterly's autumn issue, with an editable layout and recovered masthead

The editor will still be moving copy close to publication. Lumen Quarterly needs an autumn issue document that remains genuinely editable, supported by a coherent fourteen-frame photo essay and a usable version of our scanned masthead.

Final handoff

 Autumn editorial issue: 1 named export. The complete approved article is present. The image order follows the editorial sequence. The masthead preserves the approved lettering. The page hierarchy supports sustained reading.

 Editorial plate card: 15 named exports. The plate caption matches this record. If this record names a supplied picture, that picture appears on the card; otherwise the card contains no invented image.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the complete supplied essay and approved plate/caption order. Reflow long copy within the registered issue rather than cutting it. The current type card governs new setting; the historic issue is a reference, not a competing style specification.
- Arnhem is the caption family, replacing the old sans-caption requirement. Keep artist/author credits and Roman plate numbering attached to the correct source plate.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
