# DAYDRIFT - Vertical interview short series

Season four is finished and we would like something small to point people at it. Not a narrated trailer, and not three separate quote clips.

The three recordings in the pack are picture only. There is no sound on any of them, so please do not caption speech that is not there, and do not credit a line to a guest who is not shown saying it. Everything the viewer reads is text you set on screen, which is how the show already plays in a muted feed. A cleared instrumental bed is in the pack as daydrift_bed.wav.

Scope

Season four trailer: one named export, upright, twelve to fifteen seconds, music only. It moves through the three recorded episodes and names each one by its published title and its guest. At least three different shots, please, and no looping one recording to fill the time.

Season four trailer square cutdown: one named export, square, eight to ten seconds, music only, cut from the same material and finishing on a card that holds.

Episode covers: three named exports, square stills, one for episode two, one for episode five and one for episode eight. Each carries its published episode title, its guest and the sponsor line in full.

Titles, guest names and dates come from the season file and the show notes, spelled the way we publish them. The sponsor line is not ours to shorten, so it appears complete on every cover. The show name only survives as the artwork on the microphone flag, so take it from there rather than setting it in a typeface.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Video delivery means a playable MP4, not a storyboard, a still montage PDF or an editing log. Audio expectations are stated on each film, and no film in this pack carries speech.

Live action edits require adequate distinct footage. Looping a short clip is not a substitute for the missing coverage.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The current trailer/cutdown films replace the older interview-short scope. short-cover-idea-1.png covers episode 2, What the tide leaves, with Della Okonkwo; short-cover-idea-2.png covers episode 5, The quiet part out loud, with Yusuf Adeyemi; short-cover-idea-3.png covers episode 8, Everything we kept, with Samuel Boone. Their dates and complete sponsor lines come from those same records. Extract cover frames from daydrift_ep02.mp4, daydrift_ep05.mp4 and daydrift_ep08.mp4 respectively; the legacy interview-short-idea files are not required.
- No legacy dialogue is required in silent/music-only cuts. Guest-name italic is a role exception, not permission to italicize sponsor or episode details.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
