# MOTION-10: delivery register

## Season four trailer

- File: `deliverables/season-trailer-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: On screen text naming each of the three recorded episodes by its published title and guest: episode two, What the tide leaves, with Della Okonkwo; episode five, The quiet part out loud, with Yusuf Adeyemi; episode eight, Everything we kept, with Samuel Boone. The show name taken from daydrift_mic_flag.jpg. At least three distinct source shots.

## Season four trailer square cutdown

- File: `deliverables/season-trailer-square.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":8,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The show name taken from daydrift_mic_flag.jpg and a closing card that holds on screen for at least one second. At least three distinct source shots, all of them also used in the upright trailer.

## Episode 2 cover - What the tide leaves

- File: `deliverables/short-cover-idea-1.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: What the tide leaves Della Okonkwo 2025-11-18 This season of DAYDRIFT is supported by Fernhill & Oats, a tea room on SE Alder Street — open late, and no laptops after six.

## Episode 5 cover - The quiet part out loud

- File: `deliverables/short-cover-idea-2.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The quiet part out loud Yusuf Adeyemi 2026-02-24 This season of DAYDRIFT is supported by Fernhill & Oats, a tea room on SE Alder Street — open late, and no laptops after six.

## Episode 8 cover - Everything we kept

- File: `deliverables/short-cover-idea-3.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Everything we kept Samuel Boone 2026-05-19 This season of DAYDRIFT is supported by Fernhill & Oats, a tea room on SE Alder Street — open late, and no laptops after six.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
