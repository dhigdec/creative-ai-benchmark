# PHOTO-10: delivery register

## Apparel style product-page module - northgrove_style_01_loopback_crew

- File: `deliverables/style-pdp-northgrove-style-01-loopback-crew.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.

## Apparel style product-page module - northgrove_style_02_heavy_tee

- File: `deliverables/style-pdp-northgrove-style-02-heavy-tee.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.

## Apparel style product-page module - northgrove_style_03_raglan

- File: `deliverables/style-pdp-northgrove-style-03-raglan.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.

## Apparel style product-page module - northgrove_style_04_henley

- File: `deliverables/style-pdp-northgrove-style-04-henley.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.

## Apparel style product-page module - northgrove_style_05_zip_hoodie

- File: `deliverables/style-pdp-northgrove-style-05-zip-hoodie.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.

## Apparel style product-page module - northgrove_style_06_supporters_crew

- File: `deliverables/style-pdp-northgrove-style-06-supporters-crew.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.

## Capsule launch carousel - Page 1

- File: `deliverables/capsule-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

## Capsule launch carousel - Page 2

- File: `deliverables/capsule-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

## Capsule launch carousel - Page 3

- File: `deliverables/capsule-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

## Capsule launch carousel - Page 4

- File: `deliverables/capsule-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

## Capsule launch carousel - Page 5

- File: `deliverables/capsule-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

## Capsule launch carousel - Page 6

- File: `deliverables/capsule-carousel-p06.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
