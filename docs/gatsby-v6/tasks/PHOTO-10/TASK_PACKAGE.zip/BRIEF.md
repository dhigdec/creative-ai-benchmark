# Northgrove - Apparel colorway image system

Colour-consistent apparel images and clean retailer cutouts

Our Northgrove range is affordable premium basics. Customers choose between colours and fabrics, so a polished set that changes either of those is not useful to us.

Please prepare
- Apparel style product-page module: 6 named exports. The garment geometry matches its source style. The colourway is identified accurately. Fabric texture survives the treatment.
- Capsule launch carousel: 6 named exports. The capsule has a coherent visual direction. The opening page identifies Northgrove. The closing page contains the approved shopping action.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Deliver the six apparel modules and six carousel pages listed in the register. Separate transparent retailer cutouts mentioned in the older placement note are not commissioned in V6.
- Use the approved style/colourway records in register order. Swatches are colour references, not permission to recolour a photographed garment into an unavailable variant. Preserve the production logo rather than approximating its drawing.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
