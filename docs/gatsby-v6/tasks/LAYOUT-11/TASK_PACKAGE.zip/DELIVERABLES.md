# LAYOUT-11: delivery register

## Festival access credential - Marah Delune

- File: `deliverables/credential-r002.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Elias Ridge

- File: `deliverables/credential-r003.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Silas Ridge

- File: `deliverables/credential-r004.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Cassiane Wren

- File: `deliverables/credential-r005.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Fenn Aldous

- File: `deliverables/credential-r006.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Odette Marsh

- File: `deliverables/credential-r007.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Tamsin Reed

- File: `deliverables/credential-r008.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Jonah Vale

- File: `deliverables/credential-r009.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Priya Nandakumar

- File: `deliverables/credential-r010.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Rowan Beck

- File: `deliverables/credential-r011.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Dana Okonkwo

- File: `deliverables/credential-r012.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Marcus Feld

- File: `deliverables/credential-r013.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Lena Ostrove

- File: `deliverables/credential-r014.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Theo Brandt

- File: `deliverables/credential-r015.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Aisha Rahman

- File: `deliverables/credential-r016.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Cole Whitaker

- File: `deliverables/credential-r017.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Marisol Vega

- File: `deliverables/credential-r018.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Sam Iverson

- File: `deliverables/credential-r019.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Nadia Chen

- File: `deliverables/credential-r020.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Bram Kessler

- File: `deliverables/credential-r021.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - Georgia Pryce

- File: `deliverables/credential-r022.pdf`
- Specification: {"format":"pdf","width_mm":100,"height_mm":150,"pages":1}
- Content: The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

## Festival access credential - combined production run

- File: `deliverables/credential-combined.pdf`
- Specification: {"format":"pdf","pages":21,"width_mm":100,"height_mm":150}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
