# Lanternwood Folk Fest - Performer credential system

Performer laminates for Lanternwood, rebuilt from last year's printed artwork

Twenty-two people need correct performer laminates. Our designer left in 2024, and the usable starting point is last year's printed artwork. We need a production designer who will rebuild the run carefully, not carry last year's names or fields into new passes.

The commission

 Festival access credential: 22 named exports. The role and access areas match this person record. When a headshot is supplied, it belongs to the named person; otherwise the credential contains no invented portrait. The credential remains readable when worn.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the eligible performer/access records and their assigned credentials. The combined credential file follows the individual order. A name can reflow but cannot be truncated.
- Set the large name flush left at 30 pt on 32 pt with 0 em tracking; wrap at word boundaries when needed. Keep names and access text inside the production safe area. This replaces the incompatible force-justification, touch-trim and never-wrap rules. Retain the 3 pt Ember Red rule beneath the name; the poster name uses 240 px on 250 px.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
