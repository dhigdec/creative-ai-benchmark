# LAYOUT-22: delivery register

## Cohort credential - Marcus Ellery

- File: `deliverables/credential-r002.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Renée Duval

- File: `deliverables/credential-r003.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Tomás Beckett

- File: `deliverables/credential-r004.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Priya Anand

- File: `deliverables/credential-r005.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Bjoern Aas

- File: `deliverables/credential-r006.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Agnès Mercier

- File: `deliverables/credential-r007.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Daniel Okafor

- File: `deliverables/credential-r008.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Sofia Marchetti

- File: `deliverables/credential-r009.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Łukasz Nowak

- File: `deliverables/credential-r010.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Hannah Weiss

- File: `deliverables/credential-r011.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - José Ramírez

- File: `deliverables/credential-r012.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Grace Sullivan

- File: `deliverables/credential-r013.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Karl Muller

- File: `deliverables/credential-r014.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Elise Fontaine

- File: `deliverables/credential-r015.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Oren Katz

- File: `deliverables/credential-r016.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Mei-Ling Chen

- File: `deliverables/credential-r017.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Patrick Doyle

- File: `deliverables/credential-r018.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Zoë Hartmann

- File: `deliverables/credential-r019.pdf`
- Specification: {"format":"pdf","width_mm":297.011,"height_mm":209.889,"pages":1,"template_reference":"adulted_2024_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Eleanor Whitfield

- File: `deliverables/credential-r023.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Rajesh Menon

- File: `deliverables/credential-r024.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Søren Halvorsen

- File: `deliverables/credential-r025.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Camille Béranger

- File: `deliverables/credential-r026.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Nathan Cole

- File: `deliverables/credential-r027.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Ingrid Sørensen

- File: `deliverables/credential-r028.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Olivia Grant

- File: `deliverables/credential-r029.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Yusuf Demir

- File: `deliverables/credential-r030.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - Beatriz Álvarez

- File: `deliverables/credential-r031.pdf`
- Specification: {"format":"pdf","width_mm":420.201,"height_mm":297.011,"pages":1,"template_reference":"exec_diploma_2019_press.pdf"}
- Content: The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

## Cohort credential - combined production run

- File: `deliverables/credential-combined.pdf`
- Specification: {"format":"pdf","pages":27,"variable_page_sizes":true}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
