# Cedarline Institute - Cohort credential system

Two credential registers rebuilt into a checked autumn graduation run

Cedarline Institute needs credentials for completing candidates across two registers. We have press files from two closed print shops, and they may not convert into the same kind of working document.

What we need back
- Cohort credential: 28 named exports. The credential title follows the programme code. The recipient name fits without clipping. The seal is faithful to the authoritative reference.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The programme code selects community versus executive credential treatment. Use the corrected approved candidate names, including accents, and the eligible cohort only.
- Bind the proper legacy layout/seal to the programme. Programme-specific sizes remain distinct. Candidate names are not letterspaced, and code/numeric fields use the designated numeric face.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
