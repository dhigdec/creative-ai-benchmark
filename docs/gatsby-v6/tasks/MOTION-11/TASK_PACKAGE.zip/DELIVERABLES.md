# MOTION-11: delivery register

## Channel thumbnail - WE BROKE THE MAP

- File: `deliverables/thumbnail-we-broke-the-map.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The title is readable at 320 px width. The mascot silhouette is recognisable.

## Channel thumbnail - EVERYONE OFF THE PLATFORM

- File: `deliverables/thumbnail-everyone-off-the-platform.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The title is readable at 320 px width. The mascot silhouette is recognisable.

## Channel thumbnail - KITCHEN. GONE.

- File: `deliverables/thumbnail-kitchen-gone.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The title is readable at 320 px width. The mascot silhouette is recognisable.

## Channel thumbnail - DO NOT OPEN THAT DOOR

- File: `deliverables/thumbnail-do-not-open-that-door.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The title is readable at 320 px width. The mascot silhouette is recognisable.

## Channel thumbnail - WE SPENT SIX HOURS BUILDING A BRIDGE AND THEN DROVE STRAIGHT PAST IT

- File: `deliverables/thumbnail-we-spent-six-hours-building-a-bridge-and-then-drove-straight-pas.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The title is readable at 320 px width. The mascot silhouette is recognisable.

## Channel thumbnail - I GAVE MY TEAM ONE SIMPLE JOB AND THEY SET THE ENTIRE BASE ON FIRE

- File: `deliverables/thumbnail-i-gave-my-team-one-simple-job-and-they-set-the-entire-base-on-fi.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The title is readable at 320 px width. The mascot silhouette is recognisable.

## Animated channel title and end card

- File: `deliverables/channel-animation.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: An authored reveal of the channel name STATIC FOX, landing on a held end card carrying the members line from staticfox_titles.txt complete and word for word, the handle @STATICFOX, and a background drawn from the five brand palette colours.

## Channel feed teaser

- File: `deliverables/channel-teaser.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: Shots from at least four of the six supplied captures, the tagline Co op disasters and bad decisions. exactly as written in staticfox_titles.txt, and the end card line NEW ONE EVERY OTHER DAY. No shot repeated to fill length.

## Channel feed teaser upright cutdown

- File: `deliverables/channel-teaser-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: Shots from at least three of the six supplied captures, all of them also used in the wide teaser, with the handle @STATICFOX on the closing frame and all text fully inside the upright frame.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
