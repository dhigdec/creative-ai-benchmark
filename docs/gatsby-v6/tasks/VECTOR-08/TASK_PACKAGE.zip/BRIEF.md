# Coble & Vane - One-color mark system

Distillery mark recovery and a matching founder portrait set

This is a focused identity-production commission for Coble & Vane. We need the existing mark recovered in colour and true one-ink form, alongside three founder photographs that currently disagree because of their lighting.

The commission

 One-colour packaging identity: 1 named export. The mark uses the approved one-ink treatment. The counter spaces remain open on the stated stock.

 Cask-release label artwork: 8 named exports. The release details match this record. The label respects the supplied packaging area.

 Packaging supplier application sheet: 1 named export. The ink treatment is unambiguous. The application scale is stated.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the one-ink house mark on the eligible release labels and supplier sheet. Bind the release name, volume and required legal copy to its assigned cask record.
- One ink means a single solid production ink on the substrate; do not add tints, gradients or extra plates. Recovered mark geometry and newly typeset release text have separate references.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
