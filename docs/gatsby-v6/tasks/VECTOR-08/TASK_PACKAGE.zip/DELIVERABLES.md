# VECTOR-08: delivery register

## One-colour packaging identity

- File: `deliverables/one-ink-mark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The mark uses the approved one-ink treatment. The counter spaces remain open on the stated stock.

## Cask-release label artwork - 214

- File: `deliverables/release-label-r002.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - 221

- File: `deliverables/release-label-r004.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - 225

- File: `deliverables/release-label-r005.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - 229

- File: `deliverables/release-label-r006.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - 241

- File: `deliverables/release-label-r009.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - 250

- File: `deliverables/release-label-r011.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - 254

- File: `deliverables/release-label-r012.pdf`
- Specification: {"format":"pdf","width_mm":209.889,"height_mm":148.167,"pages":1,"template_reference":"cask_labels_2025_PRINT.pdf"}
- Content: The release details match this record. The label respects the supplied packaging area.

## Cask-release label artwork - combined production run

- File: `deliverables/release-label-combined.pdf`
- Specification: {"format":"pdf","pages":7,"width_mm":209.889,"height_mm":148.167}
- Content: undefined

## Packaging supplier application sheet

- File: `deliverables/supplier-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: The ink treatment is unambiguous. The application scale is stated.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
