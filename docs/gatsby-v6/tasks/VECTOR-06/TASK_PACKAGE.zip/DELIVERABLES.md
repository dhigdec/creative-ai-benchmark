# VECTOR-06: delivery register

## Football club crest - Master

- File: `deliverables/club-crest-master.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The club lettering matches the source. The crest details remain recognisable at shirt size.

## Football club crest - Single ink

- File: `deliverables/club-crest-single-ink.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The club lettering matches the source. The crest details remain recognisable at shirt size.

## Football club crest - Reversed

- File: `deliverables/club-crest-reversed.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The club lettering matches the source. The crest details remain recognisable at shirt size.

## Club number glyph - 0

- File: `deliverables/number-0.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 1

- File: `deliverables/number-1.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 2

- File: `deliverables/number-2.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 3

- File: `deliverables/number-3.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 4

- File: `deliverables/number-4.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 5

- File: `deliverables/number-5.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 6

- File: `deliverables/number-6.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 7

- File: `deliverables/number-7.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 8

- File: `deliverables/number-8.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club number glyph - 9

- File: `deliverables/number-9.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.

## Club letter glyph - A

- File: `deliverables/letter-a.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - B

- File: `deliverables/letter-b.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - C

- File: `deliverables/letter-c.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - D

- File: `deliverables/letter-d.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - E

- File: `deliverables/letter-e.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - F

- File: `deliverables/letter-f.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - G

- File: `deliverables/letter-g.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - H

- File: `deliverables/letter-h.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - I

- File: `deliverables/letter-i.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - J

- File: `deliverables/letter-j.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - K

- File: `deliverables/letter-k.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - L

- File: `deliverables/letter-l.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - M

- File: `deliverables/letter-m.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - N

- File: `deliverables/letter-n.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - O

- File: `deliverables/letter-o.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - P

- File: `deliverables/letter-p.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - Q

- File: `deliverables/letter-q.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - R

- File: `deliverables/letter-r.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - S

- File: `deliverables/letter-s.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - T

- File: `deliverables/letter-t.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - U

- File: `deliverables/letter-u.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - V

- File: `deliverables/letter-v.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - W

- File: `deliverables/letter-w.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - X

- File: `deliverables/letter-x.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - Y

- File: `deliverables/letter-y.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Club letter glyph - Z

- File: `deliverables/letter-z.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows the founder's drawing. The letter has no graph-paper artefacts.

## Shirt and training-kit artwork sheet

- File: `deliverables/kit-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":3}
- Content: The crest placement respects the supplied kit dimensions. The name-number hierarchy is usable on the shirt.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
