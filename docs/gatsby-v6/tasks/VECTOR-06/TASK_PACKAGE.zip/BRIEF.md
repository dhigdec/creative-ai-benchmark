# Ridgeway Rovers - Football crest master system

Recover a football crest and its hand-drawn shirt lettering

Ridgeway Rovers wants its existing identity back in usable form. The crest needs to work at breast size and in one ink; the lettering comes from a set of 1990s drawings rather than a font we can buy.

Scope
1. Football club crest: 3 named exports. The club lettering matches the source. The crest details remain recognisable at shirt size.
2. Club number glyph: 10 named exports. The numeral is unambiguous at kit viewing distance. The glyph follows the founder's drawing.
3. Club letter glyph: 26 named exports. The letter follows the founder's drawing. The letter has no graph-paper artefacts.
4. Shirt and training-kit artwork sheet: 1 named export. The crest placement respects the supplied kit dimensions. The name-number hierarchy is usable on the shirt.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Keep crest variants, ten numerals, twenty-six letters and the kit sheet separate. Preserve the approved crest/date geometry and source glyph construction; new kit-sheet labels follow the layout type roles.
- Manufacturing limits are evaluated at the supplier's named reproduction size and separately for the applicable crest variant. The roster is for kit application identity, not permission to alter the recovered numbering alphabet.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
