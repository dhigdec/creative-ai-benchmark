# VECTOR-15: delivery register

## Marchfield shield-and-wreath crest - Master

- File: `deliverables/crest-master.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The shield matches the authoritative source crest. The wreath matches the authoritative source crest. The original lettering is preserved.

## Marchfield shield-and-wreath crest - Reversed

- File: `deliverables/crest-reversed.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The shield matches the authoritative source crest. The wreath matches the authoritative source crest. The original lettering is preserved.

## Marchfield engraving artwork

- File: `deliverables/engraving.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The original crest identity survives the production simplification. Small counters remain open at 32 mm. The thinnest engraved stroke is at least 0.50 mm at a 32 mm crest width.

## Suite plate - 101

- File: `deliverables/suite-plate-r002.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 102

- File: `deliverables/suite-plate-r003.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 103

- File: `deliverables/suite-plate-r004.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 201

- File: `deliverables/suite-plate-r006.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 202

- File: `deliverables/suite-plate-r007.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 203

- File: `deliverables/suite-plate-r008.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 204

- File: `deliverables/suite-plate-r009.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 301

- File: `deliverables/suite-plate-r010.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 302

- File: `deliverables/suite-plate-r012.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 303

- File: `deliverables/suite-plate-r013.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 304

- File: `deliverables/suite-plate-r014.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 401

- File: `deliverables/suite-plate-r015.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 402

- File: `deliverables/suite-plate-r016.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - 403

- File: `deliverables/suite-plate-r017.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.

## Suite plate - combined production run

- File: `deliverables/suite-plate-combined.pdf`
- Specification: {"format":"pdf","pages":14,"width_mm":200,"height_mm":75}
- Content: undefined

## Entrance plaque artwork

- File: `deliverables/entrance-plaque.pdf`
- Specification: {"format":"pdf","width_mm":450,"height_mm":300,"pages":1}
- Content: The crest is 180 mm across. Artwork stays at least 15 mm from each bolt centre. The building name is correct.

## Lobby directory artwork

- File: `deliverables/directory-board.pdf`
- Specification: {"format":"pdf","width_mm":600,"height_mm":900,"pages":1}
- Content: The crest is 120 mm across. Artwork leaves a 20 mm clear margin. Tenants appear in reconciled suite order.

## Brass reproduction proof

- File: `deliverables/fabrication-proof.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":3}
- Content: The proof shows the crest on satin brass. The stated reproduction size is accurate. The proof identifies details that fail the 0.50 mm stroke limit.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
