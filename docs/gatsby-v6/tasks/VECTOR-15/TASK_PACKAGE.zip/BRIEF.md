# Marchfield Exchange - Crest and engraving geometry system

Restore the Exchange crest and rebuild the suite-plate workflow

Marchfield Exchange is a listed 1911 building. The crest needs recovering from brass and letterhead references; the suite plates need updating from the 2019 production PDF. We are preserving an identity and an installation, not commissioning a redesign.

Deliverables
1. Marchfield shield-and-wreath crest: 2 named exports. The shield matches the authoritative source crest. The wreath matches the authoritative source crest. The original lettering is preserved.
2. Marchfield engraving artwork: 1 named export. The original crest identity survives the production simplification. Small counters remain open at 32 mm. The thinnest engraved stroke is at least 0.50 mm at a 32 mm crest width.
3. Suite plate: 15 named exports. The suite number matches this schedule record. The approved shield-and-wreath crest is used. The artwork leaves a 12 mm clear margin.
4. Entrance plaque artwork: 1 named export. The crest is 180 mm across. Artwork stays at least 15 mm from each bolt centre. The building name is correct.
5. Lobby directory artwork: 1 named export. The crest is 120 mm across. Artwork leaves a 20 mm clear margin. Tenants appear in reconciled suite order.
6. Brass reproduction proof: 1 named export. The proof shows the crest on satin brass. The stated reproduction size is accurate. The proof identifies details that fail the 0.50 mm stroke limit.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The crest, reversed crest, 32 mm engraving, suite plates, entrance plaque, directory and fabrication proof retain their distinct sizes and manufacturing constraints. MCMXI is Roman lettering, not an Arabic oldstyle-number feature.
- Use current suite/tenant records and the source precedence in the survey. Tenant names are not bold. Source-handoff references must allow the added tenant text to be edited; a flattened preview alone does not satisfy that requirement.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
