# Isla Verde - Monogram and wayfinding pictogram system

Resort identity recovery and a bilingual door-plate system

Isla Verde needs a specialist who is comfortable with both identity craft and production data. This is one coordinated job: recover the foil monogram, build the pictograms and make the bilingual plates fit the existing installation.

Final handoff

 Recovered Isla Verde monogram: 1 named export. The letterforms match the authoritative source. The inter-letter relationships preserve the original identity.

 Wordless facility pictogram: 8 named exports. The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

 Bilingual door plate: 25 named exports. The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Recover the monogram, create the eight named pictograms and produce the eligible door plates. Bind each door plate to its room code/name in the approved schedule, retaining bilingual copy where supplied.
- The physical signshop constraints apply at final plate size. Pictograms and recovered monograms do not receive arbitrary font checks; only added room numbers/names do.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
