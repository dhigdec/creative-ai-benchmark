# VECTOR-05: delivery register

## Recovered Isla Verde monogram

- File: `deliverables/monogram.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The letterforms match the authoritative source. The inter-letter relationships preserve the original identity.

## Wordless facility pictogram - Reception

- File: `deliverables/pictogram-reception.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Pool

- File: `deliverables/pictogram-pool.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Restaurant

- File: `deliverables/pictogram-restaurant.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Bar

- File: `deliverables/pictogram-bar.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Spa

- File: `deliverables/pictogram-spa.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Gym

- File: `deliverables/pictogram-gym.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Restroom

- File: `deliverables/pictogram-restroom.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Wordless facility pictogram - Beach

- File: `deliverables/pictogram-beach.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The complete symbol remains inside the export boundary. The symbol retains an open interior counter at 12 mm.

## Bilingual door plate - 1

- File: `deliverables/door-plate-r002.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 2

- File: `deliverables/door-plate-r003.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 3

- File: `deliverables/door-plate-r004.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 4

- File: `deliverables/door-plate-r005.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 5

- File: `deliverables/door-plate-r006.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 6

- File: `deliverables/door-plate-r007.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 7

- File: `deliverables/door-plate-r008.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 8

- File: `deliverables/door-plate-r009.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 9

- File: `deliverables/door-plate-r010.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 10

- File: `deliverables/door-plate-r011.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 11

- File: `deliverables/door-plate-r012.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 12

- File: `deliverables/door-plate-r013.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 13

- File: `deliverables/door-plate-r014.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 14

- File: `deliverables/door-plate-r015.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 15

- File: `deliverables/door-plate-r016.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 16

- File: `deliverables/door-plate-r017.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 17

- File: `deliverables/door-plate-r018.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 18

- File: `deliverables/door-plate-r019.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 19

- File: `deliverables/door-plate-r020.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 20

- File: `deliverables/door-plate-r021.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 21

- File: `deliverables/door-plate-r022.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 22

- File: `deliverables/door-plate-r023.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 23

- File: `deliverables/door-plate-r024.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - 24

- File: `deliverables/door-plate-r025.pdf`
- Specification: {"format":"pdf","width_mm":200,"height_mm":75,"pages":1}
- Content: The language pairing matches the schedule. The room identifier is unambiguous. The approved monogram is used.

## Bilingual door plate - combined production run

- File: `deliverables/door-plate-combined.pdf`
- Specification: {"format":"pdf","pages":24,"width_mm":200,"height_mm":75}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
