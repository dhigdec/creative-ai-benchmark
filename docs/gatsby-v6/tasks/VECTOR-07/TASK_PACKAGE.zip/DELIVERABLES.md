# VECTOR-07: delivery register

## Recovered festival mark

- File: `deliverables/festival-mark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The source lettering is preserved.

## Festival poster

- File: `deliverables/festival-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The billing order follows the approved lineup. The event date is readable.

## Festival handbill

- File: `deliverables/handbill.pdf`
- Specification: {"format":"pdf","width_mm":148,"height_mm":210,"pages":1}
- Content: The venue details are readable at print size. The ticket action is visible.

## Festival shirt artwork

- File: `deliverables/shirt-art.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The ink limits follow the supplier note. The mark remains recognisable on the garment.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
