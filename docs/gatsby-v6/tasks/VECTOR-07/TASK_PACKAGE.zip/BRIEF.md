# Wharfside Folk Festival - Restored festival identity

Bring our painted festival wordmark into a usable anniversary kit

Wharfside Folk Festival is twenty years old. The shed-painted wordmark is part of that history, and we want to retain its character across the handbill, cloth and supporting anniversary materials.

What we need back
- Recovered festival mark: 1 named export. The source lettering is preserved.
- Festival poster: 1 named export. The billing order follows the approved lineup. The event date is readable.
- Festival handbill: 1 named export. The venue details are readable at print size. The ticket action is visible.
- Festival shirt artwork: 1 named export. The ink limits follow the supplier note. The mark remains recognisable on the garment.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The recovered festival mark is reused on the poster, handbill and shirt art without replacing its lettering. Use the supplied act billing and festival details in their approved order.
- Separate paper collateral from the shirt's production ink restrictions. New event/body text uses the current type card; source mark lettering is exempt from retypesetting.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
