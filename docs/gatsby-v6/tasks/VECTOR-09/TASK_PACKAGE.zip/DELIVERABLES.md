# VECTOR-09: delivery register

## Halcyon Grid logo variant - Master

- File: `deliverables/logo-master.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The geometry preserves the master identity. The lettering is optically balanced.

## Halcyon Grid logo variant - Dispatch

- File: `deliverables/logo-dispatch.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The geometry preserves the master identity. The lettering is optically balanced.

## Halcyon Grid logo variant - Relay

- File: `deliverables/logo-relay.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The geometry preserves the master identity. The lettering is optically balanced.

## Identity usage guide

- File: `deliverables/identity-usage.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The guide shows usable clear-space examples. The variant naming is unambiguous.

## Team website identity application

- File: `deliverables/team-lockup.png`
- Specification: {"format":"png","width":1440,"height":2400}
- Content: The correct team names accompany their portraits. The parent and product identities have a clear hierarchy.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
