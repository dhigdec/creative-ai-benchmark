# Halcyon Grid - Production logo family

Turn rough raster brand concepts into a credible SaaS identity system

Halcyon Grid is a small logistics software team. We have three AI-generated raster marks, but we do not yet have a usable identity. We need a designer to resolve the geometry, not preserve every artefact in those images.

Deliverables
1. Halcyon Grid logo variant: 3 named exports. The geometry preserves the master identity. The lettering is optically balanced.
2. Identity usage guide: 1 named export. The guide shows usable clear-space examples. The variant naming is unambiguous.
3. Team website identity application: 1 named export. The correct team names accompany their portraits. The parent and product identities have a clear hierarchy.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The logo family contains the registered primary, reversed and alternate variants. The identity sheet explains those actual variants; the team lockup uses the eligible roster only.
- Use the founder-approved surviving geometry. Do not confuse a white reversed shape with an opaque white background. New roster text follows the type card without changing the logo's source lettering.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
