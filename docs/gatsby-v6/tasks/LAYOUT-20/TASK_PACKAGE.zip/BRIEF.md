# Walter Fernwood Memorial - Service print and remembrance set

Memorial print and a memory book for Walter Fernwood's family

My father, Walter Fernwood, died in March. We are preparing the service and would like the printed pieces to sit alongside those from my mother's service in 2019. We have the old press files, a eulogy and a shoebox of scans spanning many years.

Final handoff

 Memorial keepsake card: 27 named exports. The memorial name is correct. The wording remains respectful.

 Framed memorial page: 1 named export. The dates agree with the family record. The portrait identity is preserved.

 Family memory book: 1 named export. The chronology follows the family notes. The eulogy is not rewritten. The images preserve documentary identity.

 Memorial share card: 1 named export. The memorial details are readable. The treatment is restrained.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the supplied eulogy, guest records and exact transcriptions for the registered remembrance outputs. Preserve [?] for illegible text rather than completing a guessed word.
- The V6 role table governs newly set names/dates, while protected scan damage and original handwriting remain source content. No script substitute or automatic beautification may erase that distinction.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
