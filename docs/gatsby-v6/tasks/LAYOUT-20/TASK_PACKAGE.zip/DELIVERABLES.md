# LAYOUT-20: delivery register

## Memorial keepsake card - Margaret Ellis

- File: `deliverables/keepsake-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Tom Ellis

- File: `deliverables/keepsake-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Peter Fernwood

- File: `deliverables/keepsake-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Susan Fernwood

- File: `deliverables/keepsake-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Claire Ellis

- File: `deliverables/keepsake-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - David Fernwood

- File: `deliverables/keepsake-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Hollis Fernwood

- File: `deliverables/keepsake-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Eleanor Vance

- File: `deliverables/keepsake-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Otis Freeman

- File: `deliverables/keepsake-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Lucille Freeman

- File: `deliverables/keepsake-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Harold Prentice

- File: `deliverables/keepsake-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Ruth Prentice

- File: `deliverables/keepsake-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Arthur Bell

- File: `deliverables/keepsake-card-r014.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Sam Okonkwo

- File: `deliverables/keepsake-card-r015.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Beatrice Lundy

- File: `deliverables/keepsake-card-r016.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Grace Holloway

- File: `deliverables/keepsake-card-r017.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Rev. Miriam Todd

- File: `deliverables/keepsake-card-r018.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Pearl Whitcomb

- File: `deliverables/keepsake-card-r019.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Frank Delgado

- File: `deliverables/keepsake-card-r020.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Nora Delgado

- File: `deliverables/keepsake-card-r021.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Gene Tackett

- File: `deliverables/keepsake-card-r022.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Marion Tackett

- File: `deliverables/keepsake-card-r023.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Walter Chase

- File: `deliverables/keepsake-card-r024.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Dr. Anand Rao

- File: `deliverables/keepsake-card-r025.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Tabitha Ng

- File: `deliverables/keepsake-card-r026.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - Junie Marsh

- File: `deliverables/keepsake-card-r027.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"keepsake_card_2019_press.pdf"}
- Content: The memorial name is correct. The wording remains respectful.

## Memorial keepsake card - combined production run

- File: `deliverables/keepsake-card-combined.pdf`
- Specification: {"format":"pdf","pages":26,"width_mm":105.156,"height_mm":148.167}
- Content: undefined

## Framed memorial page

- File: `deliverables/memorial-page.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The dates agree with the family record. The portrait identity is preserved.

## Family memory book

- File: `deliverables/memory-book.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":12}
- Content: The chronology follows the family notes. The eulogy is not rewritten. The images preserve documentary identity.

## Memorial share card

- File: `deliverables/share-card.png`
- Specification: {"format":"png","width":1200,"height":1200}
- Content: The memorial details are readable. The treatment is restrained.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
