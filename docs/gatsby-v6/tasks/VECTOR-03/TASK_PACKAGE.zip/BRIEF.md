# Apex Rally Club - Motorsport face and livery system

Six club badges rebuilt for pin and coin supplier review

Apex Rally Club needs six badge faces recovered from photographs for a pin and coin project. The references contain the colours and details we want to retain, but they are not reliable production drawings.

Deliverables
1. Motorsport face artwork: 6 named exports. The face design matches the named design record. The crest remains recognisable at the supplied reduction size.
2. Applied livery presentation: 1 named export. The graphics follow the vehicle panel boundaries. The livery hierarchy is readable at viewing distance.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The six rally faces and livery application are the commissioned outputs. Mint line-only manufacture variants, alternative colourway proofs and an edition insert in older supplier correspondence are reference requirements only, not extra files in this edition.
- Bind each design name to its own source drawing. Manufacturing limits apply to a production face only where the output register calls for that medium; do not impose a mint constraint on a colour livery visualization.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
