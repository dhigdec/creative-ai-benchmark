# VECTOR-03: delivery register

## Motorsport face artwork - Club Crest

- File: `deliverables/rally-face-r002.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The face design matches the named design record. The crest remains recognisable at the supplied reduction size.

## Motorsport face artwork - Hillclimb

- File: `deliverables/rally-face-r003.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The face design matches the named design record. The crest remains recognisable at the supplied reduction size.

## Motorsport face artwork - Night Stage

- File: `deliverables/rally-face-r004.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The face design matches the named design record. The crest remains recognisable at the supplied reduction size.

## Motorsport face artwork - Ice Trial

- File: `deliverables/rally-face-r005.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The face design matches the named design record. The crest remains recognisable at the supplied reduction size.

## Motorsport face artwork - Gravel Loop

- File: `deliverables/rally-face-r006.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The face design matches the named design record. The crest remains recognisable at the supplied reduction size.

## Motorsport face artwork - Finale

- File: `deliverables/rally-face-r007.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The face design matches the named design record. The crest remains recognisable at the supplied reduction size.

## Applied livery presentation

- File: `deliverables/livery.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The graphics follow the vehicle panel boundaries. The livery hierarchy is readable at viewing distance.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
