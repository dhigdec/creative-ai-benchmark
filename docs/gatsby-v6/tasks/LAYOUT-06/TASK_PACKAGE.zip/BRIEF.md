# Nordheim Atelier - Showroom line-card system

Showroom line cards for twelve looks, with a controlled editorial treatment

Nordheim Atelier is preparing for buyer appointments. Twelve looks were photographed over two days, including two outside as the light changed. We need one grey editorial treatment, but wool, shearling and gabardine must still read as different materials.

Deliverables
1. Showroom line card: 13 named exports. The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The eligible FW26 looks receive individual line cards and the combined run in register order. Include the approved style, fabrication and price fields; long press essays are not required on these product cards.
- Use the matching look photograph and recovered wordmark. The two 0.4 pt rules, their 3 mm gap, caption role and permitted price styling are production rules for the full individual-card run.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
