# LAYOUT-06: delivery register

## Showroom line card - 1

- File: `deliverables/line-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 2

- File: `deliverables/line-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 3

- File: `deliverables/line-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 4

- File: `deliverables/line-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 5

- File: `deliverables/line-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 6

- File: `deliverables/line-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 7

- File: `deliverables/line-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 8

- File: `deliverables/line-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 9

- File: `deliverables/line-card-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 10

- File: `deliverables/line-card-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 11

- File: `deliverables/line-card-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - 12

- File: `deliverables/line-card-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The pictured style matches this record. The photographed garment uses the fabric named in the Fabric Composition field. Material information is readable. The trade price is easy to locate.

## Showroom line card - combined production run

- File: `deliverables/line-card-combined.pdf`
- Specification: {"format":"pdf","pages":12,"width_mm":210,"height_mm":297}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
