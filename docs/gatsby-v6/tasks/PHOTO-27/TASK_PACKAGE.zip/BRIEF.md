# Fennhollow - Botanical soda summer campaign

Build a believable soda image set around two imperfect packshots

Fennhollow has two packshots that have already been pushed too far in retouching, and no lifestyle shoot. We need a product retoucher with a good eye for licensing compatible photography and for knowing when to stop correcting a damaged source.

Deliverables
1. Botanical soda summer key visual: 1 named export. The can artwork matches the approved product. The headline and can have a clear hierarchy.
2. Botanical ingredient carousel: 5 named exports. The featured ingredients match approved copy. The closing page contains the approved shopping action.
3. Soda retail display poster: 1 named export. The brand is visible at viewing size. The pack remains recognisable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The key visual, carousel and poster may feature supplied sellable flavours only. A missing packshot is declared unavailable; it is not fabricated. The five-slide carousel moves from product introduction to approved ingredients, cleared claim, serving/product detail and shopping action.
- Whitney Semibold is the subheading font. Flavour names keep the separate two-line Staatliches display treatment and Label Green rule. The cleared nutrition claim is copied without paraphrase wherever printed.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
