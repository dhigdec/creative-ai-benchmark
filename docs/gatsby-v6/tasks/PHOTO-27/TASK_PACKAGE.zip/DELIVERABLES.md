# PHOTO-27: delivery register

## Botanical soda summer key visual

- File: `deliverables/soda-keyvisual.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The can artwork matches the approved product. The headline and can have a clear hierarchy.

## Botanical ingredient carousel - Page 1

- File: `deliverables/ingredient-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured ingredients match approved copy. The closing page contains the approved shopping action.

## Botanical ingredient carousel - Page 2

- File: `deliverables/ingredient-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured ingredients match approved copy. The closing page contains the approved shopping action.

## Botanical ingredient carousel - Page 3

- File: `deliverables/ingredient-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured ingredients match approved copy. The closing page contains the approved shopping action.

## Botanical ingredient carousel - Page 4

- File: `deliverables/ingredient-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured ingredients match approved copy. The closing page contains the approved shopping action.

## Botanical ingredient carousel - Page 5

- File: `deliverables/ingredient-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured ingredients match approved copy. The closing page contains the approved shopping action.

## Soda retail display poster

- File: `deliverables/retail-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The brand is visible at viewing size. The pack remains recognisable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
