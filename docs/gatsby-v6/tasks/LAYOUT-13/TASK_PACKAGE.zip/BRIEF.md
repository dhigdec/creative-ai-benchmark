# Marisol Cove - Shoulder-season hospitality campaign

Shoulder-season hospitality campaign built from carefully matched photography

Marisol Cove needs a shoulder-season campaign that reflects the light we actually have. Most of the coastal pictures will be licensed; the usable room photographs are ours. The work is to make them belong together, not to promise a different coast or a different property.

Please prepare
- Shoulder-season key visual: 1 named export. The pictured property is correctly identified. The tagline is exactly “The quiet side of the coast.” No date, discount or unlisted amenity is added.
- Hospitality booking story: 1 named export. The booking action stays inside the safe area.
- Seasonal offer card: 10 named exports. The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.
- Seasonal hospitality brochure: 1 named export. The offer is understandable without the original brief. The property imagery is truthful.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use Shoulder Rate, not another rate column. Offer records keep their own room/rate/terms; the story and key visual draw from those same approved offers. Brochure room-rate entries are separate facts.
- Urbanist is the current headline/tagline font. Use the named owned room photograph where available. A missing room photograph can use a typography-led layout; a Stock preview is not a licensed deliverable and cannot be substituted as evidence of the actual room.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
