# LAYOUT-13: delivery register

## Shoulder-season key visual

- File: `deliverables/hospitality-keyvisual.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The pictured property is correctly identified. The tagline is exactly “The quiet side of the coast.” No date, discount or unlisted amenity is added.

## Hospitality booking story

- File: `deliverables/booking-story.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The booking action stays inside the safe area.

## Seasonal offer card - Bluff Suite

- File: `deliverables/season-offer-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Cypress Suite

- File: `deliverables/season-offer-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Cove View King

- File: `deliverables/season-offer-r004.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Cove View Queen

- File: `deliverables/season-offer-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Terrace Room

- File: `deliverables/season-offer-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Boathouse Loft

- File: `deliverables/season-offer-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Headland Room

- File: `deliverables/season-offer-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Garden Room

- File: `deliverables/season-offer-r009.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - Path Room

- File: `deliverables/season-offer-r010.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal offer card - The Boathouse

- File: `deliverables/season-offer-r011.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The words “Shoulder Rate” appear beside the supplied Shoulder Rate value. The property identity is visible.

## Seasonal hospitality brochure

- File: `deliverables/offer-brochure.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":4}
- Content: The offer is understandable without the original brief. The property imagery is truthful.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
