# MOTION-18: delivery register

## Performance film

- File: `deliverables/performance-film.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three visibly different supplied takes, the venue name “Velvet Hour”, and an end card billing the next show as “Next” with the act name “Junie Ash”, the date “Saturday, October 17, 2026”, the door time “Doors 7:30pm” and the price “$18”.

## Square performance cutdown

- File: `deliverables/performance-story.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":6,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: The singer held in frame throughout, the venue name “Velvet Hour” and the next show date “Saturday, October 17, 2026”.

## Next-show poster

- File: `deliverables/show-poster.pdf`
- Specification: {"format":"pdf","width_mm":420,"height_mm":594,"pages":1}
- Content: The billing order matches the lineup. The show date is accurate.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
