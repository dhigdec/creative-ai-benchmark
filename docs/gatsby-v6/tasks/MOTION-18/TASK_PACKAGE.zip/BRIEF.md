# Velvet Hour - Social film and story cutdowns

Velvet Hour needs a short film for the next show, a square cut for the feed and the next show poster. The camera sits in the same corner every month and it gives us short silent takes, a few seconds each, with no sound at all, so we are sending five more takes from that corner under the same lamp. Cut the film upright. It is filmed upright and that is where people will watch it.

No narration and no voice over. The words go on screen, set small and quietly, the way we write a listing. The music is the cleared instrumental bed we supply, not a recording of anyone's set, so nothing on these films is anyone's performance audio.

The commission
1. Performance film: 1 named export, 1080 by 1920, 12 to 15 seconds, music from the supplied bed. At least three different takes. The singer stays in frame. The end card bills the next show.
2. Square performance cutdown: 1 named export, 1080 by 1080, 6 to 10 seconds, music from the supplied bed. The singer stays in frame in the square crop.
3. Next show poster: 1 named export, unchanged at 420 by 594 mm, one page. The billing order matches the lineup and the show date is accurate.

Two things matter to us as much as the atmosphere. The act on the end card is next month's act, so bill her as next and do not attribute the footage in the film to her. The billing order, the dates and the prices come from the lineup file and are not ours to reorder or round.

One warning about the framing: the camera clears a pillar, so the singer sits in the left third of the picture and the centre of the frame is a stool and a pair of plain black road cases. A centred crop can be technically correct and still contain no performer, so check the crop rather than trusting it.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
Video delivery means a playable MP4, not a storyboard, a still montage PDF or an editing log. Audio expectations are stated on each film. No film in this commission carries speech: the message is carried by on screen text you set, and the music is the cleared bed we supply.
Authored animation can exceed the duration of still source images. Live action edits require adequate distinct footage; looping a short clip is not a substitute for missing coverage.
Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The calendar date is authoritative: the next show is Saturday, October 17, 2026. This V6 amendment corrects the erroneous Friday label in the old source/verifiers; the date itself does not move.
- Junie Ash is billed as the next act, not identified as the performer in the existing footage. Bind the poster and closing cards to the same corrected event details. Music is the cleared bed, not the performer's recorded set.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
