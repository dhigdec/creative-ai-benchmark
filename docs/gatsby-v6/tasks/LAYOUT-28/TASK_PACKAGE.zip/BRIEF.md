# SEVE Botanicals - Cosmetic launch label system

Nineteen cosmetic labels with exact ingredient copy and per-shade imagery

SEVE Botanicals needs a launch-label run across two price tiers. We have one physical sample photographed on a phone, nineteen drawdown images and a printer's flat PDF. The imagery needs careful preparation; the compliance copy is not open for creative rewriting.

What we need back
- Cosmetic launch label: 20 named exports. The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The approved roster selects Atelier or Everyday treatment. Copy INCI, claims and net contents without shortening. BatchFormat is a literal format placeholder from the record, not a made-up production batch number.
- Bind the drawdown image to its actual shade/SKU. Real shade swatches are exempt from the graphic brand palette. Use the separate tier name sizes and the fixed ingredients role.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
