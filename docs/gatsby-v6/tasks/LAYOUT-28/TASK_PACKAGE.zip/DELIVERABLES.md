# LAYOUT-28: delivery register

## Cosmetic launch label - ATL-101

- File: `deliverables/cosmetic-label-r002.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - ATL-102

- File: `deliverables/cosmetic-label-r003.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - ATL-103

- File: `deliverables/cosmetic-label-r004.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - ATL-104

- File: `deliverables/cosmetic-label-r005.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - ATL-105

- File: `deliverables/cosmetic-label-r006.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - ATL-106

- File: `deliverables/cosmetic-label-r007.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - ATL-107

- File: `deliverables/cosmetic-label-r008.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-208

- File: `deliverables/cosmetic-label-r009.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-209

- File: `deliverables/cosmetic-label-r010.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-210

- File: `deliverables/cosmetic-label-r011.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-211

- File: `deliverables/cosmetic-label-r012.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-212

- File: `deliverables/cosmetic-label-r013.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-213

- File: `deliverables/cosmetic-label-r014.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-214

- File: `deliverables/cosmetic-label-r015.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-215

- File: `deliverables/cosmetic-label-r016.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-216

- File: `deliverables/cosmetic-label-r017.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-217

- File: `deliverables/cosmetic-label-r018.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-218

- File: `deliverables/cosmetic-label-r019.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - EVR-219

- File: `deliverables/cosmetic-label-r020.pdf`
- Specification: {"format":"pdf","width_mm":57.827,"height_mm":92.117,"pages":1,"template_reference":"serum_label_PRESS.pdf"}
- Content: The ingredient wording matches approved copy. The BatchFormat value is present as an unobscured content element. The net contents value is readable.

## Cosmetic launch label - combined production run

- File: `deliverables/cosmetic-label-combined.pdf`
- Specification: {"format":"pdf","pages":19,"width_mm":57.827,"height_mm":92.117}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
