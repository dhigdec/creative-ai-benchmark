# Continental Cup - Player portrait card system

Eight-player card run with matched portraits and checked player identities

Continental Cup needs the eight-player release prepared from the supplied portraits and roster. The pictures come from two stadium lighting rigs; the cards come from a printer's PDF we need to make usable again.

Final handoff

 Player press card: 9 named exports. The portrait belongs to the named player. The player number is legible. The competition identity is visible.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use only the eligible tournament roster and the supplied licensing wording. Withdrawn players remain excluded from the individual cards and combined production file.
- Do not shorten a licensing line to make it fit. Reflow within the card using its fine-print rules. Match each player's name, affiliation and portrait before applying the new card typography; photographed jersey lettering stays untouched.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
