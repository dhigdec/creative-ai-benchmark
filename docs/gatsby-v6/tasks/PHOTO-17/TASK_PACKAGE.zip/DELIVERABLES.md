# PHOTO-17: delivery register

## Player press card - Diego Solano

- File: `deliverables/player-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Marco Ferraz

- File: `deliverables/player-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Theo Rocher

- File: `deliverables/player-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Luka Petrov

- File: `deliverables/player-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Rafael Duarte

- File: `deliverables/player-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Nikolai Ivanic

- File: `deliverables/player-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Callum Reid

- File: `deliverables/player-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - Mattias Holm

- File: `deliverables/player-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":63.5,"height_mm":88.9,"pages":1,"template_reference":"cup26_card_2025_PRINTER.pdf"}
- Content: The portrait belongs to the named player. The player number is legible. The competition identity is visible.

## Player press card - combined production run

- File: `deliverables/player-card-combined.pdf`
- Specification: {"format":"pdf","pages":8,"width_mm":63.5,"height_mm":88.9}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
