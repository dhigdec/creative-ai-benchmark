# Fernwell & Rowe - Hartley wedding gallery finishing

Wedding retouching pilot: one warm house look across changing light

We are Fernwell & Rowe, and this is a pilot using the Hartley wedding shortlist. There are sixteen photographs spanning window light, golden hour and the reception. We want a natural warm treatment that holds together through those changes without giving every person the same skin colour.

Scope
1. Wedding review image: 16 named exports. The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.
2. Full-resolution wedding keeper: 6 named exports. The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- For this benchmark, the six keeper source files already named in the output register are the preapproved couple selection. This replaces the older note asking for a later confirmation. The sixteen review files remain required.
- These are unbranded photographic exports with no added text. Keep the warm finish consistent while preserving source skin tones, white clothing and garden greens. A frame that cannot take the treatment is delivered conservatively with its limitation identified, not omitted or forced.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
