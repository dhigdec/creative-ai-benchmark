# PHOTO-18: delivery register

## Wedding review image - hartley_select_01

- File: `deliverables/review-hartley-select-01.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_02

- File: `deliverables/review-hartley-select-02.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_03

- File: `deliverables/review-hartley-select-03.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_04

- File: `deliverables/review-hartley-select-04.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_05

- File: `deliverables/review-hartley-select-05.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_06

- File: `deliverables/review-hartley-select-06.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_07

- File: `deliverables/review-hartley-select-07.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_08

- File: `deliverables/review-hartley-select-08.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_09

- File: `deliverables/review-hartley-select-09.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_10

- File: `deliverables/review-hartley-select-10.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_11

- File: `deliverables/review-hartley-select-11.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_12

- File: `deliverables/review-hartley-select-12.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_13

- File: `deliverables/review-hartley-select-13.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_14

- File: `deliverables/review-hartley-select-14.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_15

- File: `deliverables/review-hartley-select-15.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Wedding review image - hartley_select_16

- File: `deliverables/review-hartley-select-16.jpg`
- Specification: {"format":"jpg","long_edge":1600}
- Content: The people retain their source identities. Skin retains natural texture. The scene remains faithful to the event.

## Full-resolution wedding keeper - hartley_select_01

- File: `deliverables/keeper-hartley-select-01.png`
- Specification: {"format":"png","source_dimensions":true,"width":4000,"height":6000}
- Content: The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.

## Full-resolution wedding keeper - hartley_select_05

- File: `deliverables/keeper-hartley-select-05.png`
- Specification: {"format":"png","source_dimensions":true,"width":6000,"height":4000}
- Content: The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.

## Full-resolution wedding keeper - hartley_select_08

- File: `deliverables/keeper-hartley-select-08.png`
- Specification: {"format":"png","source_dimensions":true,"width":6000,"height":4000}
- Content: The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.

## Full-resolution wedding keeper - hartley_select_11

- File: `deliverables/keeper-hartley-select-11.png`
- Specification: {"format":"png","source_dimensions":true,"width":6000,"height":4000}
- Content: The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.

## Full-resolution wedding keeper - hartley_select_13

- File: `deliverables/keeper-hartley-select-13.png`
- Specification: {"format":"png","source_dimensions":true,"width":6000,"height":4000}
- Content: The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.

## Full-resolution wedding keeper - hartley_select_16

- File: `deliverables/keeper-hartley-select-16.png`
- Specification: {"format":"png","source_dimensions":true,"width":6000,"height":4000}
- Content: The delivered keeper is derived from its named source photograph. Highlight detail is retained where present in the source.
