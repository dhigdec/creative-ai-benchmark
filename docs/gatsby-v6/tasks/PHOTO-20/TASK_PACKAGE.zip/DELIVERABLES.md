# PHOTO-20: delivery register

## Speaker booking one-pager

- File: `deliverables/speaker-onepager.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The biography preserves approved facts. The talk offer is clear. The booking contact is readable.

## Confirmed-talk speaker announcement - Northlight Design Forum - Designing the thing before the deck

- File: `deliverables/event-announcement-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The event name is visible. The event date matches this talk record. The speaker name is clear.

## Confirmed-talk speaker announcement - Made & Kept - Six people, one hand

- File: `deliverables/event-announcement-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The event name is visible. The event date matches this talk record. The speaker name is clear.

## Confirmed-talk speaker announcement - Continuum Product Days - What survives contact with a factory

- File: `deliverables/event-announcement-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The event name is visible. The event date matches this talk record. The speaker name is clear.

## Confirmed-talk speaker banner - Northlight Design Forum - Designing the thing before the deck

- File: `deliverables/event-banner-r002.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The banner identifies this talk. The supplied talk portrait belongs to this record.

## Confirmed-talk speaker banner - Made & Kept - Six people, one hand

- File: `deliverables/event-banner-r003.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The banner identifies this talk. The supplied talk portrait belongs to this record.

## Confirmed-talk speaker banner - Continuum Product Days - What survives contact with a factory

- File: `deliverables/event-banner-r008.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The banner identifies this talk. The supplied talk portrait belongs to this record.

## Speaker talk card - Northlight Design Forum - Designing the thing before the deck

- File: `deliverables/talk-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - Made & Kept - Six people, one hand

- File: `deliverables/talk-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - Fjordworks Summit - On staying small on purpose

- File: `deliverables/talk-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - Fjordworks Summit - The room after the round

- File: `deliverables/talk-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - Halden Design Days - From sketch to tooling

- File: `deliverables/talk-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - The Bench Sessions - Designing for the next hands

- File: `deliverables/talk-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - Continuum Product Days - What survives contact with a factory

- File: `deliverables/talk-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - Grain & Frame Forum - What a small studio can promise

- File: `deliverables/talk-card-r009.pdf`
- Specification: {"format":"pdf","width_mm":105.156,"height_mm":148.167,"pages":1,"template_reference":"vellacourt_speakercard_template.pdf"}
- Content: The talk title matches this record. The event identity is visible.

## Speaker talk card - combined production run

- File: `deliverables/talk-card-combined.pdf`
- Specification: {"format":"pdf","pages":8,"width_mm":105.156,"height_mm":148.167}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
