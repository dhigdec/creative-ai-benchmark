# Astrid Vellacourt - Editorial portrait session

A coherent speaking and investor image set for an industrial-design founder

I am preparing speaking and investor materials for Astrid Vellacourt. The photographs and supporting pieces need to feel like the same person and practice: considered, credible and recognisably connected to industrial design.

The commission

 Speaker booking one-pager: 1 named export. The biography preserves approved facts. The talk offer is clear. The booking contact is readable.

 Confirmed-talk speaker announcement: 3 named exports. The event name is visible. The event date matches this talk record. The speaker name is clear.

 Confirmed-talk speaker banner: 3 named exports. The banner identifies this talk. The supplied talk portrait belongs to this record.

 Speaker talk card: 9 named exports. The talk title matches this record. The event identity is visible.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The one-pager uses the approved biography; event announcements and banners use their assigned event records; talk cards use their assigned talks. Portrait choices may vary within the approved session, but the exact frame is named for each output.
- Recover the AV monogram from its source and keep it separate from newly typeset copy. Apply print point sizes only to print formats and screen equivalents to raster banners/cards. Check hair edges on the delivered placement ground.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
