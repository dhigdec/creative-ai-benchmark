# Continental Cup - Squad press and partner kit

Expand our licensed player-card production to the full stocked squad

The licensing partner has taken the full Continental Cup squad. We now need the eighteen-player material reconciled against the stock roster and produced from last season's printer PDF.

Scope
1. Squad player press sheet: 19 named exports. The portrait belongs to the named player. The squad facts match the register.
2. Player partner graphic: 18 named exports. The player number is clear. The competition identity is visible.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the eighteen approved players for the individual press sheets, combined file and partner graphics. The registered PDF/PNG outputs and source handoff are the delivery; extra 600 dpi proof files mentioned in the older printer note are not separately commissioned.
- Keep the source-resolution limitation visible; interpolation does not create missing player detail. Preserve the exact contractual copy and its ordered fields. Print PDFs use the registered trim with a 3 mm bleed box.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
