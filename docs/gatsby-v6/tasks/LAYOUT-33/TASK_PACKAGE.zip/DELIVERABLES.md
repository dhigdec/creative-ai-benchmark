# LAYOUT-33: delivery register

## Squad player press sheet - Kofi Adjei

- File: `deliverables/player-press-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Lucas Almeida

- File: `deliverables/player-press-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Rafael Duarte

- File: `deliverables/player-press-r004.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Bruno Ferraz

- File: `deliverables/player-press-r005.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Marco Ferraz

- File: `deliverables/player-press-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Omar Haddad

- File: `deliverables/player-press-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Viktor Halic

- File: `deliverables/player-press-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Nikolai Ivanic

- File: `deliverables/player-press-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Emil Larsson

- File: `deliverables/player-press-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Hugo Marchand

- File: `deliverables/player-press-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Andre Mensah

- File: `deliverables/player-press-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Pavel Novak

- File: `deliverables/player-press-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Samuel Okoye

- File: `deliverables/player-press-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Luka Petrov

- File: `deliverables/player-press-r016.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Theo Rocher

- File: `deliverables/player-press-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Mateo Rossi

- File: `deliverables/player-press-r018.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Diego Solano

- File: `deliverables/player-press-r019.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - Yuki Tanaka

- File: `deliverables/player-press-r020.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":1}
- Content: The portrait belongs to the named player. The squad facts match the register.

## Squad player press sheet - combined production run

- File: `deliverables/player-press-combined.pdf`
- Specification: {"format":"pdf","pages":18,"width_mm":210,"height_mm":297}
- Content: undefined

## Player partner graphic - Kofi Adjei

- File: `deliverables/partner-player-r002.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Lucas Almeida

- File: `deliverables/partner-player-r003.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Rafael Duarte

- File: `deliverables/partner-player-r004.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Bruno Ferraz

- File: `deliverables/partner-player-r005.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Marco Ferraz

- File: `deliverables/partner-player-r006.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Omar Haddad

- File: `deliverables/partner-player-r007.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Viktor Halic

- File: `deliverables/partner-player-r008.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Nikolai Ivanic

- File: `deliverables/partner-player-r009.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Emil Larsson

- File: `deliverables/partner-player-r011.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Hugo Marchand

- File: `deliverables/partner-player-r012.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Andre Mensah

- File: `deliverables/partner-player-r013.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Pavel Novak

- File: `deliverables/partner-player-r014.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Samuel Okoye

- File: `deliverables/partner-player-r015.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Luka Petrov

- File: `deliverables/partner-player-r016.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Theo Rocher

- File: `deliverables/partner-player-r017.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Mateo Rossi

- File: `deliverables/partner-player-r018.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Diego Solano

- File: `deliverables/partner-player-r019.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Player partner graphic - Yuki Tanaka

- File: `deliverables/partner-player-r020.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The player number is clear. The competition identity is visible.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
