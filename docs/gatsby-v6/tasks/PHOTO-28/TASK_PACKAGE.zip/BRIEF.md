# Verda Reformer Studio - Fitness campaign image system

A calm launch image system for a reformer studio with a limited shoot

Verda is a reformer studio, and the launch should feel calm, approachable and grounded in the room we actually have. Our two room photographs are dusky. We need them prepared alongside suitable licensed movement imagery, not replaced by a fictional studio.

Please prepare
- Studio launch-page composition: 1 named export. The studio location is accurate. The class offer is clear. The booking action is visible.
- Class announcement: 1 named export. The class details match the approved roster. The pictured instructor is identified accurately.
- Studio booking story: 1 named export. The booking action is inside the safe area. The studio identity is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- This commission is the studio launch, class feed and booking story only, not instructor passes. Use the current approved roster/schedule; departed Erin is excluded from all three outputs, including background/group appearances.
- Use an eligible class or instructor image and name the selected file for each canvas. Copy only supplied class names, schedule details and booking contact; do not invent a session time.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
