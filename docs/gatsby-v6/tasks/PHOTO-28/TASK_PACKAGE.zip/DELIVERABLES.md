# PHOTO-28: delivery register

## Studio launch-page composition

- File: `deliverables/studio-launch.png`
- Specification: {"format":"png","width":1440,"height":2400}
- Content: The studio location is accurate. The class offer is clear. The booking action is visible.

## Class announcement

- File: `deliverables/class-feed.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The class details match the approved roster. The pictured instructor is identified accurately.

## Studio booking story

- File: `deliverables/booking-story.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The booking action is inside the safe area. The studio identity is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
