# PHOTO-11: delivery register

## Retailer shade card - Bronze Hour

- File: `deliverables/shade-card-r002.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - Rosewood

- File: `deliverables/shade-card-r003.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - Amber Hour

- File: `deliverables/shade-card-r004.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - Coral Flash

- File: `deliverables/shade-card-r005.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - Peach Noon

- File: `deliverables/shade-card-r006.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - Mulberry

- File: `deliverables/shade-card-r007.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - Clear Dawn

- File: `deliverables/shade-card-r008.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":1}
- Content: The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

## Retailer shade card - combined production run

- File: `deliverables/shade-card-combined.pdf`
- Specification: {"format":"pdf","pages":7,"width_mm":55,"height_mm":85}
- Content: undefined

## Seven-shade comparison

- File: `deliverables/shade-comparison.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The seven approved shade names are present. The shades appear in the approved range order. The concept-colour notice is readable.

## Lip oil product-page module

- File: `deliverables/product-page.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The product name is accurate. The benefit uses the approved claim wording. The concept-colour notice is readable.

## Lip oil launch feed ad

- File: `deliverables/launch-feed.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: Lumora is identified. The call to action is readable at mobile size. The product edge has no visible halo. The concept-colour notice is readable.

## Lip oil launch story

- File: `deliverables/launch-story.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The headline is readable at mobile size. The call to action remains within the safe area. The concept-colour notice is readable.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
