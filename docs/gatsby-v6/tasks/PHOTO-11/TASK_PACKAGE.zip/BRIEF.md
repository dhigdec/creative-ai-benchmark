# Lumora - Lip oil shade concept set

Lip-oil shade concepts for a launch that has one physical sample

Important before you quote: Lumora has one physical lip-oil sample, not seven approved production shades. This is concept-colour work. Every result must say CONCEPT COLOR - SAMPLE APPROVAL REQUIRED.

Final handoff

 Retailer shade card: 8 named exports. The bottle keeps the approved packaging geometry. The concept-colour notice is readable. The displayed shade agrees with its shade name.

 Seven-shade comparison: 1 named export. The seven approved shade names are present. The shades appear in the approved range order. The concept-colour notice is readable.

 Lip oil product-page module: 1 named export. The product name is accurate. The benefit uses the approved claim wording. The concept-colour notice is readable.

 Lip oil launch feed ad: 1 named export. Lumora is identified. The call to action is readable at mobile size. The product edge has no visible halo. The concept-colour notice is readable.

 Lip oil launch story: 1 named export. The headline is readable at mobile size. The call to action remains within the safe area. The concept-colour notice is readable.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
- Every shade concept must show CONCEPT COLOR - SAMPLE APPROVAL REQUIRED. Only Amber Hour is the physical-sample reference.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Amber Hour is the physical reference sample; the other supplied shades are labelled concept colours. The exact notice CONCEPT COLOR - SAMPLE APPROVAL REQUIRED appears on a shade card that is not Amber Hour and on a campaign output showing any concept shade. Do not label the unchanged Amber Hour physical sample as a concept.
- Use the supplied sample bottle geometry for concepts, without changing cap, glass or label proportions. The comparison contains the seven named shades; the combined card file is a package, not an eighth shade. For the 55 by 85 mm card, use a lowercase shade name at 32 pt on 34 pt; retain spaces and wrap between words. Screen shade names use 96 px on 102 px. These explicit sizes replace the incompatible 96 pt card size and roughly-five-times-body description.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
