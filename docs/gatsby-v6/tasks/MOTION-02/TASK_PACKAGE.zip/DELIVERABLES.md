# MOTION-02: delivery register

## Lunch range launch film

- File: `deliverables/product-launch.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least five different supplied takes, bowls drawn from the supplied stills and clips, the price “$12”, and a closing card carrying the wordmark “Ironwood Kitchen”.

## Lunch launch upright cutdown

- File: `deliverables/vertical-cut.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":8,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: One complete uncropped bowl inside the first two seconds, the price “$12”, and the wordmark “Ironwood Kitchen” on the closing frame.

## Lunch bowl product module - Chipotle Chicken & Brown Rice

- File: `deliverables/bowl-module-01.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Seared Steak & Sweet Potato

- File: `deliverables/bowl-module-02.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Kale Caesar Chicken

- File: `deliverables/bowl-module-03.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Salsa Verde Pork

- File: `deliverables/bowl-module-04.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Harissa Turkey & Freekeh

- File: `deliverables/bowl-module-05.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Teriyaki Salmon & Rice

- File: `deliverables/bowl-module-06.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Sesame Peanut Tofu

- File: `deliverables/bowl-module-07.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch bowl product module - Breakfast Egg & Greens

- File: `deliverables/bowl-module-08.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: Complete bowl in frame. No reference card. Price $12.

## Lunch range line sheet

- File: `deliverables/lunch-line-sheet.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":2}
- Content: Pages 1 and 2 show bowls 1-4 and 5-8 respectively, in ironwood_skus.csv order. A bowl entry contains its named photo, bowl name, $12 price, full macro line and full allergen line. The long description is not printed in the line sheet.

## Ironwood lunch film cover

- File: `deliverables/film-cover.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: Ironwood Kitchen $12

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
