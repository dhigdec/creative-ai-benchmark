# Ironwood Kitchen - Product launch video package

Ironwood Kitchen is introducing the lunch range and we want it cut short and honest. What came back from the kitchen is one five second take, which is nowhere near a film, so the completed source pack adds the missing coverage and a cleared instrumental bed before anyone starts editing. Nothing here is narrated. These play muted in a feed and on the site, so the words sit on screen and the bed does the rest.

Please build a 12 to 15 second launch film in 16:9, cut from at least five different takes, and an 8 to 10 second upright cutdown that puts a complete bowl on screen inside the first two seconds. Both carry the supplied bed, both close on the Ironwood Kitchen wordmark, and both show the price “$12” exactly as ironwood_skus.csv has it. Keep the claims to the two cleared lines in ironwood_notes.txt, the protein per bowl and the no added sugar in dressings. Anything past those two lines is not approved and we will send it back.

The rest of the package is unchanged. We still need the eight bowl product modules with the complete bowl in frame and no reference card, the two page lunch range line sheet with names bound to the SKU register, and the film cover.

Production decisions for this edition
- Retain eight bowl product modules, the two-page lunch-range line sheet and film cover alongside the two music-only videos. The wide film uses at least five distinct takes; the vertical shows a complete bowl within the first two seconds.
- The exact price is $12. Only the supplied protein-per-bowl and no-added-sugar-in-dressings claims are permitted. The Schibsted name/price pair shares a baseline and size, with one em between them.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
