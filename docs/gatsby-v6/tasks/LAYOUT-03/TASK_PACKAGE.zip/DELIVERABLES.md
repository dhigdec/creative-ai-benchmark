# LAYOUT-03: delivery register

## Retail product-page module - Lumora C-15 Brightening Serum

- File: `deliverables/sku-module-r002.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The pack matches the named SKU. The approved benefit is readable.

## Retail product-page module - Lumora Niacinamide Clarifying Serum

- File: `deliverables/sku-module-r003.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The pack matches the named SKU. The approved benefit is readable.

## Retail product-page module - Lumora Retinal Renewal Night Serum

- File: `deliverables/sku-module-r004.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The pack matches the named SKU. The approved benefit is readable.

## Retail product-page module - Lumora Peptide Barrier Cream

- File: `deliverables/sku-module-r005.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The pack matches the named SKU. The approved benefit is readable.

## Retail product-page module - Lumora HA + PGA Hydrating Serum

- File: `deliverables/sku-module-r006.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The pack matches the named SKU. The approved benefit is readable.

## Retail product-page module - Lumora Azelaic Redness Serum

- File: `deliverables/sku-module-r007.png`
- Specification: {"format":"png","width":1440,"height":1800}
- Content: The pack matches the named SKU. The approved benefit is readable.

## Retail launch carousel - Page 1

- File: `deliverables/retail-carousel-p01.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The sequence differentiates the products. The brand appears on the opening page.

## Retail launch carousel - Page 2

- File: `deliverables/retail-carousel-p02.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The sequence differentiates the products. The brand appears on the opening page.

## Retail launch carousel - Page 3

- File: `deliverables/retail-carousel-p03.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The sequence differentiates the products. The brand appears on the opening page.

## Retail launch carousel - Page 4

- File: `deliverables/retail-carousel-p04.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The sequence differentiates the products. The brand appears on the opening page.

## Retail launch carousel - Page 5

- File: `deliverables/retail-carousel-p05.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The sequence differentiates the products. The brand appears on the opening page.

## Retail launch carousel - Page 6

- File: `deliverables/retail-carousel-p06.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The sequence differentiates the products. The brand appears on the opening page.

## Paid social creative - Hero product

- File: `deliverables/paid-ad-hero-product.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The approved product claim is unchanged. The shopping action is clear.

## Paid social creative - Range comparison

- File: `deliverables/paid-ad-range-comparison.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The approved product claim is unchanged. The shopping action is clear.

## Paid social creative - Benefit story

- File: `deliverables/paid-ad-benefit-story.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The approved product claim is unchanged. The shopping action is clear.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
