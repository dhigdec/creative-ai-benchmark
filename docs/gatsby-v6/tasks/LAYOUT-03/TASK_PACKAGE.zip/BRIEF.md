# Lumora Laboratories - Retail launch and paid social system

Six-product retail launch: one image standard across store and paid social

Lumora Laboratories is preparing six products for specialty retail and a rebuilt store page. The photographs currently do not read as one line. We need the image foundations corrected and carried into editable launch material.

Scope
1. Retail product-page module: 6 named exports. The pack matches the named SKU. The approved benefit is readable.
2. Retail launch carousel: 6 named exports. The sequence differentiates the products. The brand appears on the opening page.
3. Paid social creative: 3 named exports. The approved product claim is unchanged. The shopping action is clear.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Set the concentration in IBM Plex Mono Regular at the H1 scale size; it remains exactly twice the product-name size. Product names use Spectral Medium. This overrides the former Spectral concentration entry and the older sans-product-name verifier.
- The six modules keep their own SKU, INCI and claim records. Carousel pages follow SKU order; paid-ad concepts may choose those eligible SKUs, identifying the selected record and packshot. Fixed claims and INCI are not paraphrased.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
