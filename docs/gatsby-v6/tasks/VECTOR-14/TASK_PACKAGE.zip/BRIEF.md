# Ironway Run Club - Numbering and club mark system

Rebuild our club lettering and use it in the Founders Five bib run

Ironway Run Club's lettering comes from Del's 1994 drawings. We want the ten numerals, twenty-six letters and singlet logo made usable again, followed by the Founders Five bib production.

The commission

 Ironway club mark: 1 named export. The source club identity is preserved.

 Race numeral: 10 named exports. The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

 Club letter glyph: 26 named exports. The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

 Founders Five member bib: 36 named exports. The runner number matches this member. The number is the dominant visual.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The printed member bib uses the 120 pt restored numeral under the 14 pt club name. The supplier's 8-inch height is for a singlet heat transfer, not the 148 mm-high paper bib.
- The ten numerals and twenty-six letters are recovered from Del's drawings. Test heat-transfer strokes at 8-inch height against the 3 mm limit and pressing box; test printed bib typography at its own size. Keep roster exclusions and assigned numbers from the approved register.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
