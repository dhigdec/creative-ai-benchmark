# VECTOR-14: delivery register

## Ironway club mark

- File: `deliverables/club-mark.svg`
- Specification: {"format":"svg","transparent":true}
- Content: The source club identity is preserved.

## Race numeral - 0

- File: `deliverables/number-0.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 1

- File: `deliverables/number-1.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 2

- File: `deliverables/number-2.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 3

- File: `deliverables/number-3.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 4

- File: `deliverables/number-4.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 5

- File: `deliverables/number-5.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 6

- File: `deliverables/number-6.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 7

- File: `deliverables/number-7.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 8

- File: `deliverables/number-8.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Race numeral - 9

- File: `deliverables/number-9.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The numeral is distinguishable from similar digits at viewing distance. The numeral follows Del's 1994 drawing.

## Club letter glyph - A

- File: `deliverables/letter-a.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - B

- File: `deliverables/letter-b.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - C

- File: `deliverables/letter-c.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - D

- File: `deliverables/letter-d.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - E

- File: `deliverables/letter-e.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - F

- File: `deliverables/letter-f.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - G

- File: `deliverables/letter-g.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - H

- File: `deliverables/letter-h.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - I

- File: `deliverables/letter-i.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - J

- File: `deliverables/letter-j.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - K

- File: `deliverables/letter-k.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - L

- File: `deliverables/letter-l.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - M

- File: `deliverables/letter-m.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - N

- File: `deliverables/letter-n.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - O

- File: `deliverables/letter-o.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - P

- File: `deliverables/letter-p.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - Q

- File: `deliverables/letter-q.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - R

- File: `deliverables/letter-r.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - S

- File: `deliverables/letter-s.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - T

- File: `deliverables/letter-t.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - U

- File: `deliverables/letter-u.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - V

- File: `deliverables/letter-v.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - W

- File: `deliverables/letter-w.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - X

- File: `deliverables/letter-x.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - Y

- File: `deliverables/letter-y.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Club letter glyph - Z

- File: `deliverables/letter-z.svg`
- Specification: {"format":"svg","transparent":true,"closed_paths":true}
- Content: The letter follows Del's 1994 drawing. The weight is consistent with the restored set.

## Founders Five member bib - Del Marchetti

- File: `deliverables/member-bib-r002.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Marcus Abernathy

- File: `deliverables/member-bib-r003.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Nina Alvarez

- File: `deliverables/member-bib-r006.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Su Yun

- File: `deliverables/member-bib-r007.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Priya Venkataraman

- File: `deliverables/member-bib-r008.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Danielle Osei

- File: `deliverables/member-bib-r009.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Persephone Braithwaite-Ashcombe

- File: `deliverables/member-bib-r010.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Frank Ianelli

- File: `deliverables/member-bib-r011.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Beth Sorensen

- File: `deliverables/member-bib-r012.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Jamal Whitfield

- File: `deliverables/member-bib-r013.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Olivia Park

- File: `deliverables/member-bib-r014.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Hector Ramos

- File: `deliverables/member-bib-r015.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Meghan O'Doherty

- File: `deliverables/member-bib-r016.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Wei Chen

- File: `deliverables/member-bib-r017.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Gabriela Santos

- File: `deliverables/member-bib-r018.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Andy Poole

- File: `deliverables/member-bib-r019.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Rachel Kaminski

- File: `deliverables/member-bib-r020.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Terrence Bell

- File: `deliverables/member-bib-r022.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Sandra Delacroix

- File: `deliverables/member-bib-r023.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Kevin Nguyen

- File: `deliverables/member-bib-r024.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Aisha Rahman

- File: `deliverables/member-bib-r025.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Bruno Kowalczyk

- File: `deliverables/member-bib-r026.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Lucia Ferrante

- File: `deliverables/member-bib-r027.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Derek Holloway

- File: `deliverables/member-bib-r028.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Nadia Petrov

- File: `deliverables/member-bib-r029.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Sam Okafor

- File: `deliverables/member-bib-r030.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Ingrid Larsson

- File: `deliverables/member-bib-r031.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Carlos Mendez

- File: `deliverables/member-bib-r032.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Fiona MacGregor

- File: `deliverables/member-bib-r033.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Trevor Boyd

- File: `deliverables/member-bib-r034.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Yara Haddad

- File: `deliverables/member-bib-r035.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Peter Nakamura

- File: `deliverables/member-bib-r036.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Grace Abello

- File: `deliverables/member-bib-r037.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Vince Russo

- File: `deliverables/member-bib-r038.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - Harriet Blackwell

- File: `deliverables/member-bib-r039.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":148,"pages":1}
- Content: The runner number matches this member. The number is the dominant visual.

## Founders Five member bib - combined production run

- File: `deliverables/member-bib-combined.pdf`
- Specification: {"format":"pdf","pages":35,"width_mm":210,"height_mm":148}
- Content: undefined

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
