# Pulsevault - Event recap package

Saturday was the best room we have had all year and we want it up while people still remember being in it. Make it feel like our room and our crowd, not a generic festival montage. Cut it upright, because that is how the night was filmed and that is where it goes. The clips we handed over are short and silent, so the night is carried by the cut and by the type on screen. Nobody talks in these films: no voice over, no narration, no fake crowd audio. We are supplying the instrumental bed and it is cleared for this use, so use that and nothing else.

What we need back
1. Saturday recap film: 1 named export, 1080 by 1920, 12 to 15 seconds, music from the supplied bed. At least three different clips from the pack. The closing card carries the next date and the ticket link.
2. Square recap cutdown: 1 named export, 1080 by 1080, 6 to 10 seconds, same bed, tighter, for the feed.
3. Event recap cover: 1 named export, unchanged at 1080 by 1350. The event identity is readable.
4. Next event announcement: 1 named export, unchanged at 1080 by 1920. The date matches the approved next date file and the ticket action stays in the safe area.

Things that get a cut sent straight back: the warehouse address on anything public (it goes out with the ticket, never on the post), the pocket clip that is nothing but black, and the same drop cut in twice because two phones filmed it from a few feet apart. The running order in the lineup file is the running order, so do not reorder it, and do not substitute stock attendees for our crowd.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.
Video delivery means a playable MP4, not a storyboard, a still montage PDF or an editing log. Audio expectations are stated on each film. No film in this commission carries speech: the message is carried by on screen text you set, and any music is the cleared bed we supply.
Authored animation can exceed the duration of still source images. Live action edits require adequate distinct footage; looping a short clip is not a substitute for missing coverage.
Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- Use the supplied next-event date, billing order and age/ticket copy. The withheld public address remains withheld. Editable next-event copy is included in the source handoff.
- The intentional Didot headline crop applies only to decorative event lettering. Mandatory date, ticket, age and billing details remain fully visible. Recover the painted wall mark rather than retyping it.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
