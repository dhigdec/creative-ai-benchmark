# MOTION-17: delivery register

## Saturday recap film

- File: `deliverables/event-recap.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three visibly different supplied clips, the painted Pulsevault wordmark from pulsevault_wall_mark.jpg, and a closing card carrying the next date “Saturday, October 17” and the ticket link “pulsevault.example/tickets”. No street address anywhere in the film.

## Square recap cutdown

- File: `deliverables/recap-square.mp4`
- Specification: {"format":"mp4","width":1080,"height":1080,"ratio":"1:1","duration_seconds":{"min":6,"max":10},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three visibly different supplied clips, the painted Pulsevault wordmark, the next date “Saturday, October 17” and the tagline “made in the room”. No street address.

## Event recap cover

- File: `deliverables/event-cover.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The event identity is readable.

## Next-event announcement

- File: `deliverables/next-event.png`
- Specification: {"format":"png","width":1080,"height":1920,"safe_area":{"top":250,"bottom":320,"left":60,"right":60}}
- Content: The date matches the approved next-date file. The ticket action remains in the safe area.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
