# Cedarline and Vale - Ridgeway Lane listing image system

Bring a mixed-light property shoot together for Ridgeway Lane

Property: Ridgeway Lane
Source: twelve room photographs
Use: listing gallery, portal crops and tall lead-room placements

Deliverables
1. Ridgeway Lane listing brochure: 1 named export. The cover identifies the actual property. The room sequence explains the property layout. Every property claim agrees with the supplied listing facts. The contact page includes the approved agent details.
2. Property portal hero: 1 named export. The hero depicts Ridgeway Lane rather than a stock property. The architectural verticals look plausible.
3. Room announcement: 3 named exports. The featured room matches the named property. The enquiry action is visible.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- This commission covers Ridgeway Lane only, with the approved active-listing record in the V6 register. The property brochure, portal hero and three room posts are the complete scope; older office window-card requests are not part of this delivery.
- Room photographs may be chosen only from the supplied Ridgeway Lane set. Identify the selected filename for each page or post. Keep the original windows, exterior views and sky; do not create an unavailable view.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
