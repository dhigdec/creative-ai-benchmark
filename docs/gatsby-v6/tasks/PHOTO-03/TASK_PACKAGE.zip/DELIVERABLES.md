# PHOTO-03: delivery register

## Ridgeway Lane listing brochure

- File: `deliverables/listing-brochure.pdf`
- Specification: {"format":"pdf","width_mm":210,"height_mm":297,"pages":6}
- Content: The cover identifies the actual property. The room sequence explains the property layout. Every property claim agrees with the supplied listing facts. The contact page includes the approved agent details.

## Property portal hero

- File: `deliverables/portal-hero.png`
- Specification: {"format":"png","width":1920,"height":1080}
- Content: The hero depicts Ridgeway Lane rather than a stock property. The architectural verticals look plausible.

## Room announcement - Living

- File: `deliverables/room-post-living.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured room matches the named property. The enquiry action is visible.

## Room announcement - Kitchen

- File: `deliverables/room-post-kitchen.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured room matches the named property. The enquiry action is visible.

## Room announcement - Bedroom

- File: `deliverables/room-post-bedroom.png`
- Specification: {"format":"png","width":1080,"height":1350}
- Content: The featured room matches the named property. The enquiry action is visible.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
