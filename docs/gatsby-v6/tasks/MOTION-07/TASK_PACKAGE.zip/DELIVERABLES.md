# MOTION-07: delivery register

## Release film

- File: `deliverables/explainer.mp4`
- Specification: {"format":"mp4","width":1920,"height":1080,"ratio":"16:9","duration_seconds":{"min":12,"max":15},"audio":"music","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least four different supplied clips including the founder take, the release name “Throughline”, at least one of the three cleared claims from norvant_launch_copy.txt word for word, and a closing card carrying “norvant.com/march”.

## Release film vertical cutdown

- File: `deliverables/explainer-vertical.mp4`
- Specification: {"format":"mp4","width":1080,"height":1920,"ratio":"9:16","duration_seconds":{"min":6,"max":8},"audio":"silent","frame_rate":24,"video_codec":"h264","pixel_format":"yuv420p"}
- Content: At least three different supplied clips, the release name “Throughline” on screen, followed by a closing card carrying “norvant.com/march”.

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
