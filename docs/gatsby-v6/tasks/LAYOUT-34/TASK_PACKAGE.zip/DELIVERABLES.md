# LAYOUT-34: delivery register

## Plant variety tag - Coneflower

- File: `deliverables/plant-tag-r002.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - English Lavender 'Hidcote'

- File: `deliverables/plant-tag-r003.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Bee Balm

- File: `deliverables/plant-tag-r004.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Siberian Iris

- File: `deliverables/plant-tag-r005.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Common Thyme

- File: `deliverables/plant-tag-r006.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Oakleaf Hydrangea

- File: `deliverables/plant-tag-r007.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Lady's Mantle

- File: `deliverables/plant-tag-r008.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Greek Oregano

- File: `deliverables/plant-tag-r009.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - French Tarragon

- File: `deliverables/plant-tag-r010.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Bearded Iris 'Litchfield Gold'

- File: `deliverables/plant-tag-r011.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Japanese Maple 'Bloodgood'

- File: `deliverables/plant-tag-r012.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Garden Sage

- File: `deliverables/plant-tag-r013.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Mockorange 'Litchfield'

- File: `deliverables/plant-tag-r014.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Hardy Geranium

- File: `deliverables/plant-tag-r015.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Summersweet

- File: `deliverables/plant-tag-r016.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Star Magnolia

- File: `deliverables/plant-tag-r017.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Sweet Bay

- File: `deliverables/plant-tag-r018.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Doublefile Viburnum

- File: `deliverables/plant-tag-r019.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Peony 'Old Bench'

- File: `deliverables/plant-tag-r020.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Weeping Katsura

- File: `deliverables/plant-tag-r021.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - Fothergilla

- File: `deliverables/plant-tag-r022.pdf`
- Specification: {"format":"pdf","width_mm":148.167,"height_mm":209.889,"pages":1,"template_reference":"ferncroft_benchtag_2025_PRINTER.pdf"}
- Content: The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.

## Plant variety tag - combined production run

- File: `deliverables/plant-tag-combined.pdf`
- Specification: {"format":"pdf","pages":21,"width_mm":148.167,"height_mm":209.889}
- Content: undefined

## Department tag production run - Perennials (PER)

- File: `deliverables/department-run-perennials-per.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":7}
- Content: 

## Department tag production run - Herbs (HRB)

- File: `deliverables/department-run-herbs-hrb.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":6}
- Content: 

## Department tag production run - Shrubs (SHR)

- File: `deliverables/department-run-shrubs-shr.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":5}
- Content: 

## Department tag production run - Specimen (SPC)

- File: `deliverables/department-run-specimen-spc.pdf`
- Specification: {"format":"pdf","width_mm":55,"height_mm":85,"pages":3}
- Content: 

## Editable-source and selected-asset index

- File: `deliverables/source-handoff.json`
- Specification: {"format":"json"}
- Content: One entry per designed output: exact export filename, editable source file or public read-only design URL, selected input filenames with page/slot/time range, and source-to-export version association. Do not include passwords, tokens or expiring signed URLs.
