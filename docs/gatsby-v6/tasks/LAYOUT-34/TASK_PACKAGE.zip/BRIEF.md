# Ferncroft Nursery - Spring plant tag system

Spring plant tags with four complete, non-overlapping department files

Ferncroft Nursery needs the spring tag run rebuilt from last year's printed artwork and the growers' spreadsheet. The approved run contains twenty-one stocked varieties across PER, HRB, SHR and SPC.

What we need back
- Plant variety tag: 22 named exports. The photograph depicts the named variety. The care instruction matches the authoritative register. The tag remains readable at rack size.
- Department tag production run: 4 named exports. Supply one press-ready subset for PER, HRB, SHR and SPC, with no tag repeated between department files.

Permission and consent exclusions remain binding. For other conflicts, use the explicit V6 amendments and the approved values in the output register.

Use the attached brand identity and the source files listed in the asset manifest. The output register defines exact filenames, pages, sizes and record bindings. Supporting previews are welcome but cannot replace those files.

Production decisions for this edition
- The large tags use 28 pt common names and 15 pt Latin names; small department tags use 14 pt and 9 pt. These explicit sizes replace the contradictory exact-54-percent rule.
- The PER, HRB, SHR and SPC files contain their registered nonoverlapping subsets in source-row order. Keep variety/photo identity, care line, pot size and price exact; only botanical Latin is italic.

The V6 output register below is the complete handoff. Its per-output content, asset, colour and typography contracts are part of this brief. Historical templates do not add unregistered deliverables. Use the source handoff for editable designs and exact chosen-source references; do not include credentials.
